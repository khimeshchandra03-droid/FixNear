package com.fixnear.app.model;

import java.io.Serializable;

public class ProviderProfile implements Serializable {
    public static final String STATUS_NOT_SUBMITTED = "NOT_SUBMITTED";
    public static final String STATUS_PENDING_REVIEW = "PENDING_REVIEW";
    public static final String STATUS_VERIFIED = "VERIFIED";
    public static final String STATUS_REJECTED = "REJECTED";

    private long id;
    private long userId;
    private String name;
    private String email;
    private String phone;
    private String profilePhoto;
    private String category;
    private String skills;
    private int experienceYears;
    private double hourlyRate;
    private String serviceArea;
    private String bio;
    private String verificationStatus;
    private String idProofType;
    private String idProofNumber;
    private String idProofDocument;
    private String rejectionReason;
    private double ratingAvg;
    private int ratingCount;
    private int completedJobs;
    private int cancelledJobs;
    private int trustScore;
    private boolean isAvailable;
    private String createdAt;
    private boolean isFavorite;

    public ProviderProfile() {
        this.verificationStatus = STATUS_NOT_SUBMITTED;
        this.isAvailable = true;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getProfilePhoto() { return profilePhoto; }
    public void setProfilePhoto(String profilePhoto) { this.profilePhoto = profilePhoto; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }

    public int getExperienceYears() { return experienceYears; }
    public void setExperienceYears(int experienceYears) { this.experienceYears = experienceYears; }

    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }

    public String getServiceArea() { return serviceArea; }
    public void setServiceArea(String serviceArea) { this.serviceArea = serviceArea; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public String getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(String verificationStatus) { this.verificationStatus = verificationStatus; }

    public String getIdProofType() { return idProofType; }
    public void setIdProofType(String idProofType) { this.idProofType = idProofType; }

    public String getIdProofNumber() { return idProofNumber; }
    public void setIdProofNumber(String idProofNumber) { this.idProofNumber = idProofNumber; }

    public String getIdProofDocument() { return idProofDocument; }
    public void setIdProofDocument(String idProofDocument) { this.idProofDocument = idProofDocument; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public double getRatingAvg() { return ratingAvg; }
    public void setRatingAvg(double ratingAvg) { this.ratingAvg = ratingAvg; }

    public int getRatingCount() { return ratingCount; }
    public void setRatingCount(int ratingCount) { this.ratingCount = ratingCount; }

    public int getCompletedJobs() { return completedJobs; }
    public void setCompletedJobs(int completedJobs) { this.completedJobs = completedJobs; }

    public int getCancelledJobs() { return cancelledJobs; }
    public void setCancelledJobs(int cancelledJobs) { this.cancelledJobs = cancelledJobs; }

    public int getTrustScore() { return trustScore; }
    public void setTrustScore(int trustScore) { this.trustScore = trustScore; }

    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public boolean isVerified() {
        return STATUS_VERIFIED.equalsIgnoreCase(verificationStatus);
    }

    public boolean isPendingReview() {
        return STATUS_PENDING_REVIEW.equalsIgnoreCase(verificationStatus);
    }
}
