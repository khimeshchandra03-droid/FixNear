package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.fixnear.app.R;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.auth.LoginActivity;
import com.fixnear.app.ui.features.NotificationsActivity;
import com.fixnear.app.ui.features.PriceEstimatorActivity;
import com.fixnear.app.ui.features.ReportActivity;
import com.fixnear.app.ui.features.SmartAssistantActivity;
import com.google.android.material.button.MaterialButton;

public class CustomerProfileFragment extends Fragment {

    private TextView tvProfileName, tvProfileEmail, tvProfilePhone;
    private LinearLayout menuFavorites, menuNotifications, menuSmartAssistant, menuPriceEstimator, menuReport, menuEmergencyDisclaimer;
    private MaterialButton btnLogout;

    private SessionManager sessionManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_customer_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        sessionManager = new SessionManager(requireContext());

        initViews(view);
        populateUserData();
        setupMenuClickListeners();
    }

    private void initViews(View view) {
        tvProfileName = view.findViewById(R.id.tvProfileName);
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail);
        tvProfilePhone = view.findViewById(R.id.tvProfilePhone);
        menuFavorites = view.findViewById(R.id.menuFavorites);
        menuNotifications = view.findViewById(R.id.menuNotifications);
        menuSmartAssistant = view.findViewById(R.id.menuSmartAssistant);
        menuPriceEstimator = view.findViewById(R.id.menuPriceEstimator);
        menuReport = view.findViewById(R.id.menuReport);
        menuEmergencyDisclaimer = view.findViewById(R.id.menuEmergencyDisclaimer);
        btnLogout = view.findViewById(R.id.btnLogout);
    }

    private void populateUserData() {
        User user = sessionManager.getCurrentUser();
        if (user != null) {
            tvProfileName.setText(user.getName());
            tvProfileEmail.setText(user.getEmail());
            tvProfilePhone.setText(user.getPhone() != null && !user.getPhone().isEmpty() ? user.getPhone() : "Phone not set");
        }
    }

    private void setupMenuClickListeners() {
        menuFavorites.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), FavoritesActivity.class));
        });

        menuNotifications.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), NotificationsActivity.class));
        });

        menuSmartAssistant.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), SmartAssistantActivity.class));
        });

        menuPriceEstimator.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), PriceEstimatorActivity.class));
        });

        menuReport.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), ReportActivity.class);
            startActivity(intent);
        });

        menuEmergencyDisclaimer.setOnClickListener(v -> {
            showEmergencyDisclaimerDialog();
        });

        btnLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Sign Out")
                    .setMessage("Are you sure you want to sign out of FIXNEAR?")
                    .setPositiveButton("Sign Out", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(requireContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        requireActivity().finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    private void showEmergencyDisclaimerDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("⚠️ Important Safety & Emergency Notice")
                .setMessage("FIXNEAR is a scheduled repair service marketplace connecting customers with independent local technicians.\n\n" +
                        "FIXNEAR IS NOT AN EMERGENCY DISPATCH SERVICE.\n\n" +
                        "• For electrical fires, smoke, or live high-voltage hazards: Shut off your main supply breaker and immediately call 101 / 112.\n" +
                        "• For cooking gas / LPG cylinder leaks: Extinguish flames, do NOT operate electrical switches, ventilate rooms, and call your gas emergency line.\n" +
                        "• For life-threatening emergencies, call national emergency services (112).")
                .setPositiveButton("I Understand", null)
                .show();
    }
}
