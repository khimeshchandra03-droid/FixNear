package com.fixnear.app.engine;

import java.io.Serializable;

public class PriceEstimatorEngine {

    public static class PriceEstimateBreakdown implements Serializable {
        private String category;
        private String repairType;
        private double visitInspectionFee;
        private double laborMin;
        private double laborMax;
        private double partsEstimateMin;
        private double partsEstimateMax;
        private double totalEstimateMin;
        private double totalEstimateMax;
        private String disclaimer;

        public PriceEstimateBreakdown(String category, String repairType, double visitInspectionFee,
                                      double laborMin, double laborMax, double partsEstimateMin,
                                      double partsEstimateMax, String disclaimer) {
            this.category = category;
            this.repairType = repairType;
            this.visitInspectionFee = visitInspectionFee;
            this.laborMin = laborMin;
            this.laborMax = laborMax;
            this.partsEstimateMin = partsEstimateMin;
            this.partsEstimateMax = partsEstimateMax;
            this.totalEstimateMin = visitInspectionFee + laborMin + partsEstimateMin;
            this.totalEstimateMax = visitInspectionFee + laborMax + partsEstimateMax;
            this.disclaimer = disclaimer;
        }

        public String getCategory() { return category; }
        public String getRepairType() { return repairType; }
        public double getVisitInspectionFee() { return visitInspectionFee; }
        public double getLaborMin() { return laborMin; }
        public double getLaborMax() { return laborMax; }
        public double getPartsEstimateMin() { return partsEstimateMin; }
        public double getPartsEstimateMax() { return partsEstimateMax; }
        public double getTotalEstimateMin() { return totalEstimateMin; }
        public double getTotalEstimateMax() { return totalEstimateMax; }
        public String getDisclaimer() { return disclaimer; }
    }

    public static PriceEstimateBreakdown estimate(String category, String repairType, boolean isUrgent) {
        String cat = (category != null) ? category.trim() : "Electrical";
        double baseVisit = 199.0;
        double laborMin = 200.0;
        double laborMax = 450.0;
        double partsMin = 0.0;
        double partsMax = 300.0;

        if (cat.equalsIgnoreCase("AC Repair")) {
            baseVisit = 249.0;
            laborMin = 350.0;
            laborMax = 800.0;
            partsMin = 150.0;
            partsMax = 1200.0;
        } else if (cat.equalsIgnoreCase("Plumbing")) {
            baseVisit = 199.0;
            laborMin = 200.0;
            laborMax = 500.0;
            partsMin = 50.0;
            partsMax = 400.0;
        } else if (cat.equalsIgnoreCase("Appliances")) {
            baseVisit = 249.0;
            laborMin = 300.0;
            laborMax = 700.0;
            partsMin = 200.0;
            partsMax = 1000.0;
        } else if (cat.equalsIgnoreCase("CCTV Security")) {
            baseVisit = 299.0;
            laborMin = 400.0;
            laborMax = 900.0;
            partsMin = 100.0;
            partsMax = 800.0;
        } else if (cat.equalsIgnoreCase("RO Purifier")) {
            baseVisit = 199.0;
            laborMin = 250.0;
            laborMax = 450.0;
            partsMin = 300.0;
            partsMax = 1200.0;
        }

        if (isUrgent) {
            baseVisit += 100.0; // Priority visit surcharge
        }

        String disclaimer = "DISCLAIMER: This calculation is a transparent preliminary estimate based on standard regional rate cards. If physical parts need replacement, the specialist will present the invoice and confirm the exact quote prior to starting repairs.";

        return new PriceEstimateBreakdown(
                cat,
                repairType != null ? repairType : "Standard Servicing",
                baseVisit,
                laborMin,
                laborMax,
                partsMin,
                partsMax,
                disclaimer
        );
    }
}
