package com.fixnear.app.model;

import java.io.Serializable;

public class BookingTimelineEvent implements Serializable {
    private long id;
    private long bookingId;
    private String status;
    private String title;
    private String description;
    private String timestamp;

    public BookingTimelineEvent() {}

    public BookingTimelineEvent(long id, long bookingId, String status, String title, String description, String timestamp) {
        this.id = id;
        this.bookingId = bookingId;
        this.status = status;
        this.title = title;
        this.description = description;
        this.timestamp = timestamp;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getBookingId() { return bookingId; }
    public void setBookingId(long bookingId) { this.bookingId = bookingId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
