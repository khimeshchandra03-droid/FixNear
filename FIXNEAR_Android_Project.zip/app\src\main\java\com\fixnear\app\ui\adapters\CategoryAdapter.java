package com.fixnear.app.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.R;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    public static class CategoryItem {
        private String name;
        private int iconRes;

        public CategoryItem(String name, int iconRes) {
            this.name = name;
            this.iconRes = iconRes;
        }

        public String getName() { return name; }
        public int getIconRes() { return iconRes; }
    }

    public interface OnCategoryClickListener {
        void onCategoryClick(String categoryName);
    }

    private final Context context;
    private final List<CategoryItem> categories;
    private final OnCategoryClickListener listener;
    private String selectedCategory = "All";

    public CategoryAdapter(Context context, List<CategoryItem> categories, OnCategoryClickListener listener) {
        this.context = context;
        this.categories = categories;
        this.listener = listener;
    }

    public void setSelectedCategory(String category) {
        this.selectedCategory = category;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CategoryItem item = categories.get(position);
        holder.tvName.setText(item.getName());
        holder.imgIcon.setImageResource(item.getIconRes());

        boolean isSelected = item.getName().equalsIgnoreCase(selectedCategory);
        if (isSelected) {
            holder.itemView.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.brand_marigold_light));
            holder.tvName.setTextColor(ContextCompat.getColor(context, R.color.brand_deep_aubergine));
        } else {
            holder.itemView.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.surface_white));
            holder.tvName.setTextColor(ContextCompat.getColor(context, R.color.text_primary));
        }

        holder.itemView.setOnClickListener(v -> {
            selectedCategory = item.getName();
            notifyDataSetChanged();
            if (listener != null) {
                listener.onCategoryClick(item.getName());
            }
        });
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgIcon;
        TextView tvName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgIcon = itemView.findViewById(R.id.imgCategoryIcon);
            tvName = itemView.findViewById(R.id.tvCategoryName);
        }
    }
}
