package com.fixnear.app.engine;

import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.TrustScoreDetails;

public class TrustScoreCalculator {

    public static final int BASE_SCORE = 20;
    public static final int VERIFICATION_POINTS = 35;
    public static final int MAX_RATING_POINTS = 25;
    public static final int MAX_COMPLETED_JOB_POINTS = 20;

    public static TrustScoreDetails calculate(ProviderProfile profile) {
        if (profile == null) {
            return new TrustScoreDetails(0, 0, 0, 0, 0, 0, "Unrated", "No profile data available.");
        }

        int score = BASE_SCORE;

        // 1. Govt ID Verification Points
        int verifPts = profile.isVerified() ? VERIFICATION_POINTS : 0;
        score += verifPts;

        // 2. Rating Points (0 to 25 based on rating out of 5.0)
        int ratingPts = 0;
        if (profile.getRatingCount() > 0) {
            ratingPts = (int) Math.round((profile.getRatingAvg() / 5.0) * MAX_RATING_POINTS);
            if (ratingPts > MAX_RATING_POINTS) ratingPts = MAX_RATING_POINTS;
        }
        score += ratingPts;

        // 3. Completed Jobs Points (+2 pts each up to 20 pts)
        int jobPts = Math.min(profile.getCompletedJobs() * 2, MAX_COMPLETED_JOB_POINTS);
        score += jobPts;

        // 4. Cancellation Penalty (-5 pts each cancelled job)
        int penalty = profile.getCancelledJobs() * 5;
        score -= penalty;

        // Clamp between 10 and 100
        if (score > 100) score = 100;
        if (score < 10) score = 10;

        String tier;
        if (score >= 85) {
            tier = "Elite Trust";
        } else if (score >= 70) {
            tier = "High Trust";
        } else if (score >= 50) {
            tier = "Moderate Trust";
        } else {
            tier = "Basic / New Member";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Base Starting: +").append(BASE_SCORE).append(" pts\n");
        if (profile.isVerified()) {
            sb.append("Govt ID Verification: +").append(VERIFICATION_POINTS).append(" pts (Verified)\n");
        } else {
            sb.append("Govt ID Verification: 0 pts (Pending or unsubmitted)\n");
        }
        sb.append(String.format("Rating (%.1f/5 from %d reviews): +%d pts\n", profile.getRatingAvg(), profile.getRatingCount(), ratingPts));
        sb.append("Completed Services (").append(profile.getCompletedJobs()).append(" jobs): +").append(jobPts).append(" pts\n");
        if (penalty > 0) {
            sb.append("Cancellations (").append(profile.getCancelledJobs()).append("): -").append(penalty).append(" pts\n");
        }
        sb.append("Final Transparent Trust Score: ").append(score).append("/100 (").append(tier).append(")");

        return new TrustScoreDetails(score, BASE_SCORE, verifPts, ratingPts, jobPts, penalty, tier, sb.toString());
    }
}
