package com.fixnear.app.ui.features;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.NotificationItem;
import com.fixnear.app.ui.adapters.NotificationAdapter;

import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private ImageView btnNotifBack;
    private RecyclerView rvNotifications;
    private TextView tvEmptyNotifs;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        btnNotifBack = findViewById(R.id.btnNotifBack);
        rvNotifications = findViewById(R.id.rvNotifications);
        tvEmptyNotifs = findViewById(R.id.tvEmptyNotifs);

        btnNotifBack.setOnClickListener(v -> finish());

        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        loadNotifications();
    }

    private void loadNotifications() {
        long userId = sessionManager.getUserId();
        List<NotificationItem> list = dbHelper.getNotifications(userId);

        NotificationAdapter adapter = new NotificationAdapter(this, list, item -> {
            dbHelper.markNotificationRead(item.getId());
            item.setRead(true);
            rvNotifications.getAdapter().notifyDataSetChanged();
        });

        rvNotifications.setAdapter(adapter);

        if (list.isEmpty()) {
            tvEmptyNotifs.setVisibility(View.VISIBLE);
            rvNotifications.setVisibility(View.GONE);
        } else {
            tvEmptyNotifs.setVisibility(View.GONE);
            rvNotifications.setVisibility(View.VISIBLE);
        }
    }
}
