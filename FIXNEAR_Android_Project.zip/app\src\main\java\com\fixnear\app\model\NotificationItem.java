package com.fixnear.app.model;

import java.io.Serializable;

public class NotificationItem implements Serializable {
    public static final String TYPE_BOOKING = "BOOKING";
    public static final String TYPE_VERIFICATION = "VERIFICATION";
    public static final String TYPE_MESSAGE = "MESSAGE";
    public static final String TYPE_SYSTEM = "SYSTEM";

    private long id;
    private long userId;
    private String title;
    private String message;
    private String type;
    private long relatedId;
    private boolean isRead;
    private String timestamp;

    public NotificationItem() {}

    public NotificationItem(long id, long userId, String title, String message, String type,
                            long relatedId, boolean isRead, String timestamp) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.type = type;
        this.relatedId = relatedId;
        this.isRead = isRead;
        this.timestamp = timestamp;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public long getRelatedId() { return relatedId; }
    public void setRelatedId(long relatedId) { this.relatedId = relatedId; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
