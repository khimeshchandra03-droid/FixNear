package com.fixnear.app.model;

import java.io.Serializable;

public class TrustScoreDetails implements Serializable {
    private int totalScore;
    private int baseScore;
    private int verificationPoints;
    private int ratingPoints;
    private int completedJobPoints;
    private int cancellationPenalty;
    private String tierLabel;
    private String explanation;

    public TrustScoreDetails(int totalScore, int baseScore, int verificationPoints,
                             int ratingPoints, int completedJobPoints, int cancellationPenalty,
                             String tierLabel, String explanation) {
        this.totalScore = totalScore;
        this.baseScore = baseScore;
        this.verificationPoints = verificationPoints;
        this.ratingPoints = ratingPoints;
        this.completedJobPoints = completedJobPoints;
        this.cancellationPenalty = cancellationPenalty;
        this.tierLabel = tierLabel;
        this.explanation = explanation;
    }

    public int getTotalScore() { return totalScore; }
    public int getBaseScore() { return baseScore; }
    public int getVerificationPoints() { return verificationPoints; }
    public int getRatingPoints() { return ratingPoints; }
    public int getCompletedJobPoints() { return completedJobPoints; }
    public int getCancellationPenalty() { return cancellationPenalty; }
    public String getTierLabel() { return tierLabel; }
    public String getExplanation() { return explanation; }
}
