package com.fixnear.app.model;

import java.io.Serializable;

public class Booking implements Serializable {
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_ACCEPTED = "ACCEPTED";
    public static final String STATUS_SCHEDULED = "SCHEDULED";
    public static final String STATUS_IN_PROGRESS = "IN_PROGRESS";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_CANCELLED = "CANCELLED";
    public static final String STATUS_REJECTED = "REJECTED";

    private long id;
    private String bookingCode;
    private long customerId;
    private String customerName;
    private String customerPhone;
    private long providerId;
    private String providerName;
    private String providerCategory;
    private long serviceId;
    private String serviceTitle;
    private String problemDescription;
    private String serviceAddress;
    private String scheduledDate;
    private String scheduledTimeSlot;
    private double estimatedCost;
    private double finalCost;
    private String status;
    private String rejectionReason;
    private String cancellationReason;
    private String createdAt;
    private String updatedAt;
    private boolean hasReview;

    public Booking() {
        this.status = STATUS_PENDING;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getBookingCode() { return bookingCode; }
    public void setBookingCode(String bookingCode) { this.bookingCode = bookingCode; }

    public long getCustomerId() { return customerId; }
    public void setCustomerId(long customerId) { this.customerId = customerId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }

    public long getProviderId() { return providerId; }
    public void setProviderId(long providerId) { this.providerId = providerId; }

    public String getProviderName() { return providerName; }
    public void setProviderName(String providerName) { this.providerName = providerName; }

    public String getProviderCategory() { return providerCategory; }
    public void setProviderCategory(String providerCategory) { this.providerCategory = providerCategory; }

    public long getServiceId() { return serviceId; }
    public void setServiceId(long serviceId) { this.serviceId = serviceId; }

    public String getServiceTitle() { return serviceTitle; }
    public void setServiceTitle(String serviceTitle) { this.serviceTitle = serviceTitle; }

    public String getProblemDescription() { return problemDescription; }
    public void setProblemDescription(String problemDescription) { this.problemDescription = problemDescription; }

    public String getServiceAddress() { return serviceAddress; }
    public void setServiceAddress(String serviceAddress) { this.serviceAddress = serviceAddress; }

    public String getScheduledDate() { return scheduledDate; }
    public void setScheduledDate(String scheduledDate) { this.scheduledDate = scheduledDate; }

    public String getScheduledTimeSlot() { return scheduledTimeSlot; }
    public void setScheduledTimeSlot(String scheduledTimeSlot) { this.scheduledTimeSlot = scheduledTimeSlot; }

    public double getEstimatedCost() { return estimatedCost; }
    public void setEstimatedCost(double estimatedCost) { this.estimatedCost = estimatedCost; }

    public double getFinalCost() { return finalCost; }
    public void setFinalCost(double finalCost) { this.finalCost = finalCost; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public String getCancellationReason() { return cancellationReason; }
    public void setCancellationReason(String cancellationReason) { this.cancellationReason = cancellationReason; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }

    public boolean isHasReview() { return hasReview; }
    public void setHasReview(boolean hasReview) { this.hasReview = hasReview; }

    public boolean isPending() { return STATUS_PENDING.equalsIgnoreCase(status); }
    public boolean isAccepted() { return STATUS_ACCEPTED.equalsIgnoreCase(status); }
    public boolean isScheduled() { return STATUS_SCHEDULED.equalsIgnoreCase(status); }
    public boolean isInProgress() { return STATUS_IN_PROGRESS.equalsIgnoreCase(status); }
    public boolean isCompleted() { return STATUS_COMPLETED.equalsIgnoreCase(status); }
    public boolean isCancelled() { return STATUS_CANCELLED.equalsIgnoreCase(status); }
    public boolean isRejected() { return STATUS_REJECTED.equalsIgnoreCase(status); }

    public boolean canCancel() {
        return isPending() || isAccepted() || isScheduled();
    }
}
