package com.fixnear.app.ui.provider;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.ui.adapters.BookingAdapter;
import com.fixnear.app.ui.booking.BookingDetailActivity;

import java.util.ArrayList;
import java.util.List;

public class ProviderRequestsFragment extends Fragment implements BookingAdapter.OnBookingClickListener {

    private RecyclerView rvProviderAllRequests;
    private LinearLayout layoutProviderRequestsEmpty;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private BookingAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_provider_requests, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        rvProviderAllRequests = view.findViewById(R.id.rvProviderAllRequests);
        layoutProviderRequestsEmpty = view.findViewById(R.id.layoutProviderRequestsEmpty);

        rvProviderAllRequests.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BookingAdapter(requireContext(), new ArrayList<>(), true, this);
        rvProviderAllRequests.setAdapter(adapter);

        loadRequests();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadRequests();
    }

    private void loadRequests() {
        long userId = sessionManager.getUserId();
        ProviderProfile p = dbHelper.getProviderByUserId(userId);
        if (p == null) return;

        List<Booking> list = dbHelper.getBookingsForProvider(p.getId(), null);
        adapter.updateList(list);

        if (list.isEmpty()) {
            layoutProviderRequestsEmpty.setVisibility(View.VISIBLE);
            rvProviderAllRequests.setVisibility(View.GONE);
        } else {
            layoutProviderRequestsEmpty.setVisibility(View.GONE);
            rvProviderAllRequests.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBookingClick(Booking booking) {
        Intent intent = new Intent(requireContext(), BookingDetailActivity.class);
        intent.putExtra("booking_id", booking.getId());
        startActivity(intent);
    }
}
