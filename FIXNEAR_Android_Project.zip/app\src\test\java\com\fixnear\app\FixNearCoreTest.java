package com.fixnear.app;

import com.fixnear.app.data.SecurityUtils;
import com.fixnear.app.engine.PriceEstimatorEngine;
import com.fixnear.app.engine.SmartAssistantEngine;
import com.fixnear.app.engine.SmartMatchingEngine;
import com.fixnear.app.engine.TrustScoreCalculator;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.TrustScoreDetails;
import com.fixnear.app.model.User;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Automated Verification Suite for FIXNEAR Core Logic, Engines, Security & Workflows.
 */
public class FixNearCoreTest {

    // ==========================================
    // 1. SECURITY & PASSWORD HASHING TESTS
    // ==========================================

    @Test
    public void testPasswordHashingAndVerification() {
        String password = "SecretPassword123!";
        String salt = SecurityUtils.generateSalt();

        assertNotNull("Generated salt must not be null", salt);
        assertEquals("Salt should be 32 hex characters (16 bytes)", 32, salt.length());

        String hash = SecurityUtils.hashPassword(password, salt);
        assertNotNull("Hash must not be null", hash);
        assertEquals("SHA-256 hash length in hex should be 64 characters", 64, hash.length());

        // Correct password matches
        assertTrue("Verification must succeed with matching password",
                SecurityUtils.verifyPassword(password, hash, salt));

        // Incorrect password rejected
        assertFalse("Verification must fail with wrong password",
                SecurityUtils.verifyPassword("WrongPassword123!", hash, salt));
    }

    @Test
    public void testEmailAndPhoneValidation() {
        assertTrue(SecurityUtils.isValidEmail("customer@fixnear.com"));
        assertTrue(SecurityUtils.isValidEmail("provider.test@service.co.in"));
        assertFalse(SecurityUtils.isValidEmail("plainaddress"));
        assertFalse(SecurityUtils.isValidEmail("@missingusername.com"));

        assertTrue(SecurityUtils.isValidPhone("+91 98765 43210"));
        assertTrue(SecurityUtils.isValidPhone("9876543210"));
        assertFalse(SecurityUtils.isValidPhone("123")); // Too short
    }

    // ==========================================
    // 2. USER ROLE & INITIAL VERIFICATION STATUS
    // ==========================================

    @Test
    public void testProviderVerificationInitialStatusNotAutoVerified() {
        ProviderProfile profile = new ProviderProfile();
        // New providers must start as NOT_SUBMITTED, not falsely VERIFIED!
        assertEquals("Newly registered provider must start with NOT_SUBMITTED status",
                ProviderProfile.STATUS_NOT_SUBMITTED, profile.getVerificationStatus());
        assertFalse("Newly registered provider must not be verified by default", profile.isVerified());

        // When submitted, becomes PENDING_REVIEW
        profile.setVerificationStatus(ProviderProfile.STATUS_PENDING_REVIEW);
        assertTrue("Provider should be in pending review state", profile.isPendingReview());
        assertFalse("Provider in pending review must not be labeled verified", profile.isVerified());

        // Only after administrative audit does it become VERIFIED
        profile.setVerificationStatus(ProviderProfile.STATUS_VERIFIED);
        assertTrue("Provider must be verified after approval", profile.isVerified());
    }

    // ==========================================
    // 3. FIXNEAR TRUST SCORE ENGINE TESTS
    // ==========================================

    @Test
    public void testTrustScoreCalculationExplainableBreakdown() {
        ProviderProfile unverifiedProvider = new ProviderProfile();
        unverifiedProvider.setVerificationStatus(ProviderProfile.STATUS_NOT_SUBMITTED);
        unverifiedProvider.setRatingAvg(0.0);
        unverifiedProvider.setRatingCount(0);
        unverifiedProvider.setCompletedJobs(0);
        unverifiedProvider.setCancelledJobs(0);

        TrustScoreDetails unverifiedScore = TrustScoreCalculator.calculate(unverifiedProvider);
        assertEquals("Base starting trust score should be 20 pts", 20, unverifiedScore.getTotalScore());
        assertEquals(0, unverifiedScore.getVerificationPoints());

        // Verified Specialist with high rating and completed jobs
        ProviderProfile eliteProvider = new ProviderProfile();
        eliteProvider.setVerificationStatus(ProviderProfile.STATUS_VERIFIED);
        eliteProvider.setRatingAvg(4.8);
        eliteProvider.setRatingCount(40);
        eliteProvider.setCompletedJobs(10); // +20 pts (max)
        eliteProvider.setCancelledJobs(0);

        TrustScoreDetails eliteScore = TrustScoreCalculator.calculate(eliteProvider);
        // Base(20) + Verif(35) + Rating(round(4.8/5.0 * 25) = 24) + Jobs(20) - Cancel(0) = 99
        assertTrue("Elite provider score should be high (>= 90 pts)", eliteScore.getTotalScore() >= 90);
        assertEquals("Elite Trust", eliteScore.getTierLabel());
        assertTrue(eliteScore.getExplanation().contains("Govt ID Verification: +35 pts (Verified)"));

        // Penalty for cancellations
        eliteProvider.setCancelledJobs(3); // -15 pts
        TrustScoreDetails penalizedScore = TrustScoreCalculator.calculate(eliteProvider);
        assertEquals(eliteScore.getTotalScore() - 15, penalizedScore.getTotalScore());
    }

    // ==========================================
    // 4. SMART REPAIR ASSISTANT DIAGNOSTIC ENGINE
    // ==========================================

    @Test
    public void testSmartRepairAssistantElectricalDiagnosis() {
        SmartAssistantEngine.DiagnosisResult result =
                SmartAssistantEngine.analyzeIssue("Electrical", "Switchboard is sparking and has burning smell", "Urgent");

        assertNotNull(result);
        assertEquals("Electrical", result.getCategory());
        assertTrue("Diagnosis should detect short circuit or terminal overload",
                result.getIssueSummary().contains("Short Circuit"));
        assertTrue("Safety precaution must warn to turn off main breaker switch",
                result.getSafetyPrecaution().contains("breaker"));
        assertTrue("Estimated cost should be positive",
                result.getEstimatedMinCost() > 0 && result.getEstimatedMaxCost() >= result.getEstimatedMinCost());
    }

    @Test
    public void testSmartRepairAssistantACDiagnosis() {
        SmartAssistantEngine.DiagnosisResult result =
                SmartAssistantEngine.analyzeIssue("AC Repair", "AC not cooling and blowing warm air", "Normal");

        assertNotNull(result);
        assertEquals("AC Repair", result.getCategory());
        assertTrue(result.getIssueSummary().contains("Cooling") || result.getIssueSummary().contains("Refrigerant"));
    }

    // ==========================================
    // 5. TRANSPARENT PRICE ESTIMATOR ENGINE
    // ==========================================

    @Test
    public void testPriceEstimatorBreakdownAndDisclaimer() {
        PriceEstimatorEngine.PriceEstimateBreakdown breakdown =
                PriceEstimatorEngine.estimate("AC Repair", "Jet Servicing", false);

        assertNotNull(breakdown);
        assertEquals(249.0, breakdown.getVisitInspectionFee(), 0.01);
        assertTrue(breakdown.getLaborMin() > 0);
        assertTrue(breakdown.getTotalEstimateMin() >= breakdown.getVisitInspectionFee() + breakdown.getLaborMin());
        assertNotNull(breakdown.getDisclaimer());
        assertTrue("Disclaimer must clarify this is an estimated rate range",
                breakdown.getDisclaimer().contains("DISCLAIMER"));

        // Urgent priority adds surcharge
        PriceEstimatorEngine.PriceEstimateBreakdown urgentBreakdown =
                PriceEstimatorEngine.estimate("AC Repair", "Jet Servicing", true);
        assertEquals(breakdown.getVisitInspectionFee() + 100.0, urgentBreakdown.getVisitInspectionFee(), 0.01);
    }

    // ==========================================
    // 6. SMART MATCHING RECOMMENDATION ENGINE
    // ==========================================

    @Test
    public void testSmartMatchingAlgorithmRanksVerifiedHigher() {
        List<ProviderProfile> providers = new ArrayList<>();

        ProviderProfile p1 = new ProviderProfile();
        p1.setId(1);
        p1.setName("Unverified Tech");
        p1.setCategory("Electrical");
        p1.setVerificationStatus(ProviderProfile.STATUS_NOT_SUBMITTED);
        p1.setTrustScore(30);
        p1.setRatingAvg(3.5);
        p1.setHourlyRate(200.0);
        providers.add(p1);

        ProviderProfile p2 = new ProviderProfile();
        p2.setId(2);
        p2.setName("Verified Master Electrician");
        p2.setCategory("Electrical");
        p2.setVerificationStatus(ProviderProfile.STATUS_VERIFIED);
        p2.setTrustScore(95);
        p2.setRatingAvg(4.9);
        p2.setHourlyRate(300.0);
        providers.add(p2);

        List<SmartMatchingEngine.MatchResult> matches = SmartMatchingEngine.match(providers, "Electrical", 500.0);
        assertEquals(2, matches.size());
        assertEquals("Verified Master Electrician should rank #1 due to higher Trust Score and Verified status",
                "Verified Master Electrician", matches.get(0).getProvider().getName());
        assertTrue(matches.get(0).getMatchPercentage() > matches.get(1).getMatchPercentage());
    }

    // ==========================================
    // 7. BOOKING STATUS TRANSITIONS & CANCELLATION
    // ==========================================

    @Test
    public void testBookingStatusTransitions() {
        Booking booking = new Booking();
        booking.setStatus(Booking.STATUS_PENDING);

        assertTrue("Pending booking should be cancellable", booking.canCancel());
        assertTrue(booking.isPending());

        booking.setStatus(Booking.STATUS_ACCEPTED);
        assertTrue("Accepted booking should be cancellable", booking.canCancel());

        booking.setStatus(Booking.STATUS_IN_PROGRESS);
        assertFalse("In-progress booking cannot be arbitrarily cancelled", booking.canCancel());

        booking.setStatus(Booking.STATUS_COMPLETED);
        assertFalse(booking.canCancel());
        assertTrue(booking.isCompleted());
    }
}
