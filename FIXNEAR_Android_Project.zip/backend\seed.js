const bcrypt = require('bcryptjs');
const db = require('./db');

async function seed() {
    console.log('Seeding FIXNEAR REST API Database...');

    const passHash = await bcrypt.hash('admin123', 10);
    const custHash = await bcrypt.hash('cust123', 10);
    const provHash = await bcrypt.hash('prov123', 10);

    // 1. Admin
    await db.runAsync(`
        INSERT OR IGNORE INTO users (id, name, email, password, phone, role)
        VALUES (1, 'FIXNEAR Admin', 'admin@fixnear.com', ?, '+91 98765 00000', 'ADMIN')
    `, [passHash]);

    // 2. Demo Customer
    await db.runAsync(`
        INSERT OR IGNORE INTO users (id, name, email, password, phone, role)
        VALUES (2, 'Rajesh Sharma', 'customer@fixnear.com', ?, '+91 98111 22334', 'CUSTOMER')
    `, [custHash]);

    // 3. Demo Provider
    await db.runAsync(`
        INSERT OR IGNORE INTO users (id, name, email, password, phone, role)
        VALUES (3, 'Manoj Kumar', 'provider@fixnear.com', ?, '+91 98222 33445', 'PROVIDER')
    `, [provHash]);

    await db.runAsync(`
        INSERT OR IGNORE INTO provider_profiles (id, user_id, category, skills, experience_years, hourly_rate, service_area, bio, verification_status, id_proof_type, id_proof_number, rating_avg, rating_count, completed_jobs, trust_score)
        VALUES (1, 3, 'Electrical', 'Wiring, MCB Repair, Inverters, Lighting', 8, 300.0, 'South Zone, 15km', 'Licensed wireman with 8+ years hands-on experience.', 'VERIFIED', 'Aadhaar Card', 'XXXX-XXXX-8921', 4.8, 42, 38, 95)
    `);

    // 4. Suresh Verma (AC)
    const acHash = await bcrypt.hash('pass123', 10);
    await db.runAsync(`
        INSERT OR IGNORE INTO users (id, name, email, password, phone, role)
        VALUES (4, 'Suresh Verma', 'suresh.ac@fixnear.com', ?, '+91 98333 44556', 'PROVIDER')
    `, [acHash]);

    await db.runAsync(`
        INSERT OR IGNORE INTO provider_profiles (id, user_id, category, skills, experience_years, hourly_rate, service_area, bio, verification_status, id_proof_type, id_proof_number, rating_avg, rating_count, completed_jobs, trust_score)
        VALUES (2, 4, 'AC Repair', 'Inverter AC, Gas Charging, Jet Servicing', 10, 350.0, 'North & Central Zones', 'Certified HVAC technician specializing in major brands.', 'VERIFIED', 'Trade License', 'HVAC-2018-9921', 4.9, 58, 52, 98)
    `);

    // 5. Amit Patel (Pending)
    const amitHash = await bcrypt.hash('pass123', 10);
    await db.runAsync(`
        INSERT OR IGNORE INTO users (id, name, email, password, phone, role)
        VALUES (5, 'Amit Patel', 'amit.repair@fixnear.com', ?, '+91 98555 66778', 'PROVIDER')
    `, [amitHash]);

    await db.runAsync(`
        INSERT OR IGNORE INTO provider_profiles (id, user_id, category, skills, experience_years, hourly_rate, service_area, bio, verification_status, id_proof_type, id_proof_number, rating_avg, rating_count, completed_jobs, trust_score)
        VALUES (3, 5, 'Appliances', 'Washing Machine, Refrigerator, Microwave', 5, 280.0, 'East Zone', 'Factory trained technician for front-load washers and frost-free fridges.', 'PENDING_REVIEW', 'PAN Card', 'ABCDE1234F', 4.5, 14, 12, 68)
    `);

    console.log('Seed completed successfully!');
}

seed().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
