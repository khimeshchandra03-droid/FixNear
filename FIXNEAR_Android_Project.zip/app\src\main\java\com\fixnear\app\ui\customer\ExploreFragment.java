package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.ui.adapters.ProviderCardAdapter;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class ExploreFragment extends Fragment implements ProviderCardAdapter.OnProviderActionListener {

    private static final String ARG_CATEGORY = "category";

    private TextInputEditText etSearchQuery;
    private ChipGroup chipGroupCategory;
    private Chip chipVerifiedOnly;
    private Spinner spinnerSort;
    private RecyclerView rvExploreProviders;
    private LinearLayout layoutEmptyState;
    private MaterialButton btnClearFilters;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderCardAdapter adapter;

    private String currentCategory = "All";
    private String currentSort = "TRUST_SCORE";
    private boolean verifiedOnly = false;

    public static ExploreFragment newInstance(String category) {
        ExploreFragment fragment = new ExploreFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CATEGORY, category);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_customer_explore, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        if (getArguments() != null) {
            String cat = getArguments().getString(ARG_CATEGORY);
            if (cat != null && !cat.isEmpty()) {
                currentCategory = cat;
            }
        }

        initViews(view);
        setupSortSpinner();
        setupRecyclerView();
        setupFilters();
        syncCategoryChip();
        applyFilters();
    }

    private void initViews(View view) {
        etSearchQuery = view.findViewById(R.id.etSearchQuery);
        chipGroupCategory = view.findViewById(R.id.chipGroupCategory);
        chipVerifiedOnly = view.findViewById(R.id.chipVerifiedOnly);
        spinnerSort = view.findViewById(R.id.spinnerSort);
        rvExploreProviders = view.findViewById(R.id.rvExploreProviders);
        layoutEmptyState = view.findViewById(R.id.layoutEmptyState);
        btnClearFilters = view.findViewById(R.id.btnClearFilters);
    }

    private void setupSortSpinner() {
        String[] sortOptions = new String[]{"Highest Trust Score", "Top Rated", "Price: Low to High", "Price: High to Low"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, sortOptions);
        spinnerSort.setAdapter(sortAdapter);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        currentSort = "RATING";
                        break;
                    case 2:
                        currentSort = "PRICE_LOW_HIGH";
                        break;
                    case 3:
                        currentSort = "PRICE_HIGH_LOW";
                        break;
                    case 0:
                    default:
                        currentSort = "TRUST_SCORE";
                        break;
                }
                applyFilters();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupRecyclerView() {
        rvExploreProviders.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ProviderCardAdapter(requireContext(), new ArrayList<>(), this);
        rvExploreProviders.setAdapter(adapter);
    }

    private void setupFilters() {
        etSearchQuery.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilters();
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        chipGroupCategory.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipElectrical) {
                currentCategory = "Electrical";
            } else if (checkedId == R.id.chipAc) {
                currentCategory = "AC Repair";
            } else if (checkedId == R.id.chipPlumbing) {
                currentCategory = "Plumbing";
            } else if (checkedId == R.id.chipAppliances) {
                currentCategory = "Appliances";
            } else if (checkedId == R.id.chipCarpentry) {
                currentCategory = "Carpentry";
            } else if (checkedId == R.id.chipCctv) {
                currentCategory = "CCTV Security";
            } else {
                currentCategory = "All";
            }
            applyFilters();
        });

        chipVerifiedOnly.setOnCheckedChangeListener((buttonView, isChecked) -> {
            verifiedOnly = isChecked;
            applyFilters();
        });

        btnClearFilters.setOnClickListener(v -> {
            etSearchQuery.setText("");
            chipGroupCategory.check(R.id.chipAll);
            chipVerifiedOnly.setChecked(false);
            spinnerSort.setSelection(0);
            currentCategory = "All";
            verifiedOnly = false;
            currentSort = "TRUST_SCORE";
            applyFilters();
        });
    }

    private void syncCategoryChip() {
        if ("Electrical".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipElectrical);
        } else if ("AC Repair".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipAc);
        } else if ("Plumbing".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipPlumbing);
        } else if ("Appliances".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipAppliances);
        } else if ("Carpentry".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipCarpentry);
        } else if ("CCTV Security".equalsIgnoreCase(currentCategory)) {
            chipGroupCategory.check(R.id.chipCctv);
        } else {
            chipGroupCategory.check(R.id.chipAll);
        }
    }

    private void applyFilters() {
        String query = etSearchQuery.getText() != null ? etSearchQuery.getText().toString().trim() : "";
        long customerId = sessionManager.getUserId();

        List<ProviderProfile> results = dbHelper.searchAndFilterProviders(
                query,
                currentCategory,
                0,
                0,
                verifiedOnly,
                currentSort,
                customerId
        );

        adapter.updateList(results);

        if (results.isEmpty()) {
            layoutEmptyState.setVisibility(View.VISIBLE);
            rvExploreProviders.setVisibility(View.GONE);
        } else {
            layoutEmptyState.setVisibility(View.GONE);
            rvExploreProviders.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onProviderClick(ProviderProfile provider) {
        Intent intent = new Intent(requireContext(), ProviderDetailActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onBookClick(ProviderProfile provider) {
        Intent intent = new Intent(requireContext(), BookingActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onFavoriteToggle(ProviderProfile provider, int position) {
        long customerId = sessionManager.getUserId();
        boolean isFav = dbHelper.toggleFavorite(customerId, provider.getId());
        provider.setFavorite(isFav);
        adapter.notifyItemChanged(position);
        Toast.makeText(requireContext(), isFav ? "Saved to Favorites" : "Removed from Favorites", Toast.LENGTH_SHORT).show();
    }
}
