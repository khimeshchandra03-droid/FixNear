package com.fixnear.app.ui.provider;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class VerificationActivity extends AppCompatActivity {

    private ImageView btnVerifBack;
    private TextView tvCurrentVerifStatus, tvVerifRejectionFeedback;
    private Spinner spinnerIdProofType, spinnerTradeCategory;
    private TextInputEditText etIdProofNumber, etSkills, etExperience, etHourlyRate, etServiceArea, etBio;
    private MaterialButton btnSubmitVerification;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderProfile profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        initViews();
        setupSpinners();
        loadExistingData();
        setupListeners();
    }

    private void initViews() {
        btnVerifBack = findViewById(R.id.btnVerifBack);
        tvCurrentVerifStatus = findViewById(R.id.tvCurrentVerifStatus);
        tvVerifRejectionFeedback = findViewById(R.id.tvVerifRejectionFeedback);
        spinnerIdProofType = findViewById(R.id.spinnerIdProofType);
        spinnerTradeCategory = findViewById(R.id.spinnerTradeCategory);
        etIdProofNumber = findViewById(R.id.etIdProofNumber);
        etSkills = findViewById(R.id.etSkills);
        etExperience = findViewById(R.id.etExperience);
        etHourlyRate = findViewById(R.id.etHourlyRate);
        etServiceArea = findViewById(R.id.etServiceArea);
        etBio = findViewById(R.id.etBio);
        btnSubmitVerification = findViewById(R.id.btnSubmitVerification);
    }

    private void setupSpinners() {
        String[] idTypes = new String[]{
                "Aadhaar Card",
                "PAN Card",
                "Government Wireman / Trade License",
                "Driving License",
                "Voter ID Card"
        };
        ArrayAdapter<String> idAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, idTypes);
        spinnerIdProofType.setAdapter(idAdapter);

        String[] categories = new String[]{
                "Electrical",
                "AC Repair",
                "Plumbing",
                "Appliances",
                "Carpentry",
                "CCTV Security",
                "RO Purifier",
                "Painting",
                "Mobile & PC"
        };
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinnerTradeCategory.setAdapter(catAdapter);
    }

    private void loadExistingData() {
        long userId = sessionManager.getUserId();
        profile = dbHelper.getProviderByUserId(userId);
        if (profile == null) return;

        // Status Banner
        if (profile.isVerified()) {
            tvCurrentVerifStatus.setText("Status: GOVT ID VERIFIED ✓");
            tvCurrentVerifStatus.setBackgroundResource(R.drawable.bg_badge_verified);
            tvCurrentVerifStatus.setTextColor(ContextCompat.getColor(this, R.color.badge_verified));
            btnSubmitVerification.setText("Update Submitted Credentials");
        } else if (profile.isPendingReview()) {
            tvCurrentVerifStatus.setText("Status: PENDING ADMINISTRATIVE REVIEW ⏳");
            tvCurrentVerifStatus.setBackgroundResource(R.drawable.bg_badge_pending);
            tvCurrentVerifStatus.setTextColor(ContextCompat.getColor(this, R.color.status_pending));
            btnSubmitVerification.setText("Resubmit / Update Application");
        } else if (ProviderProfile.STATUS_REJECTED.equalsIgnoreCase(profile.getVerificationStatus())) {
            tvCurrentVerifStatus.setText("Status: APPLICATION REJECTED ❌");
            tvCurrentVerifStatus.setBackgroundResource(R.drawable.bg_badge_pending);
            tvCurrentVerifStatus.setTextColor(ContextCompat.getColor(this, R.color.status_cancelled));
            if (profile.getRejectionReason() != null && !profile.getRejectionReason().isEmpty()) {
                tvVerifRejectionFeedback.setText("Admin Feedback: " + profile.getRejectionReason());
                tvVerifRejectionFeedback.setVisibility(View.VISIBLE);
            }
            btnSubmitVerification.setText("Resubmit Verification with Corrections");
        } else {
            tvCurrentVerifStatus.setText("Status: NOT SUBMITTED ⚠️");
            tvCurrentVerifStatus.setBackgroundResource(R.drawable.bg_badge_unverified);
            tvCurrentVerifStatus.setTextColor(ContextCompat.getColor(this, R.color.badge_unverified));
            btnSubmitVerification.setText("Submit for Admin Verification");
        }

        // Fill existing values
        if (profile.getIdProofNumber() != null) etIdProofNumber.setText(profile.getIdProofNumber());
        if (profile.getSkills() != null) etSkills.setText(profile.getSkills());
        etExperience.setText(String.valueOf(profile.getExperienceYears()));
        etHourlyRate.setText(String.valueOf((int) profile.getHourlyRate()));
        if (profile.getServiceArea() != null) etServiceArea.setText(profile.getServiceArea());
        if (profile.getBio() != null) etBio.setText(profile.getBio());
    }

    private void setupListeners() {
        btnVerifBack.setOnClickListener(v -> finish());
        btnSubmitVerification.setOnClickListener(v -> performSubmit());
    }

    private void performSubmit() {
        String idType = spinnerIdProofType.getSelectedItem().toString();
        String idNumber = etIdProofNumber.getText() != null ? etIdProofNumber.getText().toString().trim() : "";
        String category = spinnerTradeCategory.getSelectedItem().toString();
        String skills = etSkills.getText() != null ? etSkills.getText().toString().trim() : "";
        String expStr = etExperience.getText() != null ? etExperience.getText().toString().trim() : "1";
        String rateStr = etHourlyRate.getText() != null ? etHourlyRate.getText().toString().trim() : "250";
        String area = etServiceArea.getText() != null ? etServiceArea.getText().toString().trim() : "";
        String bio = etBio.getText() != null ? etBio.getText().toString().trim() : "";

        if (idNumber.length() < 4) {
            etIdProofNumber.setError("Please enter a valid document/license number");
            etIdProofNumber.requestFocus();
            return;
        }

        if (skills.isEmpty()) {
            etSkills.setError("Please specify your core skills");
            etSkills.requestFocus();
            return;
        }

        int exp = 1;
        try {
            exp = Integer.parseInt(expStr);
        } catch (Exception ignored) {}

        double rate = 200.0;
        try {
            rate = Double.parseDouble(rateStr);
        } catch (Exception ignored) {}

        long userId = sessionManager.getUserId();
        boolean ok = dbHelper.submitProviderVerification(
                userId, idType, idNumber, category, skills, exp, rate, area, bio
        );

        if (ok) {
            Toast.makeText(this, "Application submitted! Queued for administrative review.", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to submit verification.", Toast.LENGTH_SHORT).show();
        }
    }
}
