const http = require('http');
const app = require('../server');

let server;
const PORT = 5555;
const BASE_URL = `http://localhost:${PORT}`;

function request(method, path, body = null, token = null) {
    return new Promise((resolve, reject) => {
        const url = new URL(path, BASE_URL);
        const options = {
            hostname: url.hostname,
            port: url.port,
            path: url.pathname + url.search,
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        if (token) {
            options.headers['Authorization'] = `Bearer ${token}`;
        }

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve({ status: res.statusCode, body: parsed });
                } catch (e) {
                    resolve({ status: res.statusCode, body: data });
                }
            });
        });

        req.on('error', reject);
        if (body) {
            req.write(JSON.stringify(body));
        }
        req.end();
    });
}

async function runTests() {
    console.log('--- Starting FIXNEAR REST API Verification Tests ---');
    server = app.listen(PORT);

    let passed = 0;
    let failed = 0;

    function assert(condition, message) {
        if (condition) {
            console.log(`[PASS] ${message}`);
            passed++;
        } else {
            console.error(`[FAIL] ${message}`);
            failed++;
        }
    }

    try {
        // 1. Health check
        const health = await request('GET', '/api/health');
        assert(health.status === 200 && health.body.status === 'UP', 'Health check endpoint returns status 200 UP');

        // 2. Customer login
        const login = await request('POST', '/api/auth/login', {
            email: 'customer@fixnear.com',
            password: 'cust123'
        });
        assert(login.status === 200 && login.body.token, 'Customer login succeeds and issues JWT token');
        const customerToken = login.body.token;

        // 3. Admin login
        const adminLogin = await request('POST', '/api/auth/login', {
            email: 'admin@fixnear.com',
            password: 'admin123'
        });
        assert(adminLogin.status === 200 && adminLogin.body.user.role === 'ADMIN', 'Admin login verifies role ADMIN');
        const adminToken = adminLogin.body.token;

        // 4. Fetch providers
        const providers = await request('GET', '/api/providers');
        assert(providers.status === 200 && providers.body.count > 0, 'Fetch all providers returns status 200 and data array');

        // 5. Filter providers by category
        const acProviders = await request('GET', '/api/providers?category=AC%20Repair');
        assert(acProviders.status === 200 && acProviders.body.data.every(p => p.category.toLowerCase().includes('ac')),
            'Filtering by category returns only AC specialists');

        // 6. Security check: Customer cannot access Admin endpoints
        const forbiddenAdmin = await request('GET', '/api/admin/verifications', null, customerToken);
        assert(forbiddenAdmin.status === 403, 'Customer role is strictly forbidden from accessing /api/admin/verifications (HTTP 403)');

        // 7. Admin access to pending verifications
        const pendingVerif = await request('GET', '/api/admin/verifications', null, adminToken);
        assert(pendingVerif.status === 200 && Array.isArray(pendingVerif.body.data),
            'Admin can access pending compliance applications');

        // 8. Admin platform stats
        const stats = await request('GET', '/api/admin/stats', null, adminToken);
        assert(stats.status === 200 && stats.body.data.total_users > 0,
            'Admin stats endpoint returns aggregate metrics');

        // 9. Booking creation as customer
        const newBooking = await request('POST', '/api/bookings', {
            provider_id: 1,
            service_title: 'Socket and Fan Repair',
            problem_description: 'Bedroom switch sparks intermittently',
            service_address: 'Flat 102, Green Valley Apartments',
            scheduled_date: '2026-10-28',
            scheduled_time_slot: '11:00 AM - 01:00 PM',
            estimated_cost: 350.0
        }, customerToken);
        assert(newBooking.status === 201 && newBooking.body.data.booking_code,
            'Customer can create a service booking with generated FN code');

        // 10. Fetch customer bookings
        const myBookings = await request('GET', '/api/bookings', null, customerToken);
        assert(myBookings.status === 200 && myBookings.body.data.length > 0,
            'Customer can retrieve their persistent bookings');

    } catch (e) {
        console.error('Test execution error:', e);
        failed++;
    } finally {
        server.close();
        console.log(`\nTests Completed: ${passed} Passed, ${failed} Failed`);
        process.exit(failed > 0 ? 1 : 0);
    }
}

runTests();
