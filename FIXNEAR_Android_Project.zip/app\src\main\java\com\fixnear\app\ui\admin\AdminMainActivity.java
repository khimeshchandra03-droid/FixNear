package com.fixnear.app.ui.admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.ui.adapters.AdminVerificationAdapter;
import com.fixnear.app.ui.auth.LoginActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AdminMainActivity extends AppCompatActivity implements AdminVerificationAdapter.OnVerificationActionListener {

    private ImageView btnAdminLogout;
    private TextView tvAdminStatUsers, tvAdminStatVerified, tvAdminStatPending, tvAdminStatBookings;
    private RecyclerView rvAdminPendingVerifications;
    private TextView tvAdminEmptyQueue;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private AdminVerificationAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        initViews();
        setupRecyclerView();
        setupListeners();
        loadAdminData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAdminData();
    }

    private void initViews() {
        btnAdminLogout = findViewById(R.id.btnAdminLogout);
        tvAdminStatUsers = findViewById(R.id.tvAdminStatUsers);
        tvAdminStatVerified = findViewById(R.id.tvAdminStatVerified);
        tvAdminStatPending = findViewById(R.id.tvAdminStatPending);
        tvAdminStatBookings = findViewById(R.id.tvAdminStatBookings);
        rvAdminPendingVerifications = findViewById(R.id.rvAdminPendingVerifications);
        tvAdminEmptyQueue = findViewById(R.id.tvAdminEmptyQueue);
    }

    private void setupRecyclerView() {
        rvAdminPendingVerifications.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdminVerificationAdapter(this, new ArrayList<>(), this);
        rvAdminPendingVerifications.setAdapter(adapter);
    }

    private void setupListeners() {
        btnAdminLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Sign Out")
                    .setMessage("Log out from Administrator console?")
                    .setPositiveButton("Sign Out", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }

    private void loadAdminData() {
        // Platform Stats
        Map<String, Integer> stats = dbHelper.getPlatformStats();
        tvAdminStatUsers.setText(String.valueOf(stats.get("total_users")));
        tvAdminStatVerified.setText(String.valueOf(stats.get("verified_providers")));
        tvAdminStatPending.setText(String.valueOf(stats.get("pending_verifications")));
        tvAdminStatBookings.setText(String.valueOf(stats.get("total_bookings")));

        // Pending Applications
        List<ProviderProfile> pending = dbHelper.getPendingVerifications();
        adapter.updateList(pending);

        if (pending.isEmpty()) {
            tvAdminEmptyQueue.setVisibility(View.VISIBLE);
            rvAdminPendingVerifications.setVisibility(View.GONE);
        } else {
            tvAdminEmptyQueue.setVisibility(View.GONE);
            rvAdminPendingVerifications.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onApprove(ProviderProfile provider) {
        new AlertDialog.Builder(this)
                .setTitle("Approve Verification")
                .setMessage("Confirm government ID verification for " + provider.getName() + "?\n\n" +
                        "This will grant the official Verified badge, boost their Trust Score (+35 pts), and make them visible to customers.")
                .setPositiveButton("Approve", (dialog, which) -> {
                    boolean ok = dbHelper.adminApproveProvider(provider.getId());
                    if (ok) {
                        Toast.makeText(this, provider.getName() + " is now VERIFIED ✓", Toast.LENGTH_SHORT).show();
                        loadAdminData();
                    } else {
                        Toast.makeText(this, "Failed to approve provider.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onReject(ProviderProfile provider) {
        final EditText etReason = new EditText(this);
        etReason.setHint("e.g. Blurry ID photo or expired trade license");

        new AlertDialog.Builder(this)
                .setTitle("Reject Application")
                .setMessage("Enter the compliance feedback reason for " + provider.getName() + ":")
                .setView(etReason)
                .setPositiveButton("Reject Application", (dialog, which) -> {
                    String reason = etReason.getText().toString().trim();
                    boolean ok = dbHelper.adminRejectProvider(provider.getId(), reason);
                    if (ok) {
                        Toast.makeText(this, "Application rejected with feedback.", Toast.LENGTH_SHORT).show();
                        loadAdminData();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
