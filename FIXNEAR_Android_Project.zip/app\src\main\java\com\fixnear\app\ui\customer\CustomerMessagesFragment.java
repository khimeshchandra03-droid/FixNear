package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.ui.adapters.BookingAdapter;
import com.fixnear.app.ui.chat.ChatActivity;

import java.util.ArrayList;
import java.util.List;

public class CustomerMessagesFragment extends Fragment implements BookingAdapter.OnBookingClickListener {

    private RecyclerView rvConversations;
    private LinearLayout layoutEmptyState;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private BookingAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_customer_messages, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        rvConversations = view.findViewById(R.id.rvCustomerConversations);
        layoutEmptyState = view.findViewById(R.id.layoutMessagesEmptyState);

        rvConversations.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BookingAdapter(requireContext(), new ArrayList<>(), false, this);
        rvConversations.setAdapter(adapter);

        loadConversations();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadConversations();
    }

    private void loadConversations() {
        long customerId = sessionManager.getUserId();
        // Eligible bookings to message with
        List<Booking> all = dbHelper.getBookingsForCustomer(customerId, null);
        adapter.updateList(all);

        if (all.isEmpty()) {
            layoutEmptyState.setVisibility(View.VISIBLE);
            rvConversations.setVisibility(View.GONE);
        } else {
            layoutEmptyState.setVisibility(View.GONE);
            rvConversations.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBookingClick(Booking booking) {
        // Open Chat with the technician
        com.fixnear.app.model.ProviderProfile p = dbHelper.getProviderById(booking.getProviderId());
        if (p != null) {
            Intent intent = new Intent(requireContext(), ChatActivity.class);
            intent.putExtra("booking_id", booking.getId());
            intent.putExtra("other_user_id", p.getUserId());
            intent.putExtra("other_user_name", booking.getProviderName());
            startActivity(intent);
        }
    }
}
