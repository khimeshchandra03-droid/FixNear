package com.fixnear.app.ui.provider;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.adapters.BookingAdapter;
import com.fixnear.app.ui.booking.BookingDetailActivity;
import com.fixnear.app.ui.features.NotificationsActivity;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProviderDashboardFragment extends Fragment implements BookingAdapter.OnBookingClickListener {

    private TextView tvProviderGreeting, tvProviderSubGreeting;
    private ImageView btnProviderNotifs;
    private TextView tvVerificationBannerTitle, tvVerificationBannerBadge, tvVerificationBannerDesc;
    private MaterialButton btnManageVerification;
    private TextView tvStatCompletedJobs, tvStatRating, tvStatTrustScore;
    private TextView tvSeeAllProviderRequests, tvScheduleEmptyState;
    private RecyclerView rvProviderSchedule;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private BookingAdapter adapter;
    private ProviderProfile profile;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_provider_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupListeners();
        loadDashboardData();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void initViews(View view) {
        tvProviderGreeting = view.findViewById(R.id.tvProviderGreeting);
        tvProviderSubGreeting = view.findViewById(R.id.tvProviderSubGreeting);
        btnProviderNotifs = view.findViewById(R.id.btnProviderNotifs);
        tvVerificationBannerTitle = view.findViewById(R.id.tvVerificationBannerTitle);
        tvVerificationBannerBadge = view.findViewById(R.id.tvVerificationBannerBadge);
        tvVerificationBannerDesc = view.findViewById(R.id.tvVerificationBannerDesc);
        btnManageVerification = view.findViewById(R.id.btnManageVerification);
        tvStatCompletedJobs = view.findViewById(R.id.tvStatCompletedJobs);
        tvStatRating = view.findViewById(R.id.tvStatRating);
        tvStatTrustScore = view.findViewById(R.id.tvStatTrustScore);
        tvSeeAllProviderRequests = view.findViewById(R.id.tvSeeAllProviderRequests);
        tvScheduleEmptyState = view.findViewById(R.id.tvScheduleEmptyState);
        rvProviderSchedule = view.findViewById(R.id.rvProviderSchedule);
    }

    private void setupRecyclerView() {
        rvProviderSchedule.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BookingAdapter(requireContext(), new ArrayList<>(), true, this);
        rvProviderSchedule.setAdapter(adapter);
    }

    private void setupListeners() {
        btnProviderNotifs.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), NotificationsActivity.class));
        });

        btnManageVerification.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), VerificationActivity.class));
        });

        tvSeeAllProviderRequests.setOnClickListener(v -> {
            if (getActivity() instanceof ProviderMainActivity) {
                ((ProviderMainActivity) getActivity()).navigateToRequests();
            }
        });
    }

    private void loadDashboardData() {
        long userId = sessionManager.getUserId();
        profile = dbHelper.getProviderByUserId(userId);
        User user = sessionManager.getCurrentUser();

        if (user != null) {
            tvProviderGreeting.setText("Welcome, " + user.getName() + " 👋");
        }

        if (profile == null) return;

        tvProviderSubGreeting.setText(profile.getCategory() + " Specialist • " +
                (profile.isAvailable() ? "Active Online" : "Currently Offline"));

        // Verification banner
        if (profile.isVerified()) {
            tvVerificationBannerTitle.setText("Verification Status: Active");
            tvVerificationBannerBadge.setText("VERIFIED");
            tvVerificationBannerBadge.setBackgroundResource(R.drawable.bg_badge_verified);
            tvVerificationBannerBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.badge_verified));
            tvVerificationBannerDesc.setText("Your Govt ID has been verified by FIXNEAR administrators. Your profile displays the Verified badge to all customers.");
            btnManageVerification.setText("View Verified Credentials");
        } else if (profile.isPendingReview()) {
            tvVerificationBannerTitle.setText("Verification Status: Under Review");
            tvVerificationBannerBadge.setText("PENDING");
            tvVerificationBannerBadge.setBackgroundResource(R.drawable.bg_badge_pending);
            tvVerificationBannerBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_pending));
            tvVerificationBannerDesc.setText("Your ID application (" + profile.getIdProofType() + ") has been received and is queued for administrative compliance audit.");
            btnManageVerification.setText("Update Submitted Documents");
        } else if (ProviderProfile.STATUS_REJECTED.equalsIgnoreCase(profile.getVerificationStatus())) {
            tvVerificationBannerTitle.setText("Verification Action Required");
            tvVerificationBannerBadge.setText("REJECTED");
            tvVerificationBannerBadge.setBackgroundResource(R.drawable.bg_badge_pending);
            tvVerificationBannerBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.status_cancelled));
            tvVerificationBannerDesc.setText("Feedback: " + (profile.getRejectionReason() != null ? profile.getRejectionReason() : "Please resubmit clear document photo."));
            btnManageVerification.setText("Resubmit Identification");
        } else {
            tvVerificationBannerTitle.setText("Identity Not Verified");
            tvVerificationBannerBadge.setText("UNVERIFIED");
            tvVerificationBannerBadge.setBackgroundResource(R.drawable.bg_badge_unverified);
            tvVerificationBannerBadge.setTextColor(ContextCompat.getColor(requireContext(), R.color.badge_unverified));
            tvVerificationBannerDesc.setText("Submit government ID (Aadhaar, PAN, or Trade License) to gain verified trust, priority ranking, and unlock customer bookings.");
            btnManageVerification.setText("Submit ID Verification Now");
        }

        // Stats
        tvStatCompletedJobs.setText(String.valueOf(profile.getCompletedJobs()));
        tvStatRating.setText(String.format(Locale.getDefault(), "%.1f ★", profile.getRatingAvg()));
        tvStatTrustScore.setText(profile.getTrustScore() + "/100");

        // Schedule list
        List<Booking> allJobs = dbHelper.getBookingsForProvider(profile.getId(), null);
        List<Booking> upcoming = new ArrayList<>();
        for (Booking b : allJobs) {
            if (b.isPending() || b.isAccepted() || b.isScheduled() || b.isInProgress()) {
                upcoming.add(b);
            }
        }

        adapter.updateList(upcoming);
        if (upcoming.isEmpty()) {
            tvScheduleEmptyState.setVisibility(View.VISIBLE);
            rvProviderSchedule.setVisibility(View.GONE);
        } else {
            tvScheduleEmptyState.setVisibility(View.GONE);
            rvProviderSchedule.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBookingClick(Booking booking) {
        Intent intent = new Intent(requireContext(), BookingDetailActivity.class);
        intent.putExtra("booking_id", booking.getId());
        startActivity(intent);
    }
}
