package com.fixnear.app.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.fixnear.app.model.User;

public class SessionManager {
    private static final String PREF_NAME = "FixNearSession";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_NAME = "name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_ROLE = "role";
    private static final String KEY_PHOTO = "photo";
    private static final String KEY_CREATED_AT = "createdAt";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void saveUserSession(User user) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putLong(KEY_USER_ID, user.getId());
        editor.putString(KEY_NAME, user.getName());
        editor.putString(KEY_EMAIL, user.getEmail());
        editor.putString(KEY_PHONE, user.getPhone());
        editor.putString(KEY_ROLE, user.getRole());
        editor.putString(KEY_PHOTO, user.getProfilePhoto());
        editor.putString(KEY_CREATED_AT, user.getCreatedAt());
        editor.apply();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public User getCurrentUser() {
        if (!isLoggedIn()) return null;
        User user = new User();
        user.setId(pref.getLong(KEY_USER_ID, -1));
        user.setName(pref.getString(KEY_NAME, ""));
        user.setEmail(pref.getString(KEY_EMAIL, ""));
        user.setPhone(pref.getString(KEY_PHONE, ""));
        user.setRole(pref.getString(KEY_ROLE, User.ROLE_CUSTOMER));
        user.setProfilePhoto(pref.getString(KEY_PHOTO, ""));
        user.setCreatedAt(pref.getString(KEY_CREATED_AT, ""));
        return user;
    }

    public long getUserId() {
        return pref.getLong(KEY_USER_ID, -1);
    }

    public String getUserRole() {
        return pref.getString(KEY_ROLE, User.ROLE_CUSTOMER);
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
