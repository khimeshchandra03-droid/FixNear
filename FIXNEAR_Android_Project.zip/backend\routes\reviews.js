const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

// POST /api/reviews
router.post('/', requireAuth, async (req, res) => {
    try {
        const { booking_id, provider_id, rating, review_text } = req.body;

        if (!booking_id || !provider_id || !rating) {
            return res.status(400).json({ success: false, error: 'Booking ID, provider ID, and rating are required' });
        }

        const existing = await db.getAsync('SELECT id FROM reviews WHERE booking_id = ?', [booking_id]);
        if (existing) {
            return res.status(409).json({ success: false, error: 'Review already submitted for this booking' });
        }

        await db.runAsync(`
            INSERT INTO reviews (booking_id, customer_id, provider_id, rating, review_text)
            VALUES (?, ?, ?, ?, ?)
        `, [booking_id, req.user.id, provider_id, rating, review_text || '']);

        // Update provider rating average
        const stats = await db.getAsync(`
            SELECT AVG(rating) as avg_r, COUNT(id) as cnt_r FROM reviews WHERE provider_id = ?
        `, [provider_id]);

        await db.runAsync(`
            UPDATE provider_profiles
            SET rating_avg = ROUND(?, 1), rating_count = ?
            WHERE id = ?
        `, [stats.avg_r, stats.cnt_r, provider_id]);

        res.status(201).json({ success: true, message: 'Review recorded successfully' });
    } catch (err) {
        console.error('Review error:', err);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// GET /api/reviews/provider/:id
router.get('/provider/:id', async (req, res) => {
    try {
        const reviews = await db.query(`
            SELECT r.*, u.name AS customer_name
            FROM reviews r
            JOIN users u ON r.customer_id = u.id
            WHERE r.provider_id = ?
            ORDER BY r.id DESC
        `, [req.params.id]);

        res.json({ success: true, count: reviews.length, data: reviews });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

module.exports = router;
