package com.fixnear.app.model;

import java.io.Serializable;

public class Message implements Serializable {
    private long id;
    private long bookingId;
    private long senderId;
    private String senderName;
    private long receiverId;
    private String messageText;
    private boolean isRead;
    private String timestamp;

    public Message() {}

    public Message(long id, long bookingId, long senderId, String senderName, long receiverId,
                   String messageText, boolean isRead, String timestamp) {
        this.id = id;
        this.bookingId = bookingId;
        this.senderId = senderId;
        this.senderName = senderName;
        this.receiverId = receiverId;
        this.messageText = messageText;
        this.isRead = isRead;
        this.timestamp = timestamp;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getBookingId() { return bookingId; }
    public void setBookingId(long bookingId) { this.bookingId = bookingId; }

    public long getSenderId() { return senderId; }
    public void setSenderId(long senderId) { this.senderId = senderId; }

    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }

    public long getReceiverId() { return receiverId; }
    public void setReceiverId(long receiverId) { this.receiverId = receiverId; }

    public String getMessageText() { return messageText; }
    public void setMessageText(String messageText) { this.messageText = messageText; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
