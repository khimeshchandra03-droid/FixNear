package com.fixnear.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SecurityUtils;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.customer.CustomerMainActivity;
import com.fixnear.app.ui.provider.ProviderMainActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPhone, etPassword;
    private RadioButton rbCustomer, rbProvider;
    private MaterialButton btnRegister;
    private TextView tvGoToLogin;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        rbCustomer = findViewById(R.id.rbCustomer);
        rbProvider = findViewById(R.id.rbProvider);
        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);
    }

    private void setupListeners() {
        btnRegister.setOnClickListener(v -> performRegister());
        tvGoToLogin.setOnClickListener(v -> finish());
    }

    private void performRegister() {
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";
        String role = rbProvider.isChecked() ? User.ROLE_PROVIDER : User.ROLE_CUSTOMER;

        if (name.isEmpty() || name.length() < 2) {
            etName.setError("Please enter your full name (at least 2 characters)");
            etName.requestFocus();
            return;
        }

        if (email.isEmpty() || !SecurityUtils.isValidEmail(email)) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            return;
        }

        if (phone.isEmpty() || !SecurityUtils.isValidPhone(phone)) {
            etPhone.setError("Please enter a valid 10-digit phone number");
            etPhone.requestFocus();
            return;
        }

        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            etPassword.requestFocus();
            return;
        }

        long userId = dbHelper.registerUser(name, email, password, phone, role);
        if (userId == -1) {
            Toast.makeText(this, "An account with this email already exists. Please sign in.", Toast.LENGTH_LONG).show();
            return;
        }

        User newUser = dbHelper.getUserById(userId);
        if (newUser != null) {
            sessionManager.saveUserSession(newUser);
            Toast.makeText(this, "Account created successfully! Welcome, " + name, Toast.LENGTH_SHORT).show();

            Intent intent;
            if (newUser.isProvider()) {
                intent = new Intent(this, ProviderMainActivity.class);
            } else {
                intent = new Intent(this, CustomerMainActivity.class);
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
    }
}
