package com.fixnear.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.fixnear.app.engine.TrustScoreCalculator;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.BookingTimelineEvent;
import com.fixnear.app.model.Message;
import com.fixnear.app.model.NotificationItem;
import com.fixnear.app.model.PortfolioItem;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.ReportItem;
import com.fixnear.app.model.Review;
import com.fixnear.app.model.ServiceItem;
import com.fixnear.app.model.User;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "fixnear.db";
    public static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_PROVIDERS = "provider_profiles";
    public static final String TABLE_SERVICES = "services";
    public static final String TABLE_BOOKINGS = "bookings";
    public static final String TABLE_TIMELINE = "booking_timeline";
    public static final String TABLE_REVIEWS = "reviews";
    public static final String TABLE_FAVORITES = "favorites";
    public static final String TABLE_MESSAGES = "messages";
    public static final String TABLE_NOTIFICATIONS = "notifications";
    public static final String TABLE_REPORTS = "reports";
    public static final String TABLE_PORTFOLIO = "provider_portfolio";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users Table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "email TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "salt TEXT NOT NULL, " +
                "phone TEXT, " +
                "role TEXT NOT NULL, " +
                "profile_photo TEXT, " +
                "created_at TEXT NOT NULL)");

        // Provider Profiles Table
        db.execSQL("CREATE TABLE " + TABLE_PROVIDERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER UNIQUE NOT NULL, " +
                "category TEXT NOT NULL, " +
                "skills TEXT, " +
                "experience_years INTEGER DEFAULT 1, " +
                "hourly_rate REAL DEFAULT 200.0, " +
                "service_area TEXT, " +
                "bio TEXT, " +
                "verification_status TEXT DEFAULT 'NOT_SUBMITTED', " +
                "id_proof_type TEXT, " +
                "id_proof_number TEXT, " +
                "id_proof_document TEXT, " +
                "rejection_reason TEXT, " +
                "rating_avg REAL DEFAULT 0.0, " +
                "rating_count INTEGER DEFAULT 0, " +
                "completed_jobs INTEGER DEFAULT 0, " +
                "cancelled_jobs INTEGER DEFAULT 0, " +
                "trust_score INTEGER DEFAULT 20, " +
                "is_available INTEGER DEFAULT 1, " +
                "created_at TEXT NOT NULL, " +
                "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE)");

        // Services Table
        db.execSQL("CREATE TABLE " + TABLE_SERVICES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT NOT NULL, " +
                "service_name TEXT NOT NULL, " +
                "base_inspection_fee REAL NOT NULL, " +
                "estimated_labor_min REAL NOT NULL, " +
                "estimated_labor_max REAL NOT NULL, " +
                "description TEXT, " +
                "icon_name TEXT)");

        // Bookings Table
        db.execSQL("CREATE TABLE " + TABLE_BOOKINGS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "booking_code TEXT UNIQUE NOT NULL, " +
                "customer_id INTEGER NOT NULL, " +
                "provider_id INTEGER NOT NULL, " +
                "service_id INTEGER NOT NULL, " +
                "service_title TEXT NOT NULL, " +
                "problem_description TEXT NOT NULL, " +
                "service_address TEXT NOT NULL, " +
                "scheduled_date TEXT NOT NULL, " +
                "scheduled_time_slot TEXT NOT NULL, " +
                "estimated_cost REAL NOT NULL, " +
                "final_cost REAL DEFAULT 0.0, " +
                "status TEXT NOT NULL, " +
                "rejection_reason TEXT, " +
                "cancellation_reason TEXT, " +
                "created_at TEXT NOT NULL, " +
                "updated_at TEXT NOT NULL, " +
                "FOREIGN KEY (customer_id) REFERENCES users(id), " +
                "FOREIGN KEY (provider_id) REFERENCES provider_profiles(id))");

        // Timeline Table
        db.execSQL("CREATE TABLE " + TABLE_TIMELINE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "booking_id INTEGER NOT NULL, " +
                "status TEXT NOT NULL, " +
                "title TEXT NOT NULL, " +
                "description TEXT, " +
                "timestamp TEXT NOT NULL, " +
                "FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE)");

        // Reviews Table
        db.execSQL("CREATE TABLE " + TABLE_REVIEWS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "booking_id INTEGER UNIQUE NOT NULL, " +
                "customer_id INTEGER NOT NULL, " +
                "provider_id INTEGER NOT NULL, " +
                "rating REAL NOT NULL, " +
                "review_text TEXT, " +
                "created_at TEXT NOT NULL, " +
                "FOREIGN KEY (booking_id) REFERENCES bookings(id), " +
                "FOREIGN KEY (customer_id) REFERENCES users(id), " +
                "FOREIGN KEY (provider_id) REFERENCES provider_profiles(id))");

        // Favorites Table
        db.execSQL("CREATE TABLE " + TABLE_FAVORITES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "customer_id INTEGER NOT NULL, " +
                "provider_id INTEGER NOT NULL, " +
                "created_at TEXT NOT NULL, " +
                "UNIQUE(customer_id, provider_id), " +
                "FOREIGN KEY (customer_id) REFERENCES users(id), " +
                "FOREIGN KEY (provider_id) REFERENCES provider_profiles(id))");

        // Messages Table
        db.execSQL("CREATE TABLE " + TABLE_MESSAGES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "booking_id INTEGER, " +
                "sender_id INTEGER NOT NULL, " +
                "receiver_id INTEGER NOT NULL, " +
                "message_text TEXT NOT NULL, " +
                "is_read INTEGER DEFAULT 0, " +
                "timestamp TEXT NOT NULL, " +
                "FOREIGN KEY (sender_id) REFERENCES users(id), " +
                "FOREIGN KEY (receiver_id) REFERENCES users(id))");

        // Notifications Table
        db.execSQL("CREATE TABLE " + TABLE_NOTIFICATIONS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "message TEXT NOT NULL, " +
                "type TEXT NOT NULL, " +
                "related_id INTEGER, " +
                "is_read INTEGER DEFAULT 0, " +
                "timestamp TEXT NOT NULL, " +
                "FOREIGN KEY (user_id) REFERENCES users(id))");

        // Reports Table
        db.execSQL("CREATE TABLE " + TABLE_REPORTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "reporter_id INTEGER NOT NULL, " +
                "reported_user_id INTEGER NOT NULL, " +
                "booking_id INTEGER, " +
                "reason TEXT NOT NULL, " +
                "details TEXT, " +
                "status TEXT DEFAULT 'OPEN', " +
                "admin_notes TEXT, " +
                "timestamp TEXT NOT NULL, " +
                "FOREIGN KEY (reporter_id) REFERENCES users(id), " +
                "FOREIGN KEY (reported_user_id) REFERENCES users(id))");

        // Portfolio Table
        db.execSQL("CREATE TABLE " + TABLE_PORTFOLIO + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "provider_id INTEGER NOT NULL, " +
                "title TEXT NOT NULL, " +
                "before_description TEXT, " +
                "after_description TEXT, " +
                "category TEXT, " +
                "created_at TEXT NOT NULL, " +
                "FOREIGN KEY (provider_id) REFERENCES provider_profiles(id))");

        seedInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PORTFOLIO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTIFICATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVORITES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REVIEWS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TIMELINE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROVIDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    private String getCurrentTimestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    // ==========================================
    // AUTH & USER OPERATIONS
    // ==========================================

    public long registerUser(String name, String email, String password, String phone, String role) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if email already exists
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_USERS + " WHERE LOWER(email) = LOWER(?)",
                new String[]{email.trim()});
        if (cursor.getCount() > 0) {
            cursor.close();
            return -1; // Duplicate email
        }
        cursor.close();

        String salt = SecurityUtils.generateSalt();
        String hash = SecurityUtils.hashPassword(password, salt);
        String now = getCurrentTimestamp();

        ContentValues values = new ContentValues();
        values.put("name", name.trim());
        values.put("email", email.trim().toLowerCase());
        values.put("password_hash", hash);
        values.put("salt", salt);
        values.put("phone", phone.trim());
        values.put("role", role);
        values.put("profile_photo", "");
        values.put("created_at", now);

        long userId = db.insert(TABLE_USERS, null, values);

        if (userId != -1 && User.ROLE_PROVIDER.equalsIgnoreCase(role)) {
            // Create initial pending provider profile
            ContentValues pValues = new ContentValues();
            pValues.put("user_id", userId);
            pValues.put("category", "Electrical"); // Default initial category
            pValues.put("skills", "General Troubleshooting");
            pValues.put("experience_years", 1);
            pValues.put("hourly_rate", 250.0);
            pValues.put("service_area", "Central District");
            pValues.put("bio", "Certified repair technician dedicated to reliable service.");
            pValues.put("verification_status", ProviderProfile.STATUS_NOT_SUBMITTED);
            pValues.put("rating_avg", 0.0);
            pValues.put("rating_count", 0);
            pValues.put("completed_jobs", 0);
            pValues.put("cancelled_jobs", 0);
            pValues.put("trust_score", 20);
            pValues.put("is_available", 1);
            pValues.put("created_at", now);
            db.insert(TABLE_PROVIDERS, null, pValues);
        }

        // Welcome notification
        addNotification(userId, "Welcome to FIXNEAR",
                "Your account has been created successfully. Explore verified local repair professionals anytime.",
                NotificationItem.TYPE_SYSTEM, userId);

        return userId;
    }

    public User authenticateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE LOWER(email) = LOWER(?)",
                new String[]{email.trim()});

        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow("password_hash"));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow("salt"));

            if (SecurityUtils.verifyPassword(password, storedHash, salt)) {
                User user = new User(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                        cursor.getString(cursor.getColumnIndexOrThrow("role")),
                        cursor.getString(cursor.getColumnIndexOrThrow("profile_photo")),
                        cursor.getString(cursor.getColumnIndexOrThrow("created_at"))
                );
                cursor.close();
                return user;
            }
        }
        cursor.close();
        return null;
    }

    public User getUserById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE id = ?", new String[]{String.valueOf(userId)});
        User user = null;
        if (cursor.moveToFirst()) {
            user = new User(
                    cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                    cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    cursor.getString(cursor.getColumnIndexOrThrow("email")),
                    cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                    cursor.getString(cursor.getColumnIndexOrThrow("role")),
                    cursor.getString(cursor.getColumnIndexOrThrow("profile_photo")),
                    cursor.getString(cursor.getColumnIndexOrThrow("created_at"))
            );
        }
        cursor.close();
        return user;
    }

    // ==========================================
    // PROVIDER PROFILE & VERIFICATION
    // ==========================================

    public ProviderProfile getProviderByUserId(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.*, u.name, u.email, u.phone, u.profile_photo " +
                "FROM " + TABLE_PROVIDERS + " p " +
                "JOIN " + TABLE_USERS + " u ON p.user_id = u.id " +
                "WHERE p.user_id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
        ProviderProfile profile = null;
        if (cursor.moveToFirst()) {
            profile = cursorToProviderProfile(cursor);
        }
        cursor.close();
        return profile;
    }

    public ProviderProfile getProviderById(long providerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.*, u.name, u.email, u.phone, u.profile_photo " +
                "FROM " + TABLE_PROVIDERS + " p " +
                "JOIN " + TABLE_USERS + " u ON p.user_id = u.id " +
                "WHERE p.id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(providerId)});
        ProviderProfile profile = null;
        if (cursor.moveToFirst()) {
            profile = cursorToProviderProfile(cursor);
        }
        cursor.close();
        return profile;
    }

    public boolean submitProviderVerification(long userId, String idProofType, String idProofNumber,
                                              String category, String skills, int experienceYears,
                                              double hourlyRate, String serviceArea, String bio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("id_proof_type", idProofType);
        cv.put("id_proof_number", idProofNumber);
        cv.put("category", category);
        cv.put("skills", skills);
        cv.put("experience_years", experienceYears);
        cv.put("hourly_rate", hourlyRate);
        cv.put("service_area", serviceArea);
        cv.put("bio", bio);
        cv.put("verification_status", ProviderProfile.STATUS_PENDING_REVIEW);
        cv.put("rejection_reason", "");

        int rows = db.update(TABLE_PROVIDERS, cv, "user_id = ?", new String[]{String.valueOf(userId)});

        if (rows > 0) {
            // Notification for provider
            addNotification(userId, "Verification Submitted",
                    "Your identity verification request has been received and is queued for administrative audit.",
                    NotificationItem.TYPE_VERIFICATION, userId);
            return true;
        }
        return false;
    }

    public boolean adminApproveProvider(long providerId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("verification_status", ProviderProfile.STATUS_VERIFIED);
        cv.put("rejection_reason", "");
        int rows = db.update(TABLE_PROVIDERS, cv, "id = ?", new String[]{String.valueOf(providerId)});

        if (rows > 0) {
            ProviderProfile profile = getProviderById(providerId);
            if (profile != null) {
                // Update trust score
                int newTrustScore = TrustScoreCalculator.calculate(profile).getTotalScore();
                ContentValues scoreCv = new ContentValues();
                scoreCv.put("trust_score", newTrustScore);
                db.update(TABLE_PROVIDERS, scoreCv, "id = ?", new String[]{String.valueOf(providerId)});

                addNotification(profile.getUserId(), "Verification Approved!",
                        "Congratulations! Your government ID has been verified. You now have the official Verified badge and boosted Trust Score.",
                        NotificationItem.TYPE_VERIFICATION, providerId);
            }
            return true;
        }
        return false;
    }

    public boolean adminRejectProvider(long providerId, String reason) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("verification_status", ProviderProfile.STATUS_REJECTED);
        cv.put("rejection_reason", reason != null ? reason : "Documents unclear or failed compliance check");
        int rows = db.update(TABLE_PROVIDERS, cv, "id = ?", new String[]{String.valueOf(providerId)});

        if (rows > 0) {
            ProviderProfile profile = getProviderById(providerId);
            if (profile != null) {
                int newTrustScore = TrustScoreCalculator.calculate(profile).getTotalScore();
                ContentValues scoreCv = new ContentValues();
                scoreCv.put("trust_score", newTrustScore);
                db.update(TABLE_PROVIDERS, scoreCv, "id = ?", new String[]{String.valueOf(providerId)});

                addNotification(profile.getUserId(), "Verification Action Required",
                        "Your verification application was not approved. Reason: " + reason,
                        NotificationItem.TYPE_VERIFICATION, providerId);
            }
            return true;
        }
        return false;
    }

    public List<ProviderProfile> getPendingVerifications() {
        List<ProviderProfile> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.*, u.name, u.email, u.phone, u.profile_photo " +
                "FROM " + TABLE_PROVIDERS + " p " +
                "JOIN " + TABLE_USERS + " u ON p.user_id = u.id " +
                "WHERE p.verification_status = '" + ProviderProfile.STATUS_PENDING_REVIEW + "' " +
                "ORDER BY p.id DESC";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                list.add(cursorToProviderProfile(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public List<ProviderProfile> getAllProviders(long currentCustomerId) {
        List<ProviderProfile> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.*, u.name, u.email, u.phone, u.profile_photo " +
                "FROM " + TABLE_PROVIDERS + " p " +
                "JOIN " + TABLE_USERS + " u ON p.user_id = u.id " +
                "ORDER BY p.trust_score DESC, p.rating_avg DESC";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                ProviderProfile profile = cursorToProviderProfile(cursor);
                if (currentCustomerId > 0) {
                    profile.setFavorite(isFavorite(currentCustomerId, profile.getId()));
                }
                list.add(profile);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public List<ProviderProfile> searchAndFilterProviders(String queryText, String category,
                                                          float minRating, double maxPrice,
                                                          boolean verifiedOnly, String sortBy,
                                                          long currentCustomerId) {
        List<ProviderProfile> all = getAllProviders(currentCustomerId);
        List<ProviderProfile> filtered = new ArrayList<>();

        String q = queryText != null ? queryText.trim().toLowerCase() : "";

        for (ProviderProfile p : all) {
            // Text search match: name, category, skills, bio
            if (!q.isEmpty()) {
                boolean matchesText = (p.getName() != null && p.getName().toLowerCase().contains(q)) ||
                        (p.getCategory() != null && p.getCategory().toLowerCase().contains(q)) ||
                        (p.getSkills() != null && p.getSkills().toLowerCase().contains(q)) ||
                        (p.getBio() != null && p.getBio().toLowerCase().contains(q));
                if (!matchesText) continue;
            }

            // Category filter
            if (category != null && !category.isEmpty() && !category.equalsIgnoreCase("All")) {
                if (!category.equalsIgnoreCase(p.getCategory())) {
                    continue;
                }
            }

            // Rating filter
            if (minRating > 0 && p.getRatingAvg() < minRating) {
                continue;
            }

            // Price filter
            if (maxPrice > 0 && p.getHourlyRate() > maxPrice) {
                continue;
            }

            // Verification filter
            if (verifiedOnly && !p.isVerified()) {
                continue;
            }

            filtered.add(p);
        }

        // Sorting
        if ("PRICE_LOW_HIGH".equalsIgnoreCase(sortBy)) {
            Collections.sort(filtered, new Comparator<ProviderProfile>() {
                @Override
                public int compare(ProviderProfile a, ProviderProfile b) {
                    return Double.compare(a.getHourlyRate(), b.getHourlyRate());
                }
            });
        } else if ("PRICE_HIGH_LOW".equalsIgnoreCase(sortBy)) {
            Collections.sort(filtered, new Comparator<ProviderProfile>() {
                @Override
                public int compare(ProviderProfile a, ProviderProfile b) {
                    return Double.compare(b.getHourlyRate(), a.getHourlyRate());
                }
            });
        } else if ("RATING".equalsIgnoreCase(sortBy)) {
            Collections.sort(filtered, new Comparator<ProviderProfile>() {
                @Override
                public int compare(ProviderProfile a, ProviderProfile b) {
                    return Double.compare(b.getRatingAvg(), a.getRatingAvg());
                }
            });
        } else {
            // Default: TRUST_SCORE
            Collections.sort(filtered, new Comparator<ProviderProfile>() {
                @Override
                public int compare(ProviderProfile a, ProviderProfile b) {
                    return Integer.compare(b.getTrustScore(), a.getTrustScore());
                }
            });
        }

        return filtered;
    }

    private ProviderProfile cursorToProviderProfile(Cursor cursor) {
        ProviderProfile p = new ProviderProfile();
        p.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        p.setUserId(cursor.getLong(cursor.getColumnIndexOrThrow("user_id")));
        p.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
        p.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        p.setPhone(cursor.getString(cursor.getColumnIndexOrThrow("phone")));
        p.setProfilePhoto(cursor.getString(cursor.getColumnIndexOrThrow("profile_photo")));
        p.setCategory(cursor.getString(cursor.getColumnIndexOrThrow("category")));
        p.setSkills(cursor.getString(cursor.getColumnIndexOrThrow("skills")));
        p.setExperienceYears(cursor.getInt(cursor.getColumnIndexOrThrow("experience_years")));
        p.setHourlyRate(cursor.getDouble(cursor.getColumnIndexOrThrow("hourly_rate")));
        p.setServiceArea(cursor.getString(cursor.getColumnIndexOrThrow("service_area")));
        p.setBio(cursor.getString(cursor.getColumnIndexOrThrow("bio")));
        p.setVerificationStatus(cursor.getString(cursor.getColumnIndexOrThrow("verification_status")));
        p.setIdProofType(cursor.getString(cursor.getColumnIndexOrThrow("id_proof_type")));
        p.setIdProofNumber(cursor.getString(cursor.getColumnIndexOrThrow("id_proof_number")));
        p.setIdProofDocument(cursor.getString(cursor.getColumnIndexOrThrow("id_proof_document")));
        p.setRejectionReason(cursor.getString(cursor.getColumnIndexOrThrow("rejection_reason")));
        p.setRatingAvg(cursor.getDouble(cursor.getColumnIndexOrThrow("rating_avg")));
        p.setRatingCount(cursor.getInt(cursor.getColumnIndexOrThrow("rating_count")));
        p.setCompletedJobs(cursor.getInt(cursor.getColumnIndexOrThrow("completed_jobs")));
        p.setCancelledJobs(cursor.getInt(cursor.getColumnIndexOrThrow("cancelled_jobs")));
        p.setTrustScore(cursor.getInt(cursor.getColumnIndexOrThrow("trust_score")));
        p.setAvailable(cursor.getInt(cursor.getColumnIndexOrThrow("is_available")) == 1);
        p.setCreatedAt(cursor.getString(cursor.getColumnIndexOrThrow("created_at")));
        return p;
    }

    // ==========================================
    // SERVICES CATALOG
    // ==========================================

    public List<ServiceItem> getServicesByCategory(String category) {
        List<ServiceItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;
        if (category == null || category.isEmpty() || category.equalsIgnoreCase("All")) {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_SERVICES + " ORDER BY category ASC", null);
        } else {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_SERVICES + " WHERE category = ?", new String[]{category});
        }
        if (cursor.moveToFirst()) {
            do {
                list.add(new ServiceItem(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("category")),
                        cursor.getString(cursor.getColumnIndexOrThrow("service_name")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("base_inspection_fee")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("estimated_labor_min")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("estimated_labor_max")),
                        cursor.getString(cursor.getColumnIndexOrThrow("description")),
                        cursor.getString(cursor.getColumnIndexOrThrow("icon_name"))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // BOOKINGS WORKFLOW & TIMELINE
    // ==========================================

    public long createBooking(long customerId, long providerId, long serviceId, String serviceTitle,
                              String problemDescription, String serviceAddress, String scheduledDate,
                              String scheduledTimeSlot, double estimatedCost) {
        SQLiteDatabase db = this.getWritableDatabase();

        String code = "FN-" + (10000 + new Random().nextInt(90000));
        String now = getCurrentTimestamp();

        ContentValues cv = new ContentValues();
        cv.put("booking_code", code);
        cv.put("customer_id", customerId);
        cv.put("provider_id", providerId);
        cv.put("service_id", serviceId);
        cv.put("service_title", serviceTitle);
        cv.put("problem_description", problemDescription);
        cv.put("service_address", serviceAddress);
        cv.put("scheduled_date", scheduledDate);
        cv.put("scheduled_time_slot", scheduledTimeSlot);
        cv.put("estimated_cost", estimatedCost);
        cv.put("final_cost", estimatedCost);
        cv.put("status", Booking.STATUS_PENDING);
        cv.put("rejection_reason", "");
        cv.put("cancellation_reason", "");
        cv.put("created_at", now);
        cv.put("updated_at", now);

        long bookingId = db.insert(TABLE_BOOKINGS, null, cv);

        if (bookingId != -1) {
            // Initial Timeline Event
            addTimelineEvent(bookingId, Booking.STATUS_PENDING, "Booking Request Submitted",
                    "Customer requested repair service. Awaiting professional acceptance.", now);

            // Notify Provider
            ProviderProfile provider = getProviderById(providerId);
            if (provider != null) {
                addNotification(provider.getUserId(), "New Booking Request!",
                        "New repair request (" + code + ") for " + serviceTitle + " on " + scheduledDate + ".",
                        NotificationItem.TYPE_BOOKING, bookingId);
            }

            // Notify Customer
            addNotification(customerId, "Booking Placed Successfully",
                    "Your repair request " + code + " has been sent to the professional.",
                    NotificationItem.TYPE_BOOKING, bookingId);
        }

        return bookingId;
    }

    public boolean updateBookingStatus(long bookingId, String newStatus, String reason, String actorRole) {
        SQLiteDatabase db = this.getWritableDatabase();
        Booking booking = getBookingById(bookingId);
        if (booking == null) return false;

        // Validation of status transitions
        if (!isValidStatusTransition(booking.getStatus(), newStatus, actorRole)) {
            return false;
        }

        String now = getCurrentTimestamp();
        ContentValues cv = new ContentValues();
        cv.put("status", newStatus);
        cv.put("updated_at", now);

        if (Booking.STATUS_REJECTED.equalsIgnoreCase(newStatus)) {
            cv.put("rejection_reason", reason);
        } else if (Booking.STATUS_CANCELLED.equalsIgnoreCase(newStatus)) {
            cv.put("cancellation_reason", reason);
        }

        int rows = db.update(TABLE_BOOKINGS, cv, "id = ?", new String[]{String.valueOf(bookingId)});

        if (rows > 0) {
            String timelineTitle;
            String timelineDesc;
            switch (newStatus) {
                case Booking.STATUS_ACCEPTED:
                    timelineTitle = "Booking Accepted";
                    timelineDesc = "The repair professional has confirmed your appointment.";
                    break;
                case Booking.STATUS_SCHEDULED:
                    timelineTitle = "Technician Scheduled";
                    timelineDesc = "Appointment locked for " + booking.getScheduledDate() + " (" + booking.getScheduledTimeSlot() + ").";
                    break;
                case Booking.STATUS_IN_PROGRESS:
                    timelineTitle = "Repair In Progress";
                    timelineDesc = "Technician arrived on-site and commenced diagnostic & repair work.";
                    break;
                case Booking.STATUS_COMPLETED:
                    timelineTitle = "Service Completed Successfully";
                    timelineDesc = "Repair job finished. Customer can now review the service.";
                    break;
                case Booking.STATUS_CANCELLED:
                    timelineTitle = "Booking Cancelled";
                    timelineDesc = "Reason: " + (reason != null && !reason.isEmpty() ? reason : "Cancelled by user");
                    break;
                case Booking.STATUS_REJECTED:
                    timelineTitle = "Booking Declined";
                    timelineDesc = "Reason: " + (reason != null && !reason.isEmpty() ? reason : "Technician unavailable");
                    break;
                default:
                    timelineTitle = "Status Updated to " + newStatus;
                    timelineDesc = "Booking status updated.";
            }

            addTimelineEvent(bookingId, newStatus, timelineTitle, timelineDesc, now);

            // Provider stats update if completed or cancelled
            ProviderProfile provider = getProviderById(booking.getProviderId());
            if (provider != null) {
                if (Booking.STATUS_COMPLETED.equalsIgnoreCase(newStatus)) {
                    db.execSQL("UPDATE " + TABLE_PROVIDERS + " SET completed_jobs = completed_jobs + 1 WHERE id = ?",
                            new Object[]{provider.getId()});
                } else if (Booking.STATUS_CANCELLED.equalsIgnoreCase(newStatus) && User.ROLE_PROVIDER.equalsIgnoreCase(actorRole)) {
                    db.execSQL("UPDATE " + TABLE_PROVIDERS + " SET cancelled_jobs = cancelled_jobs + 1 WHERE id = ?",
                            new Object[]{provider.getId()});
                }
                // Refresh trust score
                ProviderProfile updated = getProviderById(provider.getId());
                if (updated != null) {
                    int newTrustScore = TrustScoreCalculator.calculate(updated).getTotalScore();
                    ContentValues scoreCv = new ContentValues();
                    scoreCv.put("trust_score", newTrustScore);
                    db.update(TABLE_PROVIDERS, scoreCv, "id = ?", new String[]{String.valueOf(provider.getId())});
                }

                // Cross-party notification
                long notifyUserId = User.ROLE_PROVIDER.equalsIgnoreCase(actorRole) ? booking.getCustomerId() : provider.getUserId();
                addNotification(notifyUserId, "Booking " + booking.getBookingCode() + ": " + timelineTitle,
                        timelineDesc, NotificationItem.TYPE_BOOKING, bookingId);
            }

            return true;
        }

        return false;
    }

    private boolean isValidStatusTransition(String current, String next, String actorRole) {
        if (current.equalsIgnoreCase(next)) return false;

        // Completed, Cancelled, and Rejected are terminal
        if (Booking.STATUS_COMPLETED.equalsIgnoreCase(current) ||
                Booking.STATUS_CANCELLED.equalsIgnoreCase(current) ||
                Booking.STATUS_REJECTED.equalsIgnoreCase(current)) {
            return false;
        }

        if (Booking.STATUS_CANCELLED.equalsIgnoreCase(next)) {
            // Customer or Provider can cancel pending, accepted, or scheduled
            return Booking.STATUS_PENDING.equalsIgnoreCase(current) ||
                    Booking.STATUS_ACCEPTED.equalsIgnoreCase(current) ||
                    Booking.STATUS_SCHEDULED.equalsIgnoreCase(current);
        }

        if (User.ROLE_PROVIDER.equalsIgnoreCase(actorRole)) {
            if (Booking.STATUS_PENDING.equalsIgnoreCase(current)) {
                return Booking.STATUS_ACCEPTED.equalsIgnoreCase(next) || Booking.STATUS_REJECTED.equalsIgnoreCase(next);
            }
            if (Booking.STATUS_ACCEPTED.equalsIgnoreCase(current)) {
                return Booking.STATUS_SCHEDULED.equalsIgnoreCase(next) || Booking.STATUS_IN_PROGRESS.equalsIgnoreCase(next);
            }
            if (Booking.STATUS_SCHEDULED.equalsIgnoreCase(current)) {
                return Booking.STATUS_IN_PROGRESS.equalsIgnoreCase(next);
            }
            if (Booking.STATUS_IN_PROGRESS.equalsIgnoreCase(current)) {
                return Booking.STATUS_COMPLETED.equalsIgnoreCase(next);
            }
        }

        return false;
    }

    public Booking getBookingById(long bookingId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT b.*, u_c.name AS customer_name, u_c.phone AS customer_phone, " +
                "u_p.name AS provider_name, p.category AS provider_category " +
                "FROM " + TABLE_BOOKINGS + " b " +
                "JOIN " + TABLE_USERS + " u_c ON b.customer_id = u_c.id " +
                "JOIN " + TABLE_PROVIDERS + " p ON b.provider_id = p.id " +
                "JOIN " + TABLE_USERS + " u_p ON p.user_id = u_p.id " +
                "WHERE b.id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(bookingId)});
        Booking b = null;
        if (cursor.moveToFirst()) {
            b = cursorToBooking(cursor);
            b.setHasReview(hasReview(bookingId));
        }
        cursor.close();
        return b;
    }

    public List<Booking> getBookingsForCustomer(long customerId, String statusFilter) {
        List<Booking> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder query = new StringBuilder("SELECT b.*, u_c.name AS customer_name, u_c.phone AS customer_phone, " +
                "u_p.name AS provider_name, p.category AS provider_category " +
                "FROM " + TABLE_BOOKINGS + " b " +
                "JOIN " + TABLE_USERS + " u_c ON b.customer_id = u_c.id " +
                "JOIN " + TABLE_PROVIDERS + " p ON b.provider_id = p.id " +
                "JOIN " + TABLE_USERS + " u_p ON p.user_id = u_p.id " +
                "WHERE b.customer_id = ? ");

        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("ALL")) {
            query.append("AND b.status = '").append(statusFilter).append("' ");
        }
        query.append("ORDER BY b.id DESC");

        Cursor cursor = db.rawQuery(query.toString(), new String[]{String.valueOf(customerId)});
        if (cursor.moveToFirst()) {
            do {
                Booking b = cursorToBooking(cursor);
                b.setHasReview(hasReview(b.getId()));
                list.add(b);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public List<Booking> getBookingsForProvider(long providerId, String statusFilter) {
        List<Booking> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder query = new StringBuilder("SELECT b.*, u_c.name AS customer_name, u_c.phone AS customer_phone, " +
                "u_p.name AS provider_name, p.category AS provider_category " +
                "FROM " + TABLE_BOOKINGS + " b " +
                "JOIN " + TABLE_USERS + " u_c ON b.customer_id = u_c.id " +
                "JOIN " + TABLE_PROVIDERS + " p ON b.provider_id = p.id " +
                "JOIN " + TABLE_USERS + " u_p ON p.user_id = u_p.id " +
                "WHERE b.provider_id = ? ");

        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("ALL")) {
            query.append("AND b.status = '").append(statusFilter).append("' ");
        }
        query.append("ORDER BY b.id DESC");

        Cursor cursor = db.rawQuery(query.toString(), new String[]{String.valueOf(providerId)});
        if (cursor.moveToFirst()) {
            do {
                Booking b = cursorToBooking(cursor);
                b.setHasReview(hasReview(b.getId()));
                list.add(b);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    private Booking cursorToBooking(Cursor cursor) {
        Booking b = new Booking();
        b.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        b.setBookingCode(cursor.getString(cursor.getColumnIndexOrThrow("booking_code")));
        b.setCustomerId(cursor.getLong(cursor.getColumnIndexOrThrow("customer_id")));
        b.setCustomerName(cursor.getString(cursor.getColumnIndexOrThrow("customer_name")));
        b.setCustomerPhone(cursor.getString(cursor.getColumnIndexOrThrow("customer_phone")));
        b.setProviderId(cursor.getLong(cursor.getColumnIndexOrThrow("provider_id")));
        b.setProviderName(cursor.getString(cursor.getColumnIndexOrThrow("provider_name")));
        b.setProviderCategory(cursor.getString(cursor.getColumnIndexOrThrow("provider_category")));
        b.setServiceId(cursor.getLong(cursor.getColumnIndexOrThrow("service_id")));
        b.setServiceTitle(cursor.getString(cursor.getColumnIndexOrThrow("service_title")));
        b.setProblemDescription(cursor.getString(cursor.getColumnIndexOrThrow("problem_description")));
        b.setServiceAddress(cursor.getString(cursor.getColumnIndexOrThrow("service_address")));
        b.setScheduledDate(cursor.getString(cursor.getColumnIndexOrThrow("scheduled_date")));
        b.setScheduledTimeSlot(cursor.getString(cursor.getColumnIndexOrThrow("scheduled_time_slot")));
        b.setEstimatedCost(cursor.getDouble(cursor.getColumnIndexOrThrow("estimated_cost")));
        b.setFinalCost(cursor.getDouble(cursor.getColumnIndexOrThrow("final_cost")));
        b.setStatus(cursor.getString(cursor.getColumnIndexOrThrow("status")));
        b.setRejectionReason(cursor.getString(cursor.getColumnIndexOrThrow("rejection_reason")));
        b.setCancellationReason(cursor.getString(cursor.getColumnIndexOrThrow("cancellation_reason")));
        b.setCreatedAt(cursor.getString(cursor.getColumnIndexOrThrow("created_at")));
        b.setUpdatedAt(cursor.getString(cursor.getColumnIndexOrThrow("updated_at")));
        return b;
    }

    public void addTimelineEvent(long bookingId, String status, String title, String description, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("booking_id", bookingId);
        cv.put("status", status);
        cv.put("title", title);
        cv.put("description", description);
        cv.put("timestamp", timestamp != null ? timestamp : getCurrentTimestamp());
        db.insert(TABLE_TIMELINE, null, cv);
    }

    public List<BookingTimelineEvent> getBookingTimeline(long bookingId) {
        List<BookingTimelineEvent> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_TIMELINE + " WHERE booking_id = ? ORDER BY id ASC",
                new String[]{String.valueOf(bookingId)});
        if (cursor.moveToFirst()) {
            do {
                list.add(new BookingTimelineEvent(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("booking_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("status")),
                        cursor.getString(cursor.getColumnIndexOrThrow("title")),
                        cursor.getString(cursor.getColumnIndexOrThrow("description")),
                        cursor.getString(cursor.getColumnIndexOrThrow("timestamp"))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // REVIEWS & RATINGS
    // ==========================================

    public boolean submitReview(long bookingId, long customerId, long providerId, float rating, String reviewText) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Security check: Must be a completed booking
        Booking booking = getBookingById(bookingId);
        if (booking == null || !Booking.STATUS_COMPLETED.equalsIgnoreCase(booking.getStatus()) || booking.getCustomerId() != customerId) {
            return false;
        }

        // Duplicate review prevention
        if (hasReview(bookingId)) {
            return false;
        }

        String now = getCurrentTimestamp();
        ContentValues cv = new ContentValues();
        cv.put("booking_id", bookingId);
        cv.put("customer_id", customerId);
        cv.put("provider_id", providerId);
        cv.put("rating", rating);
        cv.put("review_text", reviewText);
        cv.put("created_at", now);

        long reviewId = db.insert(TABLE_REVIEWS, null, cv);

        if (reviewId != -1) {
            // Recalculate average rating
            Cursor c = db.rawQuery("SELECT AVG(rating) AS avg_r, COUNT(id) AS cnt_r FROM " + TABLE_REVIEWS + " WHERE provider_id = ?",
                    new String[]{String.valueOf(providerId)});
            if (c.moveToFirst()) {
                double avg = c.getDouble(c.getColumnIndexOrThrow("avg_r"));
                int cnt = c.getInt(c.getColumnIndexOrThrow("cnt_r"));

                ContentValues pCv = new ContentValues();
                pCv.put("rating_avg", Math.round(avg * 10.0) / 10.0);
                pCv.put("rating_count", cnt);
                db.update(TABLE_PROVIDERS, pCv, "id = ?", new String[]{String.valueOf(providerId)});
            }
            c.close();

            // Refresh trust score
            ProviderProfile updated = getProviderById(providerId);
            if (updated != null) {
                int newTrustScore = TrustScoreCalculator.calculate(updated).getTotalScore();
                ContentValues scoreCv = new ContentValues();
                scoreCv.put("trust_score", newTrustScore);
                db.update(TABLE_PROVIDERS, scoreCv, "id = ?", new String[]{String.valueOf(providerId)});

                // Notify provider of new review
                addNotification(updated.getUserId(), "New Customer Review Received!",
                        String.format(Locale.getDefault(), "A customer rated your service %.1f stars: \"%s\"", rating, reviewText),
                        NotificationItem.TYPE_BOOKING, bookingId);
            }

            return true;
        }

        return false;
    }

    public boolean hasReview(long bookingId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_REVIEWS + " WHERE booking_id = ?",
                new String[]{String.valueOf(bookingId)});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public List<Review> getReviewsForProvider(long providerId) {
        List<Review> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT r.*, u.name AS customer_name " +
                "FROM " + TABLE_REVIEWS + " r " +
                "JOIN " + TABLE_USERS + " u ON r.customer_id = u.id " +
                "WHERE r.provider_id = ? " +
                "ORDER BY r.id DESC";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(providerId)});
        if (cursor.moveToFirst()) {
            do {
                list.add(new Review(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("booking_id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("customer_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("customer_name")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("provider_id")),
                        cursor.getFloat(cursor.getColumnIndexOrThrow("rating")),
                        cursor.getString(cursor.getColumnIndexOrThrow("review_text")),
                        cursor.getString(cursor.getColumnIndexOrThrow("created_at"))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // FAVORITES
    // ==========================================

    public boolean toggleFavorite(long customerId, long providerId) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (isFavorite(customerId, providerId)) {
            db.delete(TABLE_FAVORITES, "customer_id = ? AND provider_id = ?",
                    new String[]{String.valueOf(customerId), String.valueOf(providerId)});
            return false;
        } else {
            ContentValues cv = new ContentValues();
            cv.put("customer_id", customerId);
            cv.put("provider_id", providerId);
            cv.put("created_at", getCurrentTimestamp());
            db.insert(TABLE_FAVORITES, null, cv);
            return true;
        }
    }

    public boolean isFavorite(long customerId, long providerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM " + TABLE_FAVORITES + " WHERE customer_id = ? AND provider_id = ?",
                new String[]{String.valueOf(customerId), String.valueOf(providerId)});
        boolean fav = cursor.getCount() > 0;
        cursor.close();
        return fav;
    }

    public List<ProviderProfile> getFavoriteProviders(long customerId) {
        List<ProviderProfile> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT p.*, u.name, u.email, u.phone, u.profile_photo " +
                "FROM " + TABLE_FAVORITES + " f " +
                "JOIN " + TABLE_PROVIDERS + " p ON f.provider_id = p.id " +
                "JOIN " + TABLE_USERS + " u ON p.user_id = u.id " +
                "WHERE f.customer_id = ? " +
                "ORDER BY f.id DESC";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(customerId)});
        if (cursor.moveToFirst()) {
            do {
                ProviderProfile profile = cursorToProviderProfile(cursor);
                profile.setFavorite(true);
                list.add(profile);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // MESSAGING & CHAT
    // ==========================================

    public long sendMessage(long bookingId, long senderId, long receiverId, String text) {
        SQLiteDatabase db = this.getWritableDatabase();
        String now = getCurrentTimestamp();

        ContentValues cv = new ContentValues();
        cv.put("booking_id", bookingId);
        cv.put("sender_id", senderId);
        cv.put("receiver_id", receiverId);
        cv.put("message_text", text);
        cv.put("is_read", 0);
        cv.put("timestamp", now);

        long msgId = db.insert(TABLE_MESSAGES, null, cv);

        if (msgId != -1) {
            User sender = getUserById(senderId);
            String senderName = sender != null ? sender.getName() : "FixNear User";
            addNotification(receiverId, "New message from " + senderName,
                    text, NotificationItem.TYPE_MESSAGE, bookingId);
        }

        return msgId;
    }

    public List<Message> getMessagesBetween(long user1, long user2) {
        List<Message> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT m.*, u.name AS sender_name " +
                "FROM " + TABLE_MESSAGES + " m " +
                "JOIN " + TABLE_USERS + " u ON m.sender_id = u.id " +
                "WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?) " +
                "ORDER BY m.id ASC";
        Cursor cursor = db.rawQuery(query, new String[]{
                String.valueOf(user1), String.valueOf(user2),
                String.valueOf(user2), String.valueOf(user1)
        });

        if (cursor.moveToFirst()) {
            do {
                list.add(new Message(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("booking_id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("sender_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("sender_name")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("receiver_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("message_text")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("is_read")) == 1,
                        cursor.getString(cursor.getColumnIndexOrThrow("timestamp"))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // NOTIFICATIONS
    // ==========================================

    public void addNotification(long userId, String title, String message, String type, long relatedId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("title", title);
        cv.put("message", message);
        cv.put("type", type);
        cv.put("related_id", relatedId);
        cv.put("is_read", 0);
        cv.put("timestamp", getCurrentTimestamp());
        db.insert(TABLE_NOTIFICATIONS, null, cv);
    }

    public List<NotificationItem> getNotifications(long userId) {
        List<NotificationItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NOTIFICATIONS + " WHERE user_id = ? ORDER BY id DESC",
                new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                list.add(new NotificationItem(
                        cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("user_id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("title")),
                        cursor.getString(cursor.getColumnIndexOrThrow("message")),
                        cursor.getString(cursor.getColumnIndexOrThrow("type")),
                        cursor.getLong(cursor.getColumnIndexOrThrow("related_id")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("is_read")) == 1,
                        cursor.getString(cursor.getColumnIndexOrThrow("timestamp"))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public int getUnreadNotificationCount(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(id) FROM " + TABLE_NOTIFICATIONS + " WHERE user_id = ? AND is_read = 0",
                new String[]{String.valueOf(userId)});
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public void markNotificationRead(long notifId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_read", 1);
        db.update(TABLE_NOTIFICATIONS, cv, "id = ?", new String[]{String.valueOf(notifId)});
    }

    // ==========================================
    // SAFETY & REPORTING
    // ==========================================

    public long submitReport(long reporterId, long reportedUserId, long bookingId, String reason, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("reporter_id", reporterId);
        cv.put("reported_user_id", reportedUserId);
        cv.put("booking_id", bookingId);
        cv.put("reason", reason);
        cv.put("details", details);
        cv.put("status", ReportItem.STATUS_OPEN);
        cv.put("admin_notes", "");
        cv.put("timestamp", getCurrentTimestamp());

        long reportId = db.insert(TABLE_REPORTS, null, cv);

        if (reportId != -1) {
            addNotification(reporterId, "Report Acknowledged",
                    "Your report has been logged with Trust & Safety. Our administrator will review it promptly.",
                    NotificationItem.TYPE_SYSTEM, reportId);
        }

        return reportId;
    }

    public List<ReportItem> getAllReports() {
        List<ReportItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT r.*, u1.name AS reporter_name, u2.name AS reported_name " +
                "FROM " + TABLE_REPORTS + " r " +
                "JOIN " + TABLE_USERS + " u1 ON r.reporter_id = u1.id " +
                "JOIN " + TABLE_USERS + " u2 ON r.reported_user_id = u2.id " +
                "ORDER BY r.id DESC";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                ReportItem item = new ReportItem();
                item.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
                item.setReporterId(cursor.getLong(cursor.getColumnIndexOrThrow("reporter_id")));
                item.setReporterName(cursor.getString(cursor.getColumnIndexOrThrow("reporter_name")));
                item.setReportedUserId(cursor.getLong(cursor.getColumnIndexOrThrow("reported_user_id")));
                item.setReportedUserName(cursor.getString(cursor.getColumnIndexOrThrow("reported_name")));
                item.setBookingId(cursor.getLong(cursor.getColumnIndexOrThrow("booking_id")));
                item.setReason(cursor.getString(cursor.getColumnIndexOrThrow("reason")));
                item.setDetails(cursor.getString(cursor.getColumnIndexOrThrow("details")));
                item.setStatus(cursor.getString(cursor.getColumnIndexOrThrow("status")));
                item.setAdminNotes(cursor.getString(cursor.getColumnIndexOrThrow("admin_notes")));
                item.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow("timestamp")));
                list.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    // ==========================================
    // PLATFORM STATS FOR ADMIN
    // ==========================================

    public Map<String, Integer> getPlatformStats() {
        Map<String, Integer> stats = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();

        stats.put("total_users", getCount(db, "SELECT COUNT(id) FROM " + TABLE_USERS));
        stats.put("total_providers", getCount(db, "SELECT COUNT(id) FROM " + TABLE_PROVIDERS));
        stats.put("verified_providers", getCount(db, "SELECT COUNT(id) FROM " + TABLE_PROVIDERS + " WHERE verification_status = '" + ProviderProfile.STATUS_VERIFIED + "'"));
        stats.put("pending_verifications", getCount(db, "SELECT COUNT(id) FROM " + TABLE_PROVIDERS + " WHERE verification_status = '" + ProviderProfile.STATUS_PENDING_REVIEW + "'"));
        stats.put("total_bookings", getCount(db, "SELECT COUNT(id) FROM " + TABLE_BOOKINGS));
        stats.put("completed_bookings", getCount(db, "SELECT COUNT(id) FROM " + TABLE_BOOKINGS + " WHERE status = '" + Booking.STATUS_COMPLETED + "'"));
        stats.put("active_bookings", getCount(db, "SELECT COUNT(id) FROM " + TABLE_BOOKINGS + " WHERE status IN ('PENDING', 'ACCEPTED', 'SCHEDULED', 'IN_PROGRESS')"));
        stats.put("open_reports", getCount(db, "SELECT COUNT(id) FROM " + TABLE_REPORTS + " WHERE status = '" + ReportItem.STATUS_OPEN + "'"));

        return stats;
    }

    private int getCount(SQLiteDatabase db, String sql) {
        Cursor c = db.rawQuery(sql, null);
        int count = 0;
        if (c.moveToFirst()) {
            count = c.getInt(0);
        }
        c.close();
        return count;
    }

    // ==========================================
    // SEED INITIAL DEMO & ADMINISTRATIVE DATA
    // ==========================================

    private void seedInitialData(SQLiteDatabase db) {
        String now = getCurrentTimestamp();

        // 1. Admin Account
        String adminSalt = SecurityUtils.generateSalt();
        String adminHash = SecurityUtils.hashPassword("admin123", adminSalt);
        ContentValues adminUser = new ContentValues();
        adminUser.put("name", "FIXNEAR Platform Admin");
        adminUser.put("email", "admin@fixnear.com");
        adminUser.put("password_hash", adminHash);
        adminUser.put("salt", adminSalt);
        adminUser.put("phone", "+91 98765 00000");
        adminUser.put("role", User.ROLE_ADMIN);
        adminUser.put("created_at", now);
        db.insert(TABLE_USERS, null, adminUser);

        // 2. Demo Customer Account
        String custSalt = SecurityUtils.generateSalt();
        String custHash = SecurityUtils.hashPassword("cust123", custSalt);
        ContentValues custUser = new ContentValues();
        custUser.put("name", "Rajesh Sharma");
        custUser.put("email", "customer@fixnear.com");
        custUser.put("password_hash", custHash);
        custUser.put("salt", custSalt);
        custUser.put("phone", "+91 98111 22334");
        custUser.put("role", User.ROLE_CUSTOMER);
        custUser.put("created_at", now);
        long custId = db.insert(TABLE_USERS, null, custUser);

        // 3. Demo Provider Account
        String provSalt = SecurityUtils.generateSalt();
        String provHash = SecurityUtils.hashPassword("prov123", provSalt);
        ContentValues provUser = new ContentValues();
        provUser.put("name", "Manoj Kumar");
        provUser.put("email", "provider@fixnear.com");
        provUser.put("password_hash", provHash);
        provUser.put("salt", provSalt);
        provUser.put("phone", "+91 98222 33445");
        provUser.put("role", User.ROLE_PROVIDER);
        provUser.put("created_at", now);
        long provUserId = db.insert(TABLE_USERS, null, provUser);

        // Seed Services Catalog
        seedServices(db);

        // Seed Providers across diverse categories (Verified, Pending, Unverified)
        seedProviders(db, provUserId, now);
    }

    private void seedServices(SQLiteDatabase db) {
        insertService(db, "Electrical", "Switchboard & Socket Repair", 199, 150, 350, "Fix sparking, loose connections, or socket burnout.", "ic_bolt");
        insertService(db, "Electrical", "MCB Tripping & Fuse Replacement", 249, 200, 500, "Inspect circuit overload and replace faulty breaker.", "ic_bolt");
        insertService(db, "Electrical", "Ceiling Fan Installation & Repair", 199, 150, 300, "Bearing replacement, capacitor check, and rewiring.", "ic_bolt");
        insertService(db, "Electrical", "Complete Inverter Wiring", 299, 400, 900, "Dual-battery backup wiring and bypass switch installation.", "ic_bolt");

        insertService(db, "AC Repair", "AC Deep Jet Cleaning", 249, 350, 600, "High pressure indoor coil & outdoor condenser foam jet wash.", "ic_ac");
        insertService(db, "AC Repair", "Gas Refill & Leak Testing", 299, 1200, 2200, "Nitrogen pressure leak detection, brazing, and R32/R410A gas charge.", "ic_ac");
        insertService(db, "AC Repair", "AC Water Leakage Resolution", 199, 250, 450, "Drain line flushing, gradient realignment, and insulation repair.", "ic_ac");

        insertService(db, "Plumbing", "Tap & Mixer Repair", 199, 150, 350, "Fix dripping taps, spindle replacement, and aerator cleaning.", "ic_plumbing");
        insertService(db, "Plumbing", "Drain Pipe De-Clogging", 249, 300, 650, "Motorized snake wire clearing for kitchen sink and bathroom drain.", "ic_plumbing");
        insertService(db, "Plumbing", "Water Tank & Motor Repair", 299, 400, 900, "Ball valve replacement, pipe leakage fix, and pressure check.", "ic_plumbing");

        insertService(db, "Appliances", "Washing Machine Drum & Motor Repair", 249, 350, 850, "Fix spin failure, vibration, water inlet valve error.", "ic_tools");
        insertService(db, "Appliances", "Refrigerator Cooling Diagnosis", 249, 300, 750, "Thermostat testing, fan motor fix, and relay replacement.", "ic_tools");
        insertService(db, "Appliances", "Microwave Oven Servicing", 199, 250, 600, "Magnetron inspection, turntable motor, and diode test.", "ic_tools");

        insertService(db, "Carpentry", "Door Lock & Handle Fitting", 199, 200, 400, "Mortise lock, latch installation, and hinge alignment.", "ic_tools");
        insertService(db, "Carpentry", "Furniture Assembly & Repair", 249, 300, 700, "Wardrobe sliding door, bed hinge, and custom shelving.", "ic_tools");

        insertService(db, "RO Purifier", "Filter Replacement & Complete Service", 199, 450, 1200, "Sediment, pre-carbon, RO membrane, and post-carbon service.", "ic_tools");
        insertService(db, "CCTV Security", "CCTV Camera Installation & DVR Setup", 299, 500, 1200, "Wiring, IP camera configuration, and mobile remote view setup.", "ic_tools");
    }

    private void insertService(SQLiteDatabase db, String cat, String name, double visit, double min, double max, String desc, String icon) {
        ContentValues cv = new ContentValues();
        cv.put("category", cat);
        cv.put("service_name", name);
        cv.put("base_inspection_fee", visit);
        cv.put("estimated_labor_min", min);
        cv.put("estimated_labor_max", max);
        cv.put("description", desc);
        cv.put("icon_name", icon);
        db.insert(TABLE_SERVICES, null, cv);
    }

    private void seedProviders(SQLiteDatabase db, long demoProvUserId, String now) {
        // Provider 1: Manoj Kumar (Demo provider - Verified Electrician)
        insertProviderProfile(db, demoProvUserId, "Electrical",
                "Wiring, MCB Repair, Inverters, Lighting", 8, 300.0,
                "South Zone, Up to 15km",
                "Licensed Grade-A wireman with 8+ years hands-on experience in residential and commercial electrical maintenance.",
                ProviderProfile.STATUS_VERIFIED, "Aadhaar Card", "XXXX-XXXX-8921",
                4.8, 42, 38, 1, 95, 1, now);

        // Provider 2: Suresh Verma (Verified AC Specialist)
        long u2 = insertUserDirect(db, "Suresh Verma", "suresh.ac@fixnear.com", "+91 98333 44556", User.ROLE_PROVIDER, now);
        insertProviderProfile(db, u2, "AC Repair",
                "Inverter AC, Gas Charging, Jet Servicing, Copper Piping", 10, 350.0,
                "North & Central Zones",
                "Certified HVAC technician specializing in all major brands (Daikin, Voltas, LG, Blue Star). Clean work guaranteed.",
                ProviderProfile.STATUS_VERIFIED, "Government Trade License", "HVAC-2018-9921",
                4.9, 58, 52, 0, 98, 1, now);

        // Provider 3: Ramesh Chandra (Verified Master Plumber)
        long u3 = insertUserDirect(db, "Ramesh Chandra", "ramesh.plumb@fixnear.com", "+91 98444 55667", User.ROLE_PROVIDER, now);
        insertProviderProfile(db, u3, "Plumbing",
                "Concealed Leakage, CPVC Fitting, Sanitary, Drain Cleaning", 12, 250.0,
                "Citywide Coverage",
                "Expert plumber specializing in high-rise buildings, pressure pumps, and bathroom fittings. Available for quick response.",
                ProviderProfile.STATUS_VERIFIED, "Aadhaar Card", "XXXX-XXXX-4512",
                4.7, 39, 36, 1, 92, 1, now);

        // Provider 4: Amit Patel (Pending Verification - Appliance Technician)
        long u4 = insertUserDirect(db, "Amit Patel", "amit.repair@fixnear.com", "+91 98555 66778", User.ROLE_PROVIDER, now);
        insertProviderProfile(db, u4, "Appliances",
                "Washing Machine, Refrigerator, Microwave Oven", 5, 280.0,
                "East Zone, 10km radius",
                "Skilled home appliance repairer with factory training for front load washing machines and frost-free refrigerators.",
                ProviderProfile.STATUS_PENDING_REVIEW, "PAN Card", "ABCDE1234F",
                4.5, 14, 12, 0, 68, 1, now);

        // Provider 5: Vikram Singh (Unverified - Carpentry)
        long u5 = insertUserDirect(db, "Vikram Singh", "vikram.carpenter@fixnear.com", "+91 98666 77889", User.ROLE_PROVIDER, now);
        insertProviderProfile(db, u5, "Carpentry",
                "Furniture Fitting, Modular Kitchen, Door Locks", 6, 320.0,
                "West Zone",
                "Experienced carpenter for custom woodwork, sliding door repairs, and premium lock fittings.",
                ProviderProfile.STATUS_NOT_SUBMITTED, "", "",
                4.2, 9, 8, 1, 48, 1, now);

        // Provider 6: Deepak Soni (Verified CCTV Specialist)
        long u6 = insertUserDirect(db, "Deepak Soni", "deepak.cctv@fixnear.com", "+91 98777 88990", User.ROLE_PROVIDER, now);
        insertProviderProfile(db, u6, "CCTV Security",
                "IP Cameras, DVR/NVR, Remote Surveillance, WiFi Doorbell", 7, 400.0,
                "Citywide Coverage",
                "Electronic security specialist. Expert in Hikvision, CP Plus, and Dahua surveillance infrastructure.",
                ProviderProfile.STATUS_VERIFIED, "Trade License", "SEC-2021-3142",
                4.9, 31, 29, 0, 96, 1, now);
    }

    private long insertUserDirect(SQLiteDatabase db, String name, String email, String phone, String role, String now) {
        String salt = SecurityUtils.generateSalt();
        String hash = SecurityUtils.hashPassword("pass123", salt);
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("email", email.toLowerCase());
        cv.put("password_hash", hash);
        cv.put("salt", salt);
        cv.put("phone", phone);
        cv.put("role", role);
        cv.put("created_at", now);
        return db.insert(TABLE_USERS, null, cv);
    }

    private void insertProviderProfile(SQLiteDatabase db, long userId, String cat, String skills,
                                       int exp, double rate, String area, String bio,
                                       String verifStatus, String idType, String idNum,
                                       double rating, int ratingCount, int completed, int cancelled,
                                       int trust, int avail, String now) {
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("category", cat);
        cv.put("skills", skills);
        cv.put("experience_years", exp);
        cv.put("hourly_rate", rate);
        cv.put("service_area", area);
        cv.put("bio", bio);
        cv.put("verification_status", verifStatus);
        cv.put("id_proof_type", idType);
        cv.put("id_proof_number", idNum);
        cv.put("rating_avg", rating);
        cv.put("rating_count", ratingCount);
        cv.put("completed_jobs", completed);
        cv.put("cancelled_jobs", cancelled);
        cv.put("trust_score", trust);
        cv.put("is_available", avail);
        cv.put("created_at", now);
        db.insert(TABLE_PROVIDERS, null, cv);
    }
}
