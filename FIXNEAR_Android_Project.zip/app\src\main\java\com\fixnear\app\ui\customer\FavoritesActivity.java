package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.ui.adapters.ProviderCardAdapter;

import java.util.ArrayList;
import java.util.List;

public class FavoritesActivity extends AppCompatActivity implements ProviderCardAdapter.OnProviderActionListener {

    private ImageView btnFavBack;
    private RecyclerView rvFavorites;
    private TextView tvEmptyFavorites;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderCardAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        btnFavBack = findViewById(R.id.btnFavBack);
        rvFavorites = findViewById(R.id.rvFavorites);
        tvEmptyFavorites = findViewById(R.id.tvEmptyFavorites);

        btnFavBack.setOnClickListener(v -> finish());

        rvFavorites.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProviderCardAdapter(this, new ArrayList<>(), this);
        rvFavorites.setAdapter(adapter);

        loadFavorites();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFavorites();
    }

    private void loadFavorites() {
        long customerId = sessionManager.getUserId();
        List<ProviderProfile> list = dbHelper.getFavoriteProviders(customerId);
        adapter.updateList(list);

        if (list.isEmpty()) {
            tvEmptyFavorites.setVisibility(View.VISIBLE);
            rvFavorites.setVisibility(View.GONE);
        } else {
            tvEmptyFavorites.setVisibility(View.GONE);
            rvFavorites.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onProviderClick(ProviderProfile provider) {
        Intent intent = new Intent(this, ProviderDetailActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onBookClick(ProviderProfile provider) {
        Intent intent = new Intent(this, BookingActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onFavoriteToggle(ProviderProfile provider, int position) {
        long customerId = sessionManager.getUserId();
        boolean isFav = dbHelper.toggleFavorite(customerId, provider.getId());
        provider.setFavorite(isFav);
        loadFavorites();
        Toast.makeText(this, isFav ? "Saved to Favorites" : "Removed from Favorites", Toast.LENGTH_SHORT).show();
    }
}
