package com.fixnear.app.engine;

import com.fixnear.app.model.ProviderProfile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SmartMatchingEngine {

    public static class MatchResult {
        private ProviderProfile provider;
        private double matchPercentage;
        private String matchReason;

        public MatchResult(ProviderProfile provider, double matchPercentage, String matchReason) {
            this.provider = provider;
            this.matchPercentage = matchPercentage;
            this.matchReason = matchReason;
        }

        public ProviderProfile getProvider() { return provider; }
        public double getMatchPercentage() { return matchPercentage; }
        public String getMatchReason() { return matchReason; }
    }

    public static List<MatchResult> match(List<ProviderProfile> providers, String category, double maxBudget) {
        List<MatchResult> results = new ArrayList<>();
        if (providers == null) return results;

        for (ProviderProfile p : providers) {
            if (category != null && !category.isEmpty() && !category.equalsIgnoreCase("All")) {
                if (!category.equalsIgnoreCase(p.getCategory())) {
                    continue;
                }
            }

            // 1. Trust Score component (up to 40 pts)
            double trustComponent = (p.getTrustScore() / 100.0) * 40.0;

            // 2. Rating component (up to 25 pts)
            double ratingComponent = (p.getRatingAvg() / 5.0) * 25.0;

            // 3. Verification component (up to 20 pts)
            double verifComponent = p.isVerified() ? 20.0 : 5.0;

            // 4. Budget fit component (up to 15 pts)
            double budgetComponent = 15.0;
            if (maxBudget > 0 && p.getHourlyRate() > maxBudget) {
                double ratio = maxBudget / p.getHourlyRate();
                budgetComponent = Math.max(0, ratio * 15.0);
            }

            double total = trustComponent + ratingComponent + verifComponent + budgetComponent;
            if (total > 100.0) total = 100.0;
            if (total < 10.0) total = 10.0;

            String reason;
            if (p.isVerified() && p.getRatingAvg() >= 4.5) {
                reason = "Govt ID Verified with outstanding 4.5+ customer ratings.";
            } else if (p.isVerified()) {
                reason = "Verified Specialist with strong track record in your category.";
            } else if (p.getRatingAvg() >= 4.0) {
                reason = "Highly rated by local customers with reliable job history.";
            } else {
                reason = "Active local professional available for quick scheduling.";
            }

            results.add(new MatchResult(p, Math.round(total * 10.0) / 10.0, reason));
        }

        // Sort descending by match percentage
        Collections.sort(results, new Comparator<MatchResult>() {
            @Override
            public int compare(MatchResult a, MatchResult b) {
                return Double.compare(b.getMatchPercentage(), a.getMatchPercentage());
            }
        });

        return results;
    }
}
