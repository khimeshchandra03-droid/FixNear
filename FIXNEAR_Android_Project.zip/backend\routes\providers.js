const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

// GET /api/providers
router.get('/', async (req, res) => {
    try {
        const { category, query, verified_only, sort } = req.query;

        let sql = `
            SELECT p.*, u.name, u.email, u.phone, u.profile_photo
            FROM provider_profiles p
            JOIN users u ON p.user_id = u.id
            WHERE 1=1
        `;
        const params = [];

        if (category && category !== 'All') {
            sql += ` AND LOWER(p.category) = LOWER(?)`;
            params.push(category);
        }

        if (verified_only === 'true') {
            sql += ` AND p.verification_status = 'VERIFIED'`;
        }

        if (query) {
            sql += ` AND (LOWER(u.name) LIKE ? OR LOWER(p.skills) LIKE ? OR LOWER(p.category) LIKE ?)`;
            const q = `%${query.toLowerCase()}%`;
            params.push(q, q, q);
        }

        if (sort === 'PRICE_LOW_HIGH') {
            sql += ` ORDER BY p.hourly_rate ASC`;
        } else if (sort === 'PRICE_HIGH_LOW') {
            sql += ` ORDER BY p.hourly_rate DESC`;
        } else if (sort === 'RATING') {
            sql += ` ORDER BY p.rating_avg DESC`;
        } else {
            sql += ` ORDER BY p.trust_score DESC, p.rating_avg DESC`;
        }

        const providers = await db.query(sql, params);
        res.json({ success: true, count: providers.length, data: providers });
    } catch (err) {
        console.error('Fetch providers error:', err);
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

// GET /api/providers/:id
router.get('/:id', async (req, res) => {
    try {
        const provider = await db.getAsync(`
            SELECT p.*, u.name, u.email, u.phone, u.profile_photo
            FROM provider_profiles p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = ?
        `, [req.params.id]);

        if (!provider) {
            return res.status(404).json({ success: false, error: 'Provider not found' });
        }

        res.json({ success: true, data: provider });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

// POST /api/providers/verification (Provider submitting ID)
router.post('/verification', requireAuth, requireRole('PROVIDER'), async (req, res) => {
    try {
        const { id_proof_type, id_proof_number, category, skills, experience_years, hourly_rate, service_area, bio } = req.body;

        if (!id_proof_type || !id_proof_number) {
            return res.status(400).json({ success: false, error: 'ID proof type and document number are required' });
        }

        await db.runAsync(`
            UPDATE provider_profiles
            SET id_proof_type = ?, id_proof_number = ?, category = COALESCE(?, category),
                skills = COALESCE(?, skills), experience_years = COALESCE(?, experience_years),
                hourly_rate = COALESCE(?, hourly_rate), service_area = COALESCE(?, service_area),
                bio = COALESCE(?, bio), verification_status = 'PENDING_REVIEW', rejection_reason = ''
            WHERE user_id = ?
        `, [id_proof_type, id_proof_number, category, skills, experience_years, hourly_rate, service_area, bio, req.user.id]);

        res.json({
            success: true,
            message: 'Verification application submitted for administrative audit'
        });
    } catch (err) {
        console.error('Submit verification error:', err);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

module.exports = router;
