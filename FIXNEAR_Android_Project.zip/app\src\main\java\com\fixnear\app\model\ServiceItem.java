package com.fixnear.app.model;

import java.io.Serializable;

public class ServiceItem implements Serializable {
    private long id;
    private String category;
    private String serviceName;
    private double baseInspectionFee;
    private double estimatedLaborMin;
    private double estimatedLaborMax;
    private String description;
    private String iconName;

    public ServiceItem() {}

    public ServiceItem(long id, String category, String serviceName, double baseInspectionFee,
                       double estimatedLaborMin, double estimatedLaborMax, String description, String iconName) {
        this.id = id;
        this.category = category;
        this.serviceName = serviceName;
        this.baseInspectionFee = baseInspectionFee;
        this.estimatedLaborMin = estimatedLaborMin;
        this.estimatedLaborMax = estimatedLaborMax;
        this.description = description;
        this.iconName = iconName;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }

    public double getBaseInspectionFee() { return baseInspectionFee; }
    public void setBaseInspectionFee(double baseInspectionFee) { this.baseInspectionFee = baseInspectionFee; }

    public double getEstimatedLaborMin() { return estimatedLaborMin; }
    public void setEstimatedLaborMin(double estimatedLaborMin) { this.estimatedLaborMin = estimatedLaborMin; }

    public double getEstimatedLaborMax() { return estimatedLaborMax; }
    public void setEstimatedLaborMax(double estimatedLaborMax) { this.estimatedLaborMax = estimatedLaborMax; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIconName() { return iconName; }
    public void setIconName(String iconName) { this.iconName = iconName; }

    public double getAverageEstimatedTotal() {
        return baseInspectionFee + ((estimatedLaborMin + estimatedLaborMax) / 2.0);
    }
}
