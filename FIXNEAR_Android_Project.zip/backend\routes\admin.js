const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

// All admin routes strictly require ADMIN role!
router.use(requireAuth, requireRole('ADMIN'));

// GET /api/admin/verifications
router.get('/verifications', async (req, res) => {
    try {
        const pending = await db.query(`
            SELECT p.*, u.name, u.email, u.phone
            FROM provider_profiles p
            JOIN users u ON p.user_id = u.id
            WHERE p.verification_status = 'PENDING_REVIEW'
            ORDER BY p.id DESC
        `);

        res.json({ success: true, count: pending.length, data: pending });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

// POST /api/admin/verify/:id
router.post('/verify/:id', async (req, res) => {
    try {
        await db.runAsync(`
            UPDATE provider_profiles
            SET verification_status = 'VERIFIED', rejection_reason = '',
                trust_score = MIN(100, trust_score + 35)
            WHERE id = ?
        `, [req.params.id]);

        res.json({ success: true, message: 'Provider approved and verified successfully' });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed to verify provider' });
    }
});

// POST /api/admin/reject/:id
router.post('/reject/:id', async (req, res) => {
    try {
        const { reason } = req.body;
        await db.runAsync(`
            UPDATE provider_profiles
            SET verification_status = 'REJECTED',
                rejection_reason = ?
            WHERE id = ?
        `, [reason || 'Document verification failed', req.params.id]);

        res.json({ success: true, message: 'Provider verification rejected with feedback' });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Failed to reject provider' });
    }
});

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
    try {
        const users = await db.getAsync('SELECT COUNT(id) as total FROM users');
        const providers = await db.getAsync('SELECT COUNT(id) as total FROM provider_profiles');
        const verified = await db.getAsync("SELECT COUNT(id) as total FROM provider_profiles WHERE verification_status = 'VERIFIED'");
        const pending = await db.getAsync("SELECT COUNT(id) as total FROM provider_profiles WHERE verification_status = 'PENDING_REVIEW'");
        const bookings = await db.getAsync('SELECT COUNT(id) as total FROM bookings');
        const completed = await db.getAsync("SELECT COUNT(id) as total FROM bookings WHERE status = 'COMPLETED'");

        res.json({
            success: true,
            data: {
                total_users: users.total,
                total_providers: providers.total,
                verified_providers: verified.total,
                pending_verifications: pending.total,
                total_bookings: bookings.total,
                completed_bookings: completed.total
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

module.exports = router;
