const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.resolve(__dirname, process.env.DB_FILE || 'fixnear_backend.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Could not connect to database', err);
    } else {
        console.log('Connected to FIXNEAR database at:', dbPath);
    }
});

// Helper for promise-based queries
db.query = function (sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
};

db.runAsync = function (sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });
};

db.getAsync = function (sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
};

// Initialize tables
function initDb() {
    db.serialize(() => {
        db.run(`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            phone TEXT,
            role TEXT NOT NULL,
            profile_photo TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS provider_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            category TEXT NOT NULL,
            skills TEXT,
            experience_years INTEGER DEFAULT 1,
            hourly_rate REAL DEFAULT 200.0,
            service_area TEXT,
            bio TEXT,
            verification_status TEXT DEFAULT 'NOT_SUBMITTED',
            id_proof_type TEXT,
            id_proof_number TEXT,
            rejection_reason TEXT,
            rating_avg REAL DEFAULT 0.0,
            rating_count INTEGER DEFAULT 0,
            completed_jobs INTEGER DEFAULT 0,
            cancelled_jobs INTEGER DEFAULT 0,
            trust_score INTEGER DEFAULT 20,
            is_available INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_code TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            provider_id INTEGER NOT NULL,
            service_title TEXT NOT NULL,
            problem_description TEXT NOT NULL,
            service_address TEXT NOT NULL,
            scheduled_date TEXT NOT NULL,
            scheduled_time_slot TEXT NOT NULL,
            estimated_cost REAL NOT NULL,
            final_cost REAL DEFAULT 0.0,
            status TEXT NOT NULL,
            rejection_reason TEXT,
            cancellation_reason TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES users(id),
            FOREIGN KEY (provider_id) REFERENCES provider_profiles(id)
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS booking_timeline (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            status TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL,
            provider_id INTEGER NOT NULL,
            rating REAL NOT NULL,
            review_text TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id)
        )`);

        db.run(`CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reporter_id INTEGER NOT NULL,
            reported_user_id INTEGER NOT NULL,
            booking_id INTEGER,
            reason TEXT NOT NULL,
            details TEXT,
            status TEXT DEFAULT 'OPEN',
            admin_notes TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);
    });
}

initDb();

module.exports = db;
