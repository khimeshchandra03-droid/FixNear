package com.fixnear.app.ui.booking;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.BookingTimelineEvent;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.adapters.TimelineAdapter;
import com.fixnear.app.ui.chat.ChatActivity;
import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

public class BookingDetailActivity extends AppCompatActivity {

    private ImageView btnBookingDetailBack, btnChatWithParty;
    private TextView tvDetailBookingCodeHeader, tvDetailServiceTitle, tvDetailStatusBadge;
    private TextView tvDetailPartyInfo, tvDetailScheduleInfo, tvDetailTotalCost, tvReasonAlert;
    private TextView tvDetailAddress, tvDetailProblemDesc;
    private RecyclerView rvBookingTimeline;
    private MaterialButton btnBookingSecondaryAction, btnBookingPrimaryAction;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private Booking booking;
    private long bookingId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_detail);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        bookingId = getIntent().getLongExtra("booking_id", -1);
        if (bookingId == -1) {
            Toast.makeText(this, "Booking record not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        loadBookingData();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBookingData();
    }

    private void initViews() {
        btnBookingDetailBack = findViewById(R.id.btnBookingDetailBack);
        btnChatWithParty = findViewById(R.id.btnChatWithParty);
        tvDetailBookingCodeHeader = findViewById(R.id.tvDetailBookingCodeHeader);
        tvDetailServiceTitle = findViewById(R.id.tvDetailServiceTitle);
        tvDetailStatusBadge = findViewById(R.id.tvDetailStatusBadge);
        tvDetailPartyInfo = findViewById(R.id.tvDetailPartyInfo);
        tvDetailScheduleInfo = findViewById(R.id.tvDetailScheduleInfo);
        tvDetailTotalCost = findViewById(R.id.tvDetailTotalCost);
        tvReasonAlert = findViewById(R.id.tvReasonAlert);
        tvDetailAddress = findViewById(R.id.tvDetailAddress);
        tvDetailProblemDesc = findViewById(R.id.tvDetailProblemDesc);
        rvBookingTimeline = findViewById(R.id.rvBookingTimeline);
        btnBookingSecondaryAction = findViewById(R.id.btnBookingSecondaryAction);
        btnBookingPrimaryAction = findViewById(R.id.btnBookingPrimaryAction);
    }

    private void loadBookingData() {
        booking = dbHelper.getBookingById(bookingId);
        if (booking == null) {
            Toast.makeText(this, "Booking record not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvDetailBookingCodeHeader.setText("Booking " + booking.getBookingCode());
        tvDetailServiceTitle.setText(booking.getServiceTitle());
        tvDetailStatusBadge.setText(booking.getStatus());

        String currentRole = sessionManager.getUserRole();
        if (User.ROLE_PROVIDER.equalsIgnoreCase(currentRole)) {
            tvDetailPartyInfo.setText("Customer: " + booking.getCustomerName() + " (" + booking.getCustomerPhone() + ")");
        } else {
            tvDetailPartyInfo.setText("Specialist: " + booking.getProviderName() + " (" + booking.getProviderCategory() + ")");
        }

        tvDetailScheduleInfo.setText(String.format("Scheduled: %s • %s", booking.getScheduledDate(), booking.getScheduledTimeSlot()));
        tvDetailTotalCost.setText(String.format(Locale.getDefault(), "Estimated Cost: ₹%.0f", booking.getEstimatedCost()));
        tvDetailAddress.setText("📍 Service Address: " + booking.getServiceAddress());
        tvDetailProblemDesc.setText("📝 Problem: " + booking.getProblemDescription());

        // Display rejection or cancellation reason if present
        if (booking.isRejected() && booking.getRejectionReason() != null && !booking.getRejectionReason().isEmpty()) {
            tvReasonAlert.setText("Declined by Specialist: " + booking.getRejectionReason());
            tvReasonAlert.setVisibility(View.VISIBLE);
        } else if (booking.isCancelled() && booking.getCancellationReason() != null && !booking.getCancellationReason().isEmpty()) {
            tvReasonAlert.setText("Cancellation Note: " + booking.getCancellationReason());
            tvReasonAlert.setVisibility(View.VISIBLE);
        } else {
            tvReasonAlert.setVisibility(View.GONE);
        }

        // Timeline
        List<BookingTimelineEvent> timelineEvents = dbHelper.getBookingTimeline(bookingId);
        rvBookingTimeline.setLayoutManager(new LinearLayoutManager(this));
        rvBookingTimeline.setAdapter(new TimelineAdapter(this, timelineEvents));

        // Setup Role Actions
        setupActionButtons(currentRole);
    }

    private void setupActionButtons(String currentRole) {
        btnBookingSecondaryAction.setVisibility(View.GONE);
        btnBookingPrimaryAction.setVisibility(View.GONE);

        if (User.ROLE_PROVIDER.equalsIgnoreCase(currentRole)) {
            // Provider actions
            if (booking.isPending()) {
                btnBookingSecondaryAction.setText("Decline");
                btnBookingSecondaryAction.setVisibility(View.VISIBLE);
                btnBookingSecondaryAction.setOnClickListener(v -> showRejectDialog());

                btnBookingPrimaryAction.setText("Accept Booking");
                btnBookingPrimaryAction.setVisibility(View.VISIBLE);
                btnBookingPrimaryAction.setOnClickListener(v -> {
                    boolean ok = dbHelper.updateBookingStatus(bookingId, Booking.STATUS_ACCEPTED, "", User.ROLE_PROVIDER);
                    if (ok) {
                        Toast.makeText(this, "Booking accepted! Customer notified.", Toast.LENGTH_SHORT).show();
                        loadBookingData();
                    }
                });
            } else if (booking.isAccepted() || booking.isScheduled()) {
                btnBookingPrimaryAction.setText("Start Repair (In Progress)");
                btnBookingPrimaryAction.setVisibility(View.VISIBLE);
                btnBookingPrimaryAction.setOnClickListener(v -> {
                    boolean ok = dbHelper.updateBookingStatus(bookingId, Booking.STATUS_IN_PROGRESS, "", User.ROLE_PROVIDER);
                    if (ok) {
                        Toast.makeText(this, "Work started! Live timeline updated.", Toast.LENGTH_SHORT).show();
                        loadBookingData();
                    }
                });
            } else if (booking.isInProgress()) {
                btnBookingPrimaryAction.setText("Mark Job Completed");
                btnBookingPrimaryAction.setVisibility(View.VISIBLE);
                btnBookingPrimaryAction.setOnClickListener(v -> {
                    boolean ok = dbHelper.updateBookingStatus(bookingId, Booking.STATUS_COMPLETED, "", User.ROLE_PROVIDER);
                    if (ok) {
                        Toast.makeText(this, "Job marked completed! Customer can now review.", Toast.LENGTH_LONG).show();
                        loadBookingData();
                    }
                });
            }
        } else {
            // Customer actions
            if (booking.canCancel()) {
                btnBookingSecondaryAction.setText("Cancel Booking");
                btnBookingSecondaryAction.setVisibility(View.VISIBLE);
                btnBookingSecondaryAction.setOnClickListener(v -> showCancelDialog());
            }

            if (booking.isCompleted() && !booking.isHasReview()) {
                btnBookingPrimaryAction.setText("Leave Rating & Review");
                btnBookingPrimaryAction.setVisibility(View.VISIBLE);
                btnBookingPrimaryAction.setOnClickListener(v -> showReviewDialog());
            }
        }
    }

    private void setupListeners() {
        btnBookingDetailBack.setOnClickListener(v -> finish());

        btnChatWithParty.setOnClickListener(v -> {
            String currentRole = sessionManager.getUserRole();
            long otherId;
            String otherName;

            if (User.ROLE_PROVIDER.equalsIgnoreCase(currentRole)) {
                otherId = booking.getCustomerId();
                otherName = booking.getCustomerName();
            } else {
                ProviderProfile p = dbHelper.getProviderById(booking.getProviderId());
                otherId = p != null ? p.getUserId() : booking.getProviderId();
                otherName = booking.getProviderName();
            }

            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("booking_id", bookingId);
            intent.putExtra("other_user_id", otherId);
            intent.putExtra("other_user_name", otherName);
            startActivity(intent);
        });
    }

    private void showRejectDialog() {
        final EditText etReason = new EditText(this);
        etReason.setHint("State reason (e.g. Schedule conflict)");

        new AlertDialog.Builder(this)
                .setTitle("Decline Booking Request")
                .setMessage("Please enter an explanation for declining this booking:")
                .setView(etReason)
                .setPositiveButton("Decline", (dialog, which) -> {
                    String reason = etReason.getText().toString().trim();
                    boolean ok = dbHelper.updateBookingStatus(bookingId, Booking.STATUS_REJECTED, reason, User.ROLE_PROVIDER);
                    if (ok) {
                        Toast.makeText(this, "Booking declined.", Toast.LENGTH_SHORT).show();
                        loadBookingData();
                    }
                })
                .setNegativeButton("Back", null)
                .show();
    }

    private void showCancelDialog() {
        final EditText etReason = new EditText(this);
        etReason.setHint("Reason for cancellation");

        new AlertDialog.Builder(this)
                .setTitle("Cancel Appointment")
                .setMessage("Are you sure you want to cancel this booking?")
                .setView(etReason)
                .setPositiveButton("Cancel Booking", (dialog, which) -> {
                    String reason = etReason.getText().toString().trim();
                    String role = sessionManager.getUserRole();
                    boolean ok = dbHelper.updateBookingStatus(bookingId, Booking.STATUS_CANCELLED, reason, role);
                    if (ok) {
                        Toast.makeText(this, "Booking has been cancelled.", Toast.LENGTH_SHORT).show();
                        loadBookingData();
                    }
                })
                .setNegativeButton("Keep Booking", null)
                .show();
    }

    private void showReviewDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_submit_review, null, false);
        RatingBar ratingBar = dialogView.findViewById(R.id.dialogRatingBar);
        EditText etComment = dialogView.findViewById(R.id.dialogEtReviewComment);

        new AlertDialog.Builder(this)
                .setTitle("Rate & Review Technician")
                .setView(dialogView)
                .setPositiveButton("Submit Review", (dialog, which) -> {
                    float rating = ratingBar.getRating();
                    String comment = etComment.getText().toString().trim();
                    if (rating == 0) {
                        Toast.makeText(this, "Please select a star rating", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    long customerId = sessionManager.getUserId();
                    boolean ok = dbHelper.submitReview(bookingId, customerId, booking.getProviderId(), rating, comment);
                    if (ok) {
                        Toast.makeText(this, "Thank you! Your feedback has updated the specialist's Trust Score.", Toast.LENGTH_LONG).show();
                        loadBookingData();
                    } else {
                        Toast.makeText(this, "Failed to submit review.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
