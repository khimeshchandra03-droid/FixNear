const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'fixnear_jwt_academic_development_secret_key';

function requireAuth(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, error: 'Access token required' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(403).json({ success: false, error: 'Invalid or expired token' });
    }
}

function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(403).json({
                success: false,
                error: `Access forbidden: requires role [${roles.join(', ')}]`
            });
        }
        next();
    };
}

module.exports = {
    requireAuth,
    requireRole,
    JWT_SECRET
};
