package com.fixnear.app.engine;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SmartAssistantEngine {

    public static class DiagnosisResult implements Serializable {
        private String category;
        private String issueSummary;
        private String preliminaryCause;
        private String safetyPrecaution;
        private String recommendedService;
        private double estimatedMinCost;
        private double estimatedMaxCost;
        private String recommendedSpecialistSkill;

        public DiagnosisResult(String category, String issueSummary, String preliminaryCause,
                               String safetyPrecaution, String recommendedService,
                               double estimatedMinCost, double estimatedMaxCost,
                               String recommendedSpecialistSkill) {
            this.category = category;
            this.issueSummary = issueSummary;
            this.preliminaryCause = preliminaryCause;
            this.safetyPrecaution = safetyPrecaution;
            this.recommendedService = recommendedService;
            this.estimatedMinCost = estimatedMinCost;
            this.estimatedMaxCost = estimatedMaxCost;
            this.recommendedSpecialistSkill = recommendedSpecialistSkill;
        }

        public String getCategory() { return category; }
        public String getIssueSummary() { return issueSummary; }
        public String getPreliminaryCause() { return preliminaryCause; }
        public String getSafetyPrecaution() { return safetyPrecaution; }
        public String getRecommendedService() { return recommendedService; }
        public double getEstimatedMinCost() { return estimatedMinCost; }
        public double getEstimatedMaxCost() { return estimatedMaxCost; }
        public String getRecommendedSpecialistSkill() { return recommendedSpecialistSkill; }
    }

    public static DiagnosisResult analyzeIssue(String category, String symptom, String ageOrCondition) {
        String cat = (category != null) ? category.trim() : "Electrical";
        String sym = (symptom != null) ? symptom.toLowerCase() : "";

        if (cat.equalsIgnoreCase("Electrical")) {
            if (sym.contains("spark") || sym.contains("smell") || sym.contains("burning")) {
                return new DiagnosisResult(
                        "Electrical",
                        "Short Circuit or Overloaded Terminal",
                        "High resistance connection, oxidized wiring, or blown circuit component causing arcing.",
                        "CRITICAL: Turn off your main MCB / breaker switch immediately. Do not touch bare wires or switchboards.",
                        "Emergency Switchboard & MCB Repair",
                        350, 750, "Wiring & MCB Repair"
                );
            } else if (sym.contains("trip") || sym.contains("mcb") || sym.contains("power cut")) {
                return new DiagnosisResult(
                        "Electrical",
                        "Repeated Circuit Breaker Tripping",
                        "Appliance earth fault, overloaded phase, or worn out MCB switch mechanism.",
                        "Unplug high-load appliances (geyser, iron, AC) before resetting MCB. Do not force breaker UP.",
                        "MCB & Circuit Inspection",
                        250, 500, "Circuit Breakers & Earthing"
                );
            } else {
                return new DiagnosisResult(
                        "Electrical",
                        "General Electrical Fixture Fault",
                        "Internal terminal contact loosening, burned fuse, or wire degradation.",
                        "Keep surroundings dry and switch off wall switches before inspecting sockets.",
                        "Electrical Fixture Inspection & Servicing",
                        200, 450, "Electrical Installation"
                );
            }
        } else if (cat.equalsIgnoreCase("AC Repair") || cat.equalsIgnoreCase("Air Conditioner")) {
            if (sym.contains("cooling") || sym.contains("hot") || sym.contains("warm")) {
                return new DiagnosisResult(
                        "AC Repair",
                        "Low Cooling or Refrigerant Leak",
                        "Gas pressure depletion, clogged outdoor condenser coil, or faulty starting capacitor.",
                        "Turn off AC to prevent compressor overheating until the technician inspects refrigerant pressure.",
                        "AC Deep Cleaning & Gas Refill",
                        600, 1800, "AC Gas Charging & Compressor"
                );
            } else if (sym.contains("water") || sym.contains("leak") || sym.contains("drip")) {
                return new DiagnosisResult(
                        "AC Repair",
                        "Indoor Water Leakage / Choked Drain Line",
                        "Algae or debris blockage in condensate drain pipe or unlevel indoor unit mounting.",
                        "Place a dry towel or bucket beneath indoor unit. Disconnect power to avoid PCB moisture damage.",
                        "AC Drain Line Flushing & Coil Cleaning",
                        350, 650, "AC Maintenance & Piping"
                );
            } else {
                return new DiagnosisResult(
                        "AC Repair",
                        "AC General Performance Diagnostic",
                        "Dust accumulation on blower fan, dirty filters, or thermistor sensor drift.",
                        "Clean dust filters gently with water while waiting for complete professional servicing.",
                        "Comprehensive AC Jet Servicing",
                        450, 850, "AC Servicing"
                );
            }
        } else if (cat.equalsIgnoreCase("Plumbing")) {
            if (sym.contains("pipe") || sym.contains("burst") || sym.contains("heavy leak")) {
                return new DiagnosisResult(
                        "Plumbing",
                        "Major Pipe Rupture or Fitting Separation",
                        "High water pressure surge, aged CPVC joint failure, or corrosion.",
                        "Turn off the main overhead tank ball-valve or water meter inlet shut-off valve immediately.",
                        "Emergency Pipe Joint Replacement",
                        400, 950, "Pipe Fitting & Concealed Plumbing"
                );
            } else if (sym.contains("tap") || sym.contains("faucet") || sym.contains("drip")) {
                return new DiagnosisResult(
                        "Plumbing",
                        "Dripping Tap or Faulty Spindle Cartridge",
                        "Worn out rubber washer, ceramic disc cartridge erosion, or calcium scale buildup.",
                        "Tighten tap gently without excessive torque to avoid snapping internal brass threads.",
                        "Tap Repair & Cartridge Replacement",
                        180, 400, "Tap & Sanitary Installation"
                );
            } else {
                return new DiagnosisResult(
                        "Plumbing",
                        "Drainage Sluggishness or Trap Clog",
                        "Hair, grease, or soap scum buildup in P-trap or waste outlet.",
                        "Avoid pouring chemical caustic drain openers if plastic pipes are installed.",
                        "Drain De-clogging & Trap Cleaning",
                        250, 550, "Drainage Unclogging"
                );
            }
        } else if (cat.equalsIgnoreCase("Appliances") || cat.equalsIgnoreCase("Refrigerator") || cat.equalsIgnoreCase("Washing Machine")) {
            if (sym.contains("spin") || sym.contains("drain") || sym.contains("vibration")) {
                return new DiagnosisResult(
                        "Appliances",
                        "Washing Machine Drum or Drain Pump Malfunction",
                        "Faulty drain pump filter, worn motor belt, or unbalanced suspension springs.",
                        "Unplug power cord and inspect coin trap/filter at the front bottom door.",
                        "Washing Machine Diagnostic & Pump Servicing",
                        400, 1100, "Washing Machine Motor & Drain"
                );
            } else {
                return new DiagnosisResult(
                        "Appliances",
                        "Refrigerator Cooling / Defrost Timer Issue",
                        "Defrost thermostat failure, choked capillary tube, or fan motor stalling.",
                        "Ensure 4 inches of clearance behind the fridge for ventilation. Check door gasket seal.",
                        "Refrigerator Comprehensive Diagnostic",
                        350, 950, "Refrigerator Compressor & Thermostat"
                );
            }
        } else {
            // General Handyman / RO / CCTV / Carpentry
            return new DiagnosisResult(
                    cat,
                    "General Inspection & Servicing",
                    "Component wear and tear or routine scheduled maintenance required.",
                    "Ensure clear access to the work area and note down specific noise or error codes.",
                    cat + " Standard Diagnostic & Servicing",
                    250, 600, cat + " Specialist"
            );
        }
    }
}
