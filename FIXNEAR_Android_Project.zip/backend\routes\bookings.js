const express = require('express');
const router = express.Router();
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

// POST /api/bookings (Create booking)
router.post('/', requireAuth, async (req, res) => {
    try {
        const { provider_id, service_title, problem_description, service_address, scheduled_date, scheduled_time_slot, estimated_cost } = req.body;

        if (!provider_id || !service_title || !problem_description || !service_address || !scheduled_date) {
            return res.status(400).json({ success: false, error: 'Missing required booking fields' });
        }

        const code = 'FN-' + Math.floor(10000 + Math.random() * 90000);

        const result = await db.runAsync(`
            INSERT INTO bookings (
                booking_code, customer_id, provider_id, service_title,
                problem_description, service_address, scheduled_date,
                scheduled_time_slot, estimated_cost, final_cost, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING')
        `, [
            code, req.user.id, provider_id, service_title,
            problem_description, service_address, scheduled_date,
            scheduled_time_slot || '10:00 AM - 12:00 PM',
            estimated_cost || 350.0, estimated_cost || 350.0
        ]);

        const bookingId = result.lastID;

        // Add initial timeline event
        await db.runAsync(`
            INSERT INTO booking_timeline (booking_id, status, title, description)
            VALUES (?, 'PENDING', 'Booking Request Submitted', 'Customer requested repair service. Awaiting professional acceptance.')
        `, [bookingId]);

        res.status(201).json({
            success: true,
            message: 'Booking created successfully',
            data: { id: bookingId, booking_code: code, status: 'PENDING' }
        });
    } catch (err) {
        console.error('Create booking error:', err);
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// GET /api/bookings
router.get('/', requireAuth, async (req, res) => {
    try {
        let sql;
        let params = [req.user.id];

        if (req.user.role === 'PROVIDER') {
            const prov = await db.getAsync('SELECT id FROM provider_profiles WHERE user_id = ?', [req.user.id]);
            if (!prov) return res.json({ success: true, data: [] });
            sql = `
                SELECT b.*, u.name AS customer_name, u.phone AS customer_phone
                FROM bookings b
                JOIN users u ON b.customer_id = u.id
                WHERE b.provider_id = ?
                ORDER BY b.id DESC
            `;
            params = [prov.id];
        } else {
            sql = `
                SELECT b.*, u.name AS provider_name, p.category AS provider_category
                FROM bookings b
                JOIN provider_profiles p ON b.provider_id = p.id
                JOIN users u ON p.user_id = u.id
                WHERE b.customer_id = ?
                ORDER BY b.id DESC
            `;
        }

        const bookings = await db.query(sql, params);
        res.json({ success: true, data: bookings });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

// GET /api/bookings/:id
router.get('/:id', requireAuth, async (req, res) => {
    try {
        const booking = await db.getAsync(`
            SELECT b.*, u_c.name AS customer_name, u_c.phone AS customer_phone,
                   u_p.name AS provider_name, p.category AS provider_category
            FROM bookings b
            JOIN users u_c ON b.customer_id = u_c.id
            JOIN provider_profiles p ON b.provider_id = p.id
            JOIN users u_p ON p.user_id = u_p.id
            WHERE b.id = ?
        `, [req.params.id]);

        if (!booking) {
            return res.status(404).json({ success: false, error: 'Booking not found' });
        }

        const timeline = await db.query(
            'SELECT * FROM booking_timeline WHERE booking_id = ? ORDER BY id ASC',
            [req.params.id]
        );

        res.json({ success: true, data: { ...booking, timeline } });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Database query error' });
    }
});

// PATCH /api/bookings/:id/status
router.patch('/:id/status', requireAuth, async (req, res) => {
    try {
        const { status, reason } = req.body;
        const booking = await db.getAsync('SELECT * FROM bookings WHERE id = ?', [req.params.id]);

        if (!booking) {
            return res.status(404).json({ success: false, error: 'Booking not found' });
        }

        await db.runAsync(
            'UPDATE bookings SET status = ?, rejection_reason = COALESCE(?, rejection_reason), cancellation_reason = COALESCE(?, cancellation_reason) WHERE id = ?',
            [status, status === 'REJECTED' ? reason : null, status === 'CANCELLED' ? reason : null, req.params.id]
        );

        await db.runAsync(
            'INSERT INTO booking_timeline (booking_id, status, title, description) VALUES (?, ?, ?, ?)',
            [req.params.id, status, `Status changed to ${status}`, reason || 'Status updated']
        );

        res.json({ success: true, message: `Booking status updated to ${status}` });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Status update failed' });
    }
});

module.exports = router;
