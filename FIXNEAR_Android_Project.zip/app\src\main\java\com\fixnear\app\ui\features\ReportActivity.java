package com.fixnear.app.ui.features;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class ReportActivity extends AppCompatActivity {

    private ImageView btnReportBack;
    private Spinner spinnerReportReason;
    private TextInputEditText etReportDetails;
    private MaterialButton btnSubmitReport;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        initViews();
        setupSpinner();
        setupListeners();
    }

    private void initViews() {
        btnReportBack = findViewById(R.id.btnReportBack);
        spinnerReportReason = findViewById(R.id.spinnerReportReason);
        etReportDetails = findViewById(R.id.etReportDetails);
        btnSubmitReport = findViewById(R.id.btnSubmitReport);
    }

    private void setupSpinner() {
        String[] reasons = new String[]{
                "Pricing Dispute or Overcharging",
                "Substandard / Incomplete Repair Work",
                "Unprofessional or Discourteous Conduct",
                "Property Damage or Safety Hazard",
                "No-Show / Unannounced Absence",
                "Fraudulent or Misleading Information"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, reasons);
        spinnerReportReason.setAdapter(adapter);
    }

    private void setupListeners() {
        btnReportBack.setOnClickListener(v -> finish());
        btnSubmitReport.setOnClickListener(v -> submitReport());
    }

    private void submitReport() {
        String reason = spinnerReportReason.getSelectedItem().toString();
        String details = etReportDetails.getText() != null ? etReportDetails.getText().toString().trim() : "";

        if (details.length() < 10) {
            etReportDetails.setError("Please describe the incident in detail (at least 10 characters)");
            etReportDetails.requestFocus();
            return;
        }

        long reporterId = sessionManager.getUserId();
        long reportId = dbHelper.submitReport(reporterId, 0, 0, reason, details);

        if (reportId != -1) {
            Toast.makeText(this, "Report received. Trust & Safety will investigate within 24 hours.", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to submit report. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
