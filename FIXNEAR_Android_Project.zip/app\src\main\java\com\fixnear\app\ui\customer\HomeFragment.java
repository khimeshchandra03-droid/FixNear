package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.adapters.CategoryAdapter;
import com.fixnear.app.ui.adapters.ProviderCardAdapter;
import com.fixnear.app.ui.booking.BookingDetailActivity;
import com.fixnear.app.ui.features.NotificationsActivity;
import com.fixnear.app.ui.features.PriceEstimatorActivity;
import com.fixnear.app.ui.features.SmartAssistantActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements ProviderCardAdapter.OnProviderActionListener {

    private TextView tvGreeting;
    private ImageView btnNotifications;
    private MaterialCardView cardSearchBar;
    private RecyclerView rvCategories;
    private RecyclerView rvTopProviders;
    private MaterialCardView cardSmartAssistant, cardPriceEstimator, cardActiveBookingBanner;
    private MaterialButton btnLaunchSmartAssistant;
    private TextView tvActiveBookingTitle, tvActiveBookingStatus, tvActiveBookingDesc, btnViewActiveTimeline;
    private TextView tvSeeAllExplore;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderCardAdapter providerAdapter;
    private long currentBookingId = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_customer_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        initViews(view);
        setupGreeting();
        setupCategories();
        setupTopProviders();
        setupFeatureBanners();
        checkActiveBooking();
    }

    @Override
    public void onResume() {
        super.onResume();
        checkActiveBooking();
        loadProviders();
    }

    private void initViews(View view) {
        tvGreeting = view.findViewById(R.id.tvGreeting);
        btnNotifications = view.findViewById(R.id.btnNotifications);
        cardSearchBar = view.findViewById(R.id.cardSearchBar);
        rvCategories = view.findViewById(R.id.rvCategories);
        rvTopProviders = view.findViewById(R.id.rvTopProviders);
        cardSmartAssistant = view.findViewById(R.id.cardSmartAssistant);
        cardPriceEstimator = view.findViewById(R.id.cardPriceEstimator);
        btnLaunchSmartAssistant = view.findViewById(R.id.btnLaunchSmartAssistant);
        cardActiveBookingBanner = view.findViewById(R.id.cardActiveBookingBanner);
        tvActiveBookingTitle = view.findViewById(R.id.tvActiveBookingTitle);
        tvActiveBookingStatus = view.findViewById(R.id.tvActiveBookingStatus);
        tvActiveBookingDesc = view.findViewById(R.id.tvActiveBookingDesc);
        btnViewActiveTimeline = view.findViewById(R.id.btnViewActiveTimeline);
        tvSeeAllExplore = view.findViewById(R.id.tvSeeAllExplore);
    }

    private void setupGreeting() {
        User user = sessionManager.getCurrentUser();
        if (user != null && user.getName() != null) {
            tvGreeting.setText("Hello, " + user.getName() + " 👋");
        } else {
            tvGreeting.setText("Hello, Guest 👋");
        }

        btnNotifications.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), NotificationsActivity.class));
        });

        cardSearchBar.setOnClickListener(v -> {
            if (getActivity() instanceof CustomerMainActivity) {
                ((CustomerMainActivity) getActivity()).navigateToExplore("All");
            }
        });

        tvSeeAllExplore.setOnClickListener(v -> {
            if (getActivity() instanceof CustomerMainActivity) {
                ((CustomerMainActivity) getActivity()).navigateToExplore("All");
            }
        });
    }

    private void setupCategories() {
        List<CategoryAdapter.CategoryItem> categories = new ArrayList<>();
        categories.add(new CategoryAdapter.CategoryItem("Electrical", R.drawable.ic_fixnear_logo));
        categories.add(new CategoryAdapter.CategoryItem("AC Repair", R.drawable.ic_fixnear_logo));
        categories.add(new CategoryAdapter.CategoryItem("Plumbing", R.drawable.ic_fixnear_logo));
        categories.add(new CategoryAdapter.CategoryItem("Appliances", R.drawable.ic_fixnear_logo));
        categories.add(new CategoryAdapter.CategoryItem("Carpentry", R.drawable.ic_fixnear_logo));
        categories.add(new CategoryAdapter.CategoryItem("CCTV Security", R.drawable.ic_fixnear_logo));

        CategoryAdapter categoryAdapter = new CategoryAdapter(requireContext(), categories, categoryName -> {
            if (getActivity() instanceof CustomerMainActivity) {
                ((CustomerMainActivity) getActivity()).navigateToExplore(categoryName);
            }
        });

        rvCategories.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        rvCategories.setAdapter(categoryAdapter);
    }

    private void setupFeatureBanners() {
        btnLaunchSmartAssistant.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), SmartAssistantActivity.class));
        });

        cardSmartAssistant.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), SmartAssistantActivity.class));
        });

        cardPriceEstimator.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), PriceEstimatorActivity.class));
        });
    }

    private void checkActiveBooking() {
        long customerId = sessionManager.getUserId();
        List<Booking> bookings = dbHelper.getBookingsForCustomer(customerId, null);
        Booking active = null;
        for (Booking b : bookings) {
            if (b.isPending() || b.isAccepted() || b.isScheduled() || b.isInProgress()) {
                active = b;
                break;
            }
        }

        if (active != null) {
            currentBookingId = active.getId();
            cardActiveBookingBanner.setVisibility(View.VISIBLE);
            tvActiveBookingTitle.setText("Active Booking: " + active.getBookingCode());
            tvActiveBookingStatus.setText(active.getStatus());
            tvActiveBookingDesc.setText(active.getServiceTitle() + " with " + active.getProviderName());

            View.OnClickListener clickListener = v -> {
                Intent intent = new Intent(requireContext(), BookingDetailActivity.class);
                intent.putExtra("booking_id", currentBookingId);
                startActivity(intent);
            };
            cardActiveBookingBanner.setOnClickListener(clickListener);
            btnViewActiveTimeline.setOnClickListener(clickListener);
        } else {
            cardActiveBookingBanner.setVisibility(View.GONE);
        }
    }

    private void setupTopProviders() {
        rvTopProviders.setLayoutManager(new LinearLayoutManager(requireContext()));
        providerAdapter = new ProviderCardAdapter(requireContext(), new ArrayList<>(), this);
        rvTopProviders.setAdapter(providerAdapter);
        loadProviders();
    }

    private void loadProviders() {
        long customerId = sessionManager.getUserId();
        List<ProviderProfile> list = dbHelper.getAllProviders(customerId);
        providerAdapter.updateList(list);
    }

    @Override
    public void onProviderClick(ProviderProfile provider) {
        Intent intent = new Intent(requireContext(), ProviderDetailActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onBookClick(ProviderProfile provider) {
        Intent intent = new Intent(requireContext(), BookingActivity.class);
        intent.putExtra("provider_id", provider.getId());
        startActivity(intent);
    }

    @Override
    public void onFavoriteToggle(ProviderProfile provider, int position) {
        long customerId = sessionManager.getUserId();
        boolean isFav = dbHelper.toggleFavorite(customerId, provider.getId());
        provider.setFavorite(isFav);
        providerAdapter.notifyItemChanged(position);
        Toast.makeText(requireContext(), isFav ? "Added to Saved Professionals" : "Removed from Saved", Toast.LENGTH_SHORT).show();
    }
}
