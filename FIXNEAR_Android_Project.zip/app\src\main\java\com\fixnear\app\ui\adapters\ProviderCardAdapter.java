package com.fixnear.app.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.R;
import com.fixnear.app.model.ProviderProfile;
import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

public class ProviderCardAdapter extends RecyclerView.Adapter<ProviderCardAdapter.ViewHolder> {

    public interface OnProviderActionListener {
        void onProviderClick(ProviderProfile provider);
        void onBookClick(ProviderProfile provider);
        void onFavoriteToggle(ProviderProfile provider, int position);
    }

    private final Context context;
    private List<ProviderProfile> providers;
    private final OnProviderActionListener listener;

    public ProviderCardAdapter(Context context, List<ProviderProfile> providers, OnProviderActionListener listener) {
        this.context = context;
        this.providers = providers;
        this.listener = listener;
    }

    public void updateList(List<ProviderProfile> list) {
        this.providers = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_provider_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProviderProfile p = providers.get(position);

        holder.tvName.setText(p.getName());
        holder.tvCategory.setText(String.format(Locale.getDefault(), "%s Specialist • %d yrs exp",
                p.getCategory(), p.getExperienceYears()));
        holder.tvSkills.setText(p.getSkills() != null && !p.getSkills().isEmpty() ? p.getSkills() : p.getBio());

        // Verification Badge logic - strict distinction!
        if (p.isVerified()) {
            holder.tvVerificationBadge.setText("Govt ID Verified");
            holder.tvVerificationBadge.setBackgroundResource(R.drawable.bg_badge_verified);
            holder.tvVerificationBadge.setTextColor(ContextCompat.getColor(context, R.color.badge_verified));
            holder.tvVerificationBadge.setVisibility(View.VISIBLE);
        } else if (p.isPendingReview()) {
            holder.tvVerificationBadge.setText("Verification Pending");
            holder.tvVerificationBadge.setBackgroundResource(R.drawable.bg_badge_pending);
            holder.tvVerificationBadge.setTextColor(ContextCompat.getColor(context, R.color.status_pending));
            holder.tvVerificationBadge.setVisibility(View.VISIBLE);
        } else {
            holder.tvVerificationBadge.setText("Unverified");
            holder.tvVerificationBadge.setBackgroundResource(R.drawable.bg_badge_unverified);
            holder.tvVerificationBadge.setTextColor(ContextCompat.getColor(context, R.color.badge_unverified));
            holder.tvVerificationBadge.setVisibility(View.VISIBLE);
        }

        // Trust Score Badge
        holder.tvTrustScore.setText(String.format(Locale.getDefault(), "Trust: %d/100", p.getTrustScore()));

        // Ratings
        holder.tvRating.setText(String.format(Locale.getDefault(), "%.1f", p.getRatingAvg()));
        holder.tvReviewCount.setText(String.format(Locale.getDefault(), "(%d)", p.getRatingCount()));

        // Starting rate
        holder.tvStartingRate.setText(String.format(Locale.getDefault(), "From ₹%.0f visit", p.getHourlyRate()));

        // Favorite icon
        holder.btnFavorite.setImageResource(p.isFavorite() ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);
        holder.btnFavorite.setColorFilter(p.isFavorite() ?
                ContextCompat.getColor(context, R.color.status_cancelled) :
                ContextCompat.getColor(context, R.color.text_secondary));

        // Click handlers
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onProviderClick(p);
        });

        holder.btnBook.setOnClickListener(v -> {
            if (listener != null) listener.onBookClick(p);
        });

        holder.btnFavorite.setOnClickListener(v -> {
            if (listener != null) listener.onFavoriteToggle(p, holder.getAdapterPosition());
        });
    }

    @Override
    public int getItemCount() {
        return providers.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvSkills, tvVerificationBadge, tvTrustScore, tvRating, tvReviewCount, tvStartingRate;
        ImageView btnFavorite, imgAvatar;
        MaterialButton btnBook;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvProviderName);
            tvCategory = itemView.findViewById(R.id.tvProviderCategory);
            tvSkills = itemView.findViewById(R.id.tvSkillsSnippet);
            tvVerificationBadge = itemView.findViewById(R.id.tvVerificationBadge);
            tvTrustScore = itemView.findViewById(R.id.tvTrustScoreBadge);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvReviewCount = itemView.findViewById(R.id.tvReviewCount);
            tvStartingRate = itemView.findViewById(R.id.tvStartingRate);
            btnFavorite = itemView.findViewById(R.id.btnFavorite);
            imgAvatar = itemView.findViewById(R.id.imgProviderAvatar);
            btnBook = itemView.findViewById(R.id.btnBookService);
        }
    }
}
