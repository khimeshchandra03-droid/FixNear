package com.fixnear.app.ui.features;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.R;
import com.fixnear.app.engine.SmartAssistantEngine;
import com.fixnear.app.ui.customer.CustomerMainActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Locale;

public class SmartAssistantActivity extends AppCompatActivity {

    private ImageView btnAssistantBack;
    private Spinner spinnerAssistantCategory, spinnerAssistantUrgency;
    private TextInputEditText etAssistantSymptom;
    private MaterialButton btnRunDiagnosis;

    private MaterialCardView cardDiagnosisResult;
    private TextView tvDiagnosisIssue, tvDiagnosisCause, tvDiagnosisSafety, tvDiagnosisService, tvDiagnosisCost;
    private MaterialButton btnFindMatchingSpecialists;

    private SmartAssistantEngine.DiagnosisResult lastResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_assistant);

        initViews();
        setupSpinners();
        setupListeners();
    }

    private void initViews() {
        btnAssistantBack = findViewById(R.id.btnAssistantBack);
        spinnerAssistantCategory = findViewById(R.id.spinnerAssistantCategory);
        spinnerAssistantUrgency = findViewById(R.id.spinnerAssistantUrgency);
        etAssistantSymptom = findViewById(R.id.etAssistantSymptom);
        btnRunDiagnosis = findViewById(R.id.btnRunDiagnosis);

        cardDiagnosisResult = findViewById(R.id.cardDiagnosisResult);
        tvDiagnosisIssue = findViewById(R.id.tvDiagnosisIssue);
        tvDiagnosisCause = findViewById(R.id.tvDiagnosisCause);
        tvDiagnosisSafety = findViewById(R.id.tvDiagnosisSafety);
        tvDiagnosisService = findViewById(R.id.tvDiagnosisService);
        tvDiagnosisCost = findViewById(R.id.tvDiagnosisCost);
        btnFindMatchingSpecialists = findViewById(R.id.btnFindMatchingSpecialists);
    }

    private void setupSpinners() {
        String[] categories = new String[]{
                "Electrical",
                "AC Repair",
                "Plumbing",
                "Appliances",
                "Carpentry",
                "CCTV Security"
        };
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinnerAssistantCategory.setAdapter(catAdapter);

        String[] urgencies = new String[]{
                "Normal (Next 24-48 Hours)",
                "Urgent (Within 4 Hours)",
                "Critical / Hazardous Issue"
        };
        ArrayAdapter<String> urgAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, urgencies);
        spinnerAssistantUrgency.setAdapter(urgAdapter);
    }

    private void setupListeners() {
        btnAssistantBack.setOnClickListener(v -> finish());

        btnRunDiagnosis.setOnClickListener(v -> runDiagnosis());

        btnFindMatchingSpecialists.setOnClickListener(v -> {
            if (lastResult != null) {
                Intent intent = new Intent(this, CustomerMainActivity.class);
                intent.putExtra("open_category", lastResult.getCategory());
                startActivity(intent);
                finish();
            }
        });
    }

    private void runDiagnosis() {
        String category = spinnerAssistantCategory.getSelectedItem().toString();
        String symptom = etAssistantSymptom.getText() != null ? etAssistantSymptom.getText().toString().trim() : "";
        String urgency = spinnerAssistantUrgency.getSelectedItem().toString();

        if (symptom.isEmpty()) {
            etAssistantSymptom.setError("Please describe the symptom (e.g. spark, water drip, not spinning)");
            etAssistantSymptom.requestFocus();
            return;
        }

        lastResult = SmartAssistantEngine.analyzeIssue(category, symptom, urgency);

        tvDiagnosisIssue.setText("Suspected: " + lastResult.getIssueSummary());
        tvDiagnosisCause.setText("Probable Cause: " + lastResult.getPreliminaryCause());
        tvDiagnosisSafety.setText("⚠️ " + lastResult.getSafetyPrecaution());
        tvDiagnosisService.setText("Recommended Service: " + lastResult.getRecommendedService());
        tvDiagnosisCost.setText(String.format(Locale.getDefault(), "Estimated Tariff Range: ₹%.0f - ₹%.0f",
                lastResult.getEstimatedMinCost(), lastResult.getEstimatedMaxCost()));

        cardDiagnosisResult.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Triage completed successfully", Toast.LENGTH_SHORT).show();
    }
}
