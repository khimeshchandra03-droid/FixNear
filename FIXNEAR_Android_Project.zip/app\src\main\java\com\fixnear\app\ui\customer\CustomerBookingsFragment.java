package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Booking;
import com.fixnear.app.ui.adapters.BookingAdapter;
import com.fixnear.app.ui.booking.BookingDetailActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class CustomerBookingsFragment extends Fragment implements BookingAdapter.OnBookingClickListener {

    private ChipGroup chipGroupBookingStatus;
    private RecyclerView rvCustomerBookings;
    private LinearLayout layoutBookingsEmptyState;
    private MaterialButton btnBookFirstService;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private BookingAdapter adapter;
    private String currentStatusFilter = "ALL";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_customer_bookings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        initViews(view);
        setupRecyclerView();
        setupFilters();
        loadBookings();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadBookings();
    }

    private void initViews(View view) {
        chipGroupBookingStatus = view.findViewById(R.id.chipGroupBookingStatus);
        rvCustomerBookings = view.findViewById(R.id.rvCustomerBookings);
        layoutBookingsEmptyState = view.findViewById(R.id.layoutBookingsEmptyState);
        btnBookFirstService = view.findViewById(R.id.btnBookFirstService);

        btnBookFirstService.setOnClickListener(v -> {
            if (getActivity() instanceof CustomerMainActivity) {
                ((CustomerMainActivity) getActivity()).navigateToExplore("All");
            }
        });
    }

    private void setupRecyclerView() {
        rvCustomerBookings.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BookingAdapter(requireContext(), new ArrayList<>(), false, this);
        rvCustomerBookings.setAdapter(adapter);
    }

    private void setupFilters() {
        chipGroupBookingStatus.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipBookingPending) {
                currentStatusFilter = Booking.STATUS_PENDING;
            } else if (checkedId == R.id.chipBookingActive) {
                currentStatusFilter = Booking.STATUS_IN_PROGRESS;
            } else if (checkedId == R.id.chipBookingCompleted) {
                currentStatusFilter = Booking.STATUS_COMPLETED;
            } else if (checkedId == R.id.chipBookingCancelled) {
                currentStatusFilter = Booking.STATUS_CANCELLED;
            } else {
                currentStatusFilter = "ALL";
            }
            loadBookings();
        });
    }

    private void loadBookings() {
        long customerId = sessionManager.getUserId();
        List<Booking> list = dbHelper.getBookingsForCustomer(customerId, currentStatusFilter);
        adapter.updateList(list);

        if (list.isEmpty()) {
            layoutBookingsEmptyState.setVisibility(View.VISIBLE);
            rvCustomerBookings.setVisibility(View.GONE);
        } else {
            layoutBookingsEmptyState.setVisibility(View.GONE);
            rvCustomerBookings.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBookingClick(Booking booking) {
        Intent intent = new Intent(requireContext(), BookingDetailActivity.class);
        intent.putExtra("booking_id", booking.getId());
        startActivity(intent);
    }
}
