package com.fixnear.app.ui.chat;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.Message;
import com.fixnear.app.ui.adapters.MessageAdapter;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private ImageView btnChatBack;
    private TextView tvChatTitle;
    private RecyclerView rvMessages;
    private EditText etChatMessage;
    private MaterialButton btnSendMessage;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private MessageAdapter adapter;
    private List<Message> messageList = new ArrayList<>();

    private long bookingId = -1;
    private long otherUserId = -1;
    private String otherUserName = "Technician";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        bookingId = getIntent().getLongExtra("booking_id", -1);
        otherUserId = getIntent().getLongExtra("other_user_id", -1);
        String name = getIntent().getStringExtra("other_user_name");
        if (name != null) otherUserName = name;

        initViews();
        setupRecyclerView();
        setupListeners();
        loadMessages();
    }

    private void initViews() {
        btnChatBack = findViewById(R.id.btnChatBack);
        tvChatTitle = findViewById(R.id.tvChatTitle);
        rvMessages = findViewById(R.id.rvMessages);
        etChatMessage = findViewById(R.id.etChatMessage);
        btnSendMessage = findViewById(R.id.btnSendMessage);

        tvChatTitle.setText(otherUserName);
    }

    private void setupRecyclerView() {
        long currentUserId = sessionManager.getUserId();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvMessages.setLayoutManager(layoutManager);
        adapter = new MessageAdapter(this, messageList, currentUserId);
        rvMessages.setAdapter(adapter);
    }

    private void setupListeners() {
        btnChatBack.setOnClickListener(v -> finish());
        btnSendMessage.setOnClickListener(v -> sendMessage());
    }

    private void loadMessages() {
        long currentUserId = sessionManager.getUserId();
        List<Message> msgs = dbHelper.getMessagesBetween(currentUserId, otherUserId);
        messageList.clear();
        messageList.addAll(msgs);
        adapter.notifyDataSetChanged();
        if (!messageList.isEmpty()) {
            rvMessages.scrollToPosition(messageList.size() - 1);
        }
    }

    private void sendMessage() {
        String text = etChatMessage.getText().toString().trim();
        if (text.isEmpty()) return;

        long currentUserId = sessionManager.getUserId();
        long msgId = dbHelper.sendMessage(bookingId, currentUserId, otherUserId, text);

        if (msgId != -1) {
            etChatMessage.setText("");
            loadMessages();
        } else {
            Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
        }
    }
}
