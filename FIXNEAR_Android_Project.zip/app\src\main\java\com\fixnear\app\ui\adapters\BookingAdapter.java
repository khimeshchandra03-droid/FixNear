package com.fixnear.app.ui.adapters;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.R;
import com.fixnear.app.model.Booking;

import java.util.List;
import java.util.Locale;

public class BookingAdapter extends RecyclerView.Adapter<BookingAdapter.ViewHolder> {

    public interface OnBookingClickListener {
        void onBookingClick(Booking booking);
    }

    private final Context context;
    private List<Booking> bookings;
    private final boolean isProviderView;
    private final OnBookingClickListener listener;

    public BookingAdapter(Context context, List<Booking> bookings, boolean isProviderView, OnBookingClickListener listener) {
        this.context = context;
        this.bookings = bookings;
        this.isProviderView = isProviderView;
        this.listener = listener;
    }

    public void updateList(List<Booking> list) {
        this.bookings = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Booking b = bookings.get(position);

        holder.tvBookingCode.setText(b.getBookingCode());
        holder.tvServiceTitle.setText(b.getServiceTitle());

        if (isProviderView) {
            holder.tvPartyName.setText("Customer: " + b.getCustomerName() + " (" + b.getCustomerPhone() + ")");
        } else {
            holder.tvPartyName.setText("Specialist: " + b.getProviderName() + " (" + b.getProviderCategory() + ")");
        }

        holder.tvScheduledTime.setText(String.format("Scheduled: %s • %s", b.getScheduledDate(), b.getScheduledTimeSlot()));
        holder.tvEstimatedCost.setText(String.format(Locale.getDefault(), "Est: ₹%.0f", b.getEstimatedCost()));

        // Status Styling
        holder.tvStatus.setText(b.getStatus());
        applyStatusColor(holder.tvStatus, b.getStatus());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onBookingClick(b);
        });
    }

    private void applyStatusColor(TextView tvStatus, String status) {
        int textColor;
        int bgColor;

        switch (status) {
            case Booking.STATUS_ACCEPTED:
            case Booking.STATUS_SCHEDULED:
                textColor = ContextCompat.getColor(context, R.color.status_accepted);
                bgColor = ContextCompat.getColor(context, R.color.status_accepted_bg);
                break;
            case Booking.STATUS_IN_PROGRESS:
                textColor = ContextCompat.getColor(context, R.color.status_in_progress);
                bgColor = ContextCompat.getColor(context, R.color.status_in_progress_bg);
                break;
            case Booking.STATUS_COMPLETED:
                textColor = ContextCompat.getColor(context, R.color.status_completed);
                bgColor = ContextCompat.getColor(context, R.color.status_completed_bg);
                break;
            case Booking.STATUS_CANCELLED:
            case Booking.STATUS_REJECTED:
                textColor = ContextCompat.getColor(context, R.color.status_cancelled);
                bgColor = ContextCompat.getColor(context, R.color.status_cancelled_bg);
                break;
            case Booking.STATUS_PENDING:
            default:
                textColor = ContextCompat.getColor(context, R.color.status_pending);
                bgColor = ContextCompat.getColor(context, R.color.status_pending_bg);
                break;
        }

        tvStatus.setTextColor(textColor);
        tvStatus.setBackgroundTintList(ColorStateList.valueOf(bgColor));
    }

    @Override
    public int getItemCount() {
        return bookings.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvBookingCode, tvStatus, tvServiceTitle, tvPartyName, tvScheduledTime, tvEstimatedCost;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBookingCode = itemView.findViewById(R.id.tvBookingCode);
            tvStatus = itemView.findViewById(R.id.tvBookingStatus);
            tvServiceTitle = itemView.findViewById(R.id.tvServiceTitle);
            tvPartyName = itemView.findViewById(R.id.tvPartyName);
            tvScheduledTime = itemView.findViewById(R.id.tvScheduledTime);
            tvEstimatedCost = itemView.findViewById(R.id.tvEstimatedCost);
        }
    }
}
