package com.fixnear.app.ui.features;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.R;
import com.fixnear.app.engine.PriceEstimatorEngine;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.Locale;

public class PriceEstimatorActivity extends AppCompatActivity {

    private ImageView btnEstimatorBack;
    private Spinner spinnerEstCategory, spinnerEstRepairType;
    private CheckBox cbUrgentService;
    private MaterialButton btnCalculateEstimate;

    private MaterialCardView cardEstResult;
    private TextView tvEstVisitFee, tvEstLaborFee, tvEstPartsFee, tvEstTotalRange, tvEstDisclaimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_estimator);

        initViews();
        setupSpinners();
        setupListeners();
    }

    private void initViews() {
        btnEstimatorBack = findViewById(R.id.btnEstimatorBack);
        spinnerEstCategory = findViewById(R.id.spinnerEstCategory);
        spinnerEstRepairType = findViewById(R.id.spinnerEstRepairType);
        cbUrgentService = findViewById(R.id.cbUrgentService);
        btnCalculateEstimate = findViewById(R.id.btnCalculateEstimate);

        cardEstResult = findViewById(R.id.cardEstResult);
        tvEstVisitFee = findViewById(R.id.tvEstVisitFee);
        tvEstLaborFee = findViewById(R.id.tvEstLaborFee);
        tvEstPartsFee = findViewById(R.id.tvEstPartsFee);
        tvEstTotalRange = findViewById(R.id.tvEstTotalRange);
        tvEstDisclaimer = findViewById(R.id.tvEstDisclaimer);
    }

    private void setupSpinners() {
        String[] categories = new String[]{"Electrical", "AC Repair", "Plumbing", "Appliances", "CCTV Security", "RO Purifier"};
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinnerEstCategory.setAdapter(catAdapter);

        spinnerEstCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateRepairTypes(categories[position]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        updateRepairTypes("Electrical");
    }

    private void updateRepairTypes(String category) {
        String[] types;
        if ("AC Repair".equalsIgnoreCase(category)) {
            types = new String[]{"Jet Foam Deep Cleaning", "Gas Leak Testing & Refill", "Drain Pipe Flushing", "Capacitor / Relay Replacement"};
        } else if ("Plumbing".equalsIgnoreCase(category)) {
            types = new String[]{"Tap & Mixer Cartridge Repair", "Drain Unclogging", "Water Tank Float Valve", "Concealed Pipe Joint Fix"};
        } else if ("Appliances".equalsIgnoreCase(category)) {
            types = new String[]{"Washing Machine Motor & Drain", "Refrigerator Thermostat / Cooling", "Microwave Magnetron Diagnostic"};
        } else if ("CCTV Security".equalsIgnoreCase(category)) {
            types = new String[]{"Camera Re-alignment", "DVR Hard Drive Setup", "Mobile Live View Config"};
        } else if ("RO Purifier".equalsIgnoreCase(category)) {
            types = new String[]{"Sediment & Carbon Filter Change", "RO Membrane Replacement", "Booster Pump Servicing"};
        } else {
            types = new String[]{"Switchboard / Socket Repair", "MCB Breaker Replacement", "Ceiling Fan Repair & Rewiring", "Inverter Line Bypass"};
        }

        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types);
        spinnerEstRepairType.setAdapter(typeAdapter);
    }

    private void setupListeners() {
        btnEstimatorBack.setOnClickListener(v -> finish());
        btnCalculateEstimate.setOnClickListener(v -> calculate());
    }

    private void calculate() {
        String category = spinnerEstCategory.getSelectedItem().toString();
        String repairType = spinnerEstRepairType.getSelectedItem().toString();
        boolean isUrgent = cbUrgentService.isChecked();

        PriceEstimatorEngine.PriceEstimateBreakdown breakdown = PriceEstimatorEngine.estimate(category, repairType, isUrgent);

        tvEstVisitFee.setText(String.format(Locale.getDefault(), "₹%.0f", breakdown.getVisitInspectionFee()));
        tvEstLaborFee.setText(String.format(Locale.getDefault(), "₹%.0f - ₹%.0f", breakdown.getLaborMin(), breakdown.getLaborMax()));
        tvEstPartsFee.setText(String.format(Locale.getDefault(), "₹%.0f - ₹%.0f", breakdown.getPartsEstimateMin(), breakdown.getPartsEstimateMax()));
        tvEstTotalRange.setText(String.format(Locale.getDefault(), "₹%.0f - ₹%.0f", breakdown.getTotalEstimateMin(), breakdown.getTotalEstimateMax()));
        tvEstDisclaimer.setText(breakdown.getDisclaimer());

        cardEstResult.setVisibility(View.VISIBLE);
    }
}
