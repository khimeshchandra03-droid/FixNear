package com.fixnear.app.ui.provider;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.fixnear.app.R;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.ui.auth.LoginActivity;
import com.fixnear.app.ui.customer.CustomerMessagesFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ProviderMainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_main);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        bottomNav = findViewById(R.id.bottomNavProvider);
        setupBottomNav();

        if (savedInstanceState == null) {
            loadFragment(new ProviderDashboardFragment());
        }
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment selectedFragment = null;

            if (id == R.id.nav_provider_dashboard) {
                selectedFragment = new ProviderDashboardFragment();
            } else if (id == R.id.nav_provider_requests) {
                selectedFragment = new ProviderRequestsFragment();
            } else if (id == R.id.nav_provider_messages) {
                selectedFragment = new CustomerMessagesFragment();
            } else if (id == R.id.nav_provider_profile) {
                selectedFragment = new ProviderProfileFragment();
            }

            if (selectedFragment != null) {
                loadFragment(selectedFragment);
                return true;
            }
            return false;
        });
    }

    public void navigateToRequests() {
        bottomNav.setSelectedItemId(R.id.nav_provider_requests);
        loadFragment(new ProviderRequestsFragment());
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.providerFragmentContainer, fragment)
                .commit();
    }
}
