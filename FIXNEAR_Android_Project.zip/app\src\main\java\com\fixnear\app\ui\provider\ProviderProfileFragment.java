package com.fixnear.app.ui.provider;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.auth.LoginActivity;
import com.fixnear.app.ui.features.NotificationsActivity;
import com.fixnear.app.ui.features.PriceEstimatorActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class ProviderProfileFragment extends Fragment {

    private TextView tvProvName, tvProvCategory, tvProvEmail;
    private SwitchMaterial switchAvailability;
    private LinearLayout menuProviderVerification, menuProviderNotifications, menuProviderRates;
    private MaterialButton btnProviderLogout;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderProfile profile;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_provider_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(requireContext());

        initViews(view);
        loadProfileData();
        setupListeners();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProfileData();
    }

    private void initViews(View view) {
        tvProvName = view.findViewById(R.id.tvProvName);
        tvProvCategory = view.findViewById(R.id.tvProvCategory);
        tvProvEmail = view.findViewById(R.id.tvProvEmail);
        switchAvailability = view.findViewById(R.id.switchAvailability);
        menuProviderVerification = view.findViewById(R.id.menuProviderVerification);
        menuProviderNotifications = view.findViewById(R.id.menuProviderNotifications);
        menuProviderRates = view.findViewById(R.id.menuProviderRates);
        btnProviderLogout = view.findViewById(R.id.btnProviderLogout);
    }

    private void loadProfileData() {
        long userId = sessionManager.getUserId();
        profile = dbHelper.getProviderByUserId(userId);
        User user = sessionManager.getCurrentUser();

        if (user != null) {
            tvProvName.setText(user.getName());
            tvProvEmail.setText(user.getEmail());
        }

        if (profile != null) {
            tvProvCategory.setText(profile.getCategory() + " Specialist • " + profile.getExperienceYears() + " yrs exp");
            switchAvailability.setChecked(profile.isAvailable());
        }
    }

    private void setupListeners() {
        switchAvailability.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (profile != null) {
                profile.setAvailable(isChecked);
                ContentValues cv = new ContentValues();
                cv.put("is_available", isChecked ? 1 : 0);
                dbHelper.getWritableDatabase().update(DatabaseHelper.TABLE_PROVIDERS, cv, "id = ?", new String[]{String.valueOf(profile.getId())});
                Toast.makeText(requireContext(), isChecked ? "You are now ONLINE and accepting requests" : "You are now OFFLINE", Toast.LENGTH_SHORT).show();
            }
        });

        menuProviderVerification.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), VerificationActivity.class));
        });

        menuProviderNotifications.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), NotificationsActivity.class));
        });

        menuProviderRates.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), PriceEstimatorActivity.class));
        });

        btnProviderLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Sign Out")
                    .setMessage("Are you sure you want to sign out?")
                    .setPositiveButton("Sign Out", (dialog, which) -> {
                        sessionManager.logout();
                        Intent intent = new Intent(requireContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        requireActivity().finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}
