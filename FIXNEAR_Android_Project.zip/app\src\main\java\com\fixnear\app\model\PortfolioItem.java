package com.fixnear.app.model;

import java.io.Serializable;

public class PortfolioItem implements Serializable {
    private long id;
    private long providerId;
    private String title;
    private String beforeDescription;
    private String afterDescription;
    private String category;
    private String createdAt;

    public PortfolioItem() {}

    public PortfolioItem(long id, long providerId, String title, String beforeDescription,
                         String afterDescription, String category, String createdAt) {
        this.id = id;
        this.providerId = providerId;
        this.title = title;
        this.beforeDescription = beforeDescription;
        this.afterDescription = afterDescription;
        this.category = category;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getProviderId() { return providerId; }
    public void setProviderId(long providerId) { this.providerId = providerId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getBeforeDescription() { return beforeDescription; }
    public void setBeforeDescription(String beforeDescription) { this.beforeDescription = beforeDescription; }

    public String getAfterDescription() { return afterDescription; }
    public void setAfterDescription(String afterDescription) { this.afterDescription = afterDescription; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
