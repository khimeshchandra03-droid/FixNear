package com.fixnear.app.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SecurityUtils;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.admin.AdminMainActivity;
import com.fixnear.app.ui.customer.CustomerMainActivity;
import com.fixnear.app.ui.provider.ProviderMainActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private MaterialButton btnLogin;
    private TextView tvGoToRegister;
    private MaterialButton btnQuickCustomer, btnQuickProvider, btnQuickAdmin;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);
        btnQuickCustomer = findViewById(R.id.btnQuickCustomer);
        btnQuickProvider = findViewById(R.id.btnQuickProvider);
        btnQuickAdmin = findViewById(R.id.btnQuickAdmin);
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> performLogin());

        tvGoToRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });

        // Quick login credentials helpers for evaluation
        btnQuickCustomer.setOnClickListener(v -> {
            etEmail.setText("customer@fixnear.com");
            etPassword.setText("cust123");
        });

        btnQuickProvider.setOnClickListener(v -> {
            etEmail.setText("provider@fixnear.com");
            etPassword.setText("prov123");
        });

        btnQuickAdmin.setOnClickListener(v -> {
            etEmail.setText("admin@fixnear.com");
            etPassword.setText("admin123");
        });
    }

    private void performLogin() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        if (email.isEmpty()) {
            etEmail.setError("Please enter your email");
            etEmail.requestFocus();
            return;
        }

        if (!SecurityUtils.isValidEmail(email)) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            etPassword.setError("Please enter your password");
            etPassword.requestFocus();
            return;
        }

        User user = dbHelper.authenticateUser(email, password);
        if (user != null) {
            sessionManager.saveUserSession(user);
            Toast.makeText(this, "Welcome back, " + user.getName(), Toast.LENGTH_SHORT).show();
            navigateForUser(user);
        } else {
            Toast.makeText(this, "Invalid email or password. Please try again.", Toast.LENGTH_LONG).show();
        }
    }

    private void navigateForUser(User user) {
        Intent intent;
        if (user.isAdmin()) {
            intent = new Intent(this, AdminMainActivity.class);
        } else if (user.isProvider()) {
            intent = new Intent(this, ProviderMainActivity.class);
        } else {
            intent = new Intent(this, CustomerMainActivity.class);
        }
        startActivity(intent);
        finish();
    }
}
