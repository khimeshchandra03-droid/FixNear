package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.fixnear.app.R;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.ui.auth.LoginActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class CustomerMainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_main);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        bottomNav = findViewById(R.id.bottomNavCustomer);
        setupBottomNav();

        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
        }
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment selectedFragment = null;

            if (id == R.id.nav_customer_home) {
                selectedFragment = new HomeFragment();
            } else if (id == R.id.nav_customer_explore) {
                selectedFragment = new ExploreFragment();
            } else if (id == R.id.nav_customer_bookings) {
                selectedFragment = new CustomerBookingsFragment();
            } else if (id == R.id.nav_customer_messages) {
                selectedFragment = new CustomerMessagesFragment();
            } else if (id == R.id.nav_customer_profile) {
                selectedFragment = new CustomerProfileFragment();
            }

            if (selectedFragment != null) {
                loadFragment(selectedFragment);
                return true;
            }
            return false;
        });
    }

    public void navigateToExplore(String category) {
        bottomNav.setSelectedItemId(R.id.nav_customer_explore);
        ExploreFragment fragment = ExploreFragment.newInstance(category);
        loadFragment(fragment);
    }

    public void navigateToBookings() {
        bottomNav.setSelectedItemId(R.id.nav_customer_bookings);
        loadFragment(new CustomerBookingsFragment());
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.customerFragmentContainer, fragment)
                .commit();
    }
}
