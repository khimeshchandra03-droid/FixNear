const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { requireAuth, JWT_SECRET } = require('../middleware/auth');

// POST /api/auth/register
router.post('/register', async (req, res) => {
    try {
        const { name, email, password, phone, role } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ success: false, error: 'Name, email, and password are required' });
        }

        const normalizedEmail = email.trim().toLowerCase();
        const existing = await db.getAsync('SELECT id FROM users WHERE LOWER(email) = ?', [normalizedEmail]);
        if (existing) {
            return res.status(409).json({ success: false, error: 'Account with this email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const assignedRole = role === 'PROVIDER' ? 'PROVIDER' : 'CUSTOMER';

        const result = await db.runAsync(
            'INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)',
            [name.trim(), normalizedEmail, hashedPassword, phone || '', assignedRole]
        );

        const userId = result.lastID;

        // If provider, create initial unverified profile
        if (assignedRole === 'PROVIDER') {
            await db.runAsync(
                `INSERT INTO provider_profiles (user_id, category, skills, experience_years, hourly_rate, service_area, verification_status, trust_score)
                 VALUES (?, 'Electrical', 'General Servicing', 1, 250.0, 'Central District', 'NOT_SUBMITTED', 20)`,
                [userId]
            );
        }

        const token = jwt.sign({ id: userId, email: normalizedEmail, role: assignedRole }, JWT_SECRET, { expiresIn: '7d' });

        return res.status(201).json({
            success: true,
            message: 'User registered successfully',
            token,
            user: { id: userId, name, email: normalizedEmail, role: assignedRole }
        });
    } catch (err) {
        console.error('Register error:', err);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ success: false, error: 'Email and password are required' });
        }

        const normalizedEmail = email.trim().toLowerCase();
        const user = await db.getAsync('SELECT * FROM users WHERE LOWER(email) = ?', [normalizedEmail]);
        if (!user) {
            return res.status(401).json({ success: false, error: 'Invalid credentials' });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ success: false, error: 'Invalid credentials' });
        }

        const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });

        return res.json({
            success: true,
            message: 'Login successful',
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role
            }
        });
    } catch (err) {
        console.error('Login error:', err);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
    try {
        const user = await db.getAsync('SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?', [req.user.id]);
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });
        res.json({ success: true, user });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

module.exports = router;
