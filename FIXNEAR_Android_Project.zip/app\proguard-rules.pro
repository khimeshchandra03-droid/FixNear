# FixNear Proguard rules
-keepattributes *Annotation*
-keepclassmembers class * {
    public <init>(...);
}
