package com.fixnear.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.R;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.User;
import com.fixnear.app.ui.admin.AdminMainActivity;
import com.fixnear.app.ui.auth.LoginActivity;
import com.fixnear.app.ui.customer.CustomerMainActivity;
import com.fixnear.app.ui.provider.ProviderMainActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            SessionManager sessionManager = new SessionManager(SplashActivity.this);
            if (sessionManager.isLoggedIn()) {
                String role = sessionManager.getUserRole();
                if (User.ROLE_ADMIN.equalsIgnoreCase(role)) {
                    startActivity(new Intent(SplashActivity.this, AdminMainActivity.class));
                } else if (User.ROLE_PROVIDER.equalsIgnoreCase(role)) {
                    startActivity(new Intent(SplashActivity.this, ProviderMainActivity.class));
                } else {
                    startActivity(new Intent(SplashActivity.this, CustomerMainActivity.class));
                }
            } else {
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }
            finish();
        }, 1200);
    }
}
