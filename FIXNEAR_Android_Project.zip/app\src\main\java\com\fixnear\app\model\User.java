package com.fixnear.app.model;

import java.io.Serializable;

public class User implements Serializable {
    public static final String ROLE_CUSTOMER = "CUSTOMER";
    public static final String ROLE_PROVIDER = "PROVIDER";
    public static final String ROLE_ADMIN = "ADMIN";

    private long id;
    private String name;
    private String email;
    private String phone;
    private String role;
    private String profilePhoto;
    private String createdAt;

    public User() {}

    public User(long id, String name, String email, String phone, String role, String profilePhoto, String createdAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.role = role;
        this.profilePhoto = profilePhoto;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getProfilePhoto() { return profilePhoto; }
    public void setProfilePhoto(String profilePhoto) { this.profilePhoto = profilePhoto; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public boolean isCustomer() { return ROLE_CUSTOMER.equalsIgnoreCase(role); }
    public boolean isProvider() { return ROLE_PROVIDER.equalsIgnoreCase(role); }
    public boolean isAdmin() { return ROLE_ADMIN.equalsIgnoreCase(role); }
}
