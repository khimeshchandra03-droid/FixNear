package com.fixnear.app.ui.customer;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.ui.booking.BookingDetailActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class BookingActivity extends AppCompatActivity {

    private ImageView btnBookingBack;
    private TextView tvBookingProviderSummary;
    private TextInputEditText etServiceTitle, etProblemDesc, etAddress, etDate;
    private Spinner spinnerTimeSlot;
    private TextView tvBreakdownVisit, tvBreakdownLabor, tvTotalEstimate;
    private MaterialButton btnSubmitBooking;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderProfile provider;
    private Calendar calendar;

    private double visitFee = 199.0;
    private double estimatedLabor = 150.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);
        calendar = Calendar.getInstance();

        long providerId = getIntent().getLongExtra("provider_id", -1);
        provider = dbHelper.getProviderById(providerId);
        if (provider == null) {
            Toast.makeText(this, "Specialist unavailable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        setupProviderData();
        setupDatePicker();
        setupTimeSlots();
        setupListeners();
    }

    private void initViews() {
        btnBookingBack = findViewById(R.id.btnBookingBack);
        tvBookingProviderSummary = findViewById(R.id.tvBookingProviderSummary);
        etServiceTitle = findViewById(R.id.etServiceTitle);
        etProblemDesc = findViewById(R.id.etProblemDesc);
        etAddress = findViewById(R.id.etAddress);
        etDate = findViewById(R.id.etDate);
        spinnerTimeSlot = findViewById(R.id.spinnerTimeSlot);
        tvBreakdownVisit = findViewById(R.id.tvBreakdownVisit);
        tvBreakdownLabor = findViewById(R.id.tvBreakdownLabor);
        tvTotalEstimate = findViewById(R.id.tvTotalEstimate);
        btnSubmitBooking = findViewById(R.id.btnSubmitBooking);
    }

    private void setupProviderData() {
        tvBookingProviderSummary.setText(String.format("Specialist: %s (%s)", provider.getName(), provider.getCategory()));
        etServiceTitle.setText(provider.getCategory() + " Diagnostic & Repair");

        visitFee = Math.max(199.0, provider.getHourlyRate());
        estimatedLabor = 150.0;

        tvBreakdownVisit.setText(String.format(Locale.getDefault(), "₹%.0f", visitFee));
        tvBreakdownLabor.setText(String.format(Locale.getDefault(), "₹%.0f", estimatedLabor));
        tvTotalEstimate.setText(String.format(Locale.getDefault(), "₹%.0f", visitFee + estimatedLabor));
    }

    private void setupDatePicker() {
        // Pre-fill tomorrow's date
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        etDate.setText(sdf.format(calendar.getTime()));

        etDate.setOnClickListener(v -> {
            DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
                calendar.set(year, month, dayOfMonth);
                etDate.setText(sdf.format(calendar.getTime()));
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

            // Prevent picking past dates
            dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            dialog.show();
        });
    }

    private void setupTimeSlots() {
        String[] slots = new String[]{
                "09:00 AM - 11:00 AM",
                "11:00 AM - 01:00 PM",
                "02:00 PM - 04:00 PM",
                "04:00 PM - 06:00 PM",
                "06:00 PM - 08:00 PM"
        };
        ArrayAdapter<String> slotAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, slots);
        spinnerTimeSlot.setAdapter(slotAdapter);
    }

    private void setupListeners() {
        btnBookingBack.setOnClickListener(v -> finish());
        btnSubmitBooking.setOnClickListener(v -> submitBooking());
    }

    private void submitBooking() {
        String title = etServiceTitle.getText() != null ? etServiceTitle.getText().toString().trim() : "";
        String problemDesc = etProblemDesc.getText() != null ? etProblemDesc.getText().toString().trim() : "";
        String address = etAddress.getText() != null ? etAddress.getText().toString().trim() : "";
        String date = etDate.getText() != null ? etDate.getText().toString().trim() : "";
        String slot = spinnerTimeSlot.getSelectedItem() != null ? spinnerTimeSlot.getSelectedItem().toString() : "10:00 AM - 12:00 PM";

        if (title.isEmpty()) {
            etServiceTitle.setError("Please enter service title");
            etServiceTitle.requestFocus();
            return;
        }

        if (problemDesc.length() < 10) {
            etProblemDesc.setError("Please provide a description of the issue (at least 10 characters)");
            etProblemDesc.requestFocus();
            return;
        }

        if (address.length() < 8) {
            etAddress.setError("Please provide a detailed service address or flat number");
            etAddress.requestFocus();
            return;
        }

        long customerId = sessionManager.getUserId();
        double totalCost = visitFee + estimatedLabor;

        long bookingId = dbHelper.createBooking(
                customerId,
                provider.getId(),
                1,
                title,
                problemDesc,
                address,
                date,
                slot,
                totalCost
        );

        if (bookingId != -1) {
            Toast.makeText(this, "Booking Request Confirmed!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, BookingDetailActivity.class);
            intent.putExtra("booking_id", bookingId);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to create booking. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
