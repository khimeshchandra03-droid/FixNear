package com.fixnear.app.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.R;
import com.fixnear.app.model.Booking;
import com.fixnear.app.model.BookingTimelineEvent;

import java.util.List;

public class TimelineAdapter extends RecyclerView.Adapter<TimelineAdapter.ViewHolder> {

    private final Context context;
    private final List<BookingTimelineEvent> events;

    public TimelineAdapter(Context context, List<BookingTimelineEvent> events) {
        this.context = context;
        this.events = events;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_timeline, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BookingTimelineEvent event = events.get(position);

        holder.tvTitle.setText(event.getTitle());
        holder.tvTimestamp.setText(event.getTimestamp());
        holder.tvDescription.setText(event.getDescription());

        // Color coding timeline icons
        if (Booking.STATUS_COMPLETED.equalsIgnoreCase(event.getStatus())) {
            holder.imgIcon.setColorFilter(ContextCompat.getColor(context, R.color.status_completed));
        } else if (Booking.STATUS_CANCELLED.equalsIgnoreCase(event.getStatus()) ||
                Booking.STATUS_REJECTED.equalsIgnoreCase(event.getStatus())) {
            holder.imgIcon.setColorFilter(ContextCompat.getColor(context, R.color.status_cancelled));
        } else if (Booking.STATUS_IN_PROGRESS.equalsIgnoreCase(event.getStatus())) {
            holder.imgIcon.setColorFilter(ContextCompat.getColor(context, R.color.status_in_progress));
        } else {
            holder.imgIcon.setColorFilter(ContextCompat.getColor(context, R.color.brand_deep_aubergine));
        }

        // Hide connector line for the last item
        if (position == events.size() - 1) {
            holder.line.setVisibility(View.INVISIBLE);
        } else {
            holder.line.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgIcon;
        View line;
        TextView tvTitle, tvTimestamp, tvDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgIcon = itemView.findViewById(R.id.imgTimelineIcon);
            line = itemView.findViewById(R.id.timelineLine);
            tvTitle = itemView.findViewById(R.id.tvTimelineTitle);
            tvTimestamp = itemView.findViewById(R.id.tvTimelineTimestamp);
            tvDescription = itemView.findViewById(R.id.tvTimelineDescription);
        }
    }
}
