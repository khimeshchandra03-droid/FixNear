package com.fixnear.app.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.R;
import com.fixnear.app.model.ProviderProfile;
import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

public class AdminVerificationAdapter extends RecyclerView.Adapter<AdminVerificationAdapter.ViewHolder> {

    public interface OnVerificationActionListener {
        void onApprove(ProviderProfile provider);
        void onReject(ProviderProfile provider);
    }

    private final Context context;
    private List<ProviderProfile> list;
    private final OnVerificationActionListener listener;

    public AdminVerificationAdapter(Context context, List<ProviderProfile> list, OnVerificationActionListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    public void updateList(List<ProviderProfile> updated) {
        this.list = updated;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_admin_verification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProviderProfile p = list.get(position);

        holder.tvName.setText(p.getName());
        holder.tvCategoryExp.setText(String.format(Locale.getDefault(),
                "Category: %s • Experience: %d yrs • Rate: ₹%.0f",
                p.getCategory(), p.getExperienceYears(), p.getHourlyRate()));

        holder.tvDocumentInfo.setText(String.format("Submitted ID: %s (%s)",
                p.getIdProofType() != null && !p.getIdProofType().isEmpty() ? p.getIdProofType() : "Govt ID Proof",
                p.getIdProofNumber() != null && !p.getIdProofNumber().isEmpty() ? p.getIdProofNumber() : "Document Attached"));

        holder.tvArea.setText("Service Area: " + (p.getServiceArea() != null ? p.getServiceArea() : "Central Zone"));

        holder.btnApprove.setOnClickListener(v -> {
            if (listener != null) listener.onApprove(p);
        });

        holder.btnReject.setOnClickListener(v -> {
            if (listener != null) listener.onReject(p);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategoryExp, tvDocumentInfo, tvArea;
        MaterialButton btnApprove, btnReject;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvAdminProviderName);
            tvCategoryExp = itemView.findViewById(R.id.tvAdminCategoryExp);
            tvDocumentInfo = itemView.findViewById(R.id.tvAdminDocumentInfo);
            tvArea = itemView.findViewById(R.id.tvAdminArea);
            btnApprove = itemView.findViewById(R.id.btnAdminApprove);
            btnReject = itemView.findViewById(R.id.btnAdminReject);
        }
    }
}
