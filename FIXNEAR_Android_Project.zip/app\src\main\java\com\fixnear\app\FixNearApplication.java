package com.fixnear.app;

import android.app.Application;
import com.fixnear.app.data.DatabaseHelper;

public class FixNearApplication extends Application {
    private static FixNearApplication instance;
    private DatabaseHelper databaseHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        databaseHelper = new DatabaseHelper(this);
    }

    public static FixNearApplication getInstance() {
        return instance;
    }

    public DatabaseHelper getDatabaseHelper() {
        return databaseHelper;
    }
}
