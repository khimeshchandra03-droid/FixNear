package com.fixnear.app.ui.customer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fixnear.app.FixNearApplication;
import com.fixnear.app.R;
import com.fixnear.app.data.DatabaseHelper;
import com.fixnear.app.data.SessionManager;
import com.fixnear.app.engine.TrustScoreCalculator;
import com.fixnear.app.model.ProviderProfile;
import com.fixnear.app.model.Review;
import com.fixnear.app.model.TrustScoreDetails;
import com.fixnear.app.ui.adapters.ReviewAdapter;
import com.fixnear.app.ui.chat.ChatActivity;
import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

public class ProviderDetailActivity extends AppCompatActivity {

    private ImageView btnBack, btnFavoriteDetail;
    private TextView tvDetailName, tvDetailCategory, tvDetailVerificationBadge, tvDetailRate;
    private TextView tvDetailArea, tvDetailSkills, tvDetailBio;
    private TextView tvTrustScoreValue, tvTrustScoreTier, tvReviewsHeader, tvDetailAvgRating;
    private MaterialButton btnExplainTrustScore, btnMessageSpecialist, btnBookServiceNow;
    private RecyclerView rvProviderReviews;

    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private ProviderProfile provider;
    private long providerId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provider_detail);

        dbHelper = FixNearApplication.getInstance().getDatabaseHelper();
        sessionManager = new SessionManager(this);

        providerId = getIntent().getLongExtra("provider_id", -1);
        if (providerId == -1) {
            Toast.makeText(this, "Specialist not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        loadProviderData();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnFavoriteDetail = findViewById(R.id.btnFavoriteDetail);
        tvDetailName = findViewById(R.id.tvDetailName);
        tvDetailCategory = findViewById(R.id.tvDetailCategory);
        tvDetailVerificationBadge = findViewById(R.id.tvDetailVerificationBadge);
        tvDetailRate = findViewById(R.id.tvDetailRate);
        tvDetailArea = findViewById(R.id.tvDetailArea);
        tvDetailSkills = findViewById(R.id.tvDetailSkills);
        tvDetailBio = findViewById(R.id.tvDetailBio);
        tvTrustScoreValue = findViewById(R.id.tvTrustScoreValue);
        tvTrustScoreTier = findViewById(R.id.tvTrustScoreTier);
        tvReviewsHeader = findViewById(R.id.tvReviewsHeader);
        tvDetailAvgRating = findViewById(R.id.tvDetailAvgRating);
        btnExplainTrustScore = findViewById(R.id.btnExplainTrustScore);
        btnMessageSpecialist = findViewById(R.id.btnMessageSpecialist);
        btnBookServiceNow = findViewById(R.id.btnBookServiceNow);
        rvProviderReviews = findViewById(R.id.rvProviderReviews);
    }

    private void loadProviderData() {
        provider = dbHelper.getProviderById(providerId);
        if (provider == null) {
            Toast.makeText(this, "Profile unavailable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        long customerId = sessionManager.getUserId();
        provider.setFavorite(dbHelper.isFavorite(customerId, provider.getId()));

        tvDetailName.setText(provider.getName());
        tvDetailCategory.setText(String.format(Locale.getDefault(), "%s Specialist • %d yrs experience",
                provider.getCategory(), provider.getExperienceYears()));
        tvDetailRate.setText(String.format(Locale.getDefault(), "Starting ₹%.0f visit", provider.getHourlyRate()));
        tvDetailArea.setText("📍 Service Area: " + (provider.getServiceArea() != null ? provider.getServiceArea() : "Citywide"));
        tvDetailSkills.setText("🛠️ Core Skills: " + (provider.getSkills() != null ? provider.getSkills() : "Repairs & Maintenance"));
        tvDetailBio.setText(provider.getBio() != null ? provider.getBio() : "Professional technician offering verified repair services.");

        // Verification Badge logic
        if (provider.isVerified()) {
            tvDetailVerificationBadge.setText("Govt ID Verified");
            tvDetailVerificationBadge.setBackgroundResource(R.drawable.bg_badge_verified);
            tvDetailVerificationBadge.setTextColor(ContextCompat.getColor(this, R.color.badge_verified));
        } else if (provider.isPendingReview()) {
            tvDetailVerificationBadge.setText("Verification Pending");
            tvDetailVerificationBadge.setBackgroundResource(R.drawable.bg_badge_pending);
            tvDetailVerificationBadge.setTextColor(ContextCompat.getColor(this, R.color.status_pending));
        } else {
            tvDetailVerificationBadge.setText("Unverified");
            tvDetailVerificationBadge.setBackgroundResource(R.drawable.bg_badge_unverified);
            tvDetailVerificationBadge.setTextColor(ContextCompat.getColor(this, R.color.badge_unverified));
        }

        // Trust score
        TrustScoreDetails trustDetails = TrustScoreCalculator.calculate(provider);
        tvTrustScoreValue.setText(trustDetails.getTotalScore() + "/100");
        tvTrustScoreTier.setText("Status: " + trustDetails.getTierLabel());

        // Favorite icon
        updateFavoriteIcon();

        // Reviews
        List<Review> reviews = dbHelper.getReviewsForProvider(providerId);
        tvReviewsHeader.setText(String.format(Locale.getDefault(), "Customer Reviews (%d)", reviews.size()));
        tvDetailAvgRating.setText(String.format(Locale.getDefault(), "%.1f", provider.getRatingAvg()));

        rvProviderReviews.setLayoutManager(new LinearLayoutManager(this));
        rvProviderReviews.setAdapter(new ReviewAdapter(this, reviews));
    }

    private void updateFavoriteIcon() {
        btnFavoriteDetail.setImageResource(provider.isFavorite() ? R.drawable.ic_favorite : R.drawable.ic_favorite_border);
        btnFavoriteDetail.setColorFilter(provider.isFavorite() ?
                ContextCompat.getColor(this, R.color.status_cancelled) :
                ContextCompat.getColor(this, R.color.brand_ice_silver));
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnFavoriteDetail.setOnClickListener(v -> {
            long customerId = sessionManager.getUserId();
            boolean isFav = dbHelper.toggleFavorite(customerId, provider.getId());
            provider.setFavorite(isFav);
            updateFavoriteIcon();
            Toast.makeText(this, isFav ? "Added to Saved Professionals" : "Removed from Saved", Toast.LENGTH_SHORT).show();
        });

        btnExplainTrustScore.setOnClickListener(v -> {
            TrustScoreDetails details = TrustScoreCalculator.calculate(provider);
            new AlertDialog.Builder(this)
                    .setTitle("🛡️ FIXNEAR Trust Score™ Breakdown")
                    .setMessage(details.getExplanation() + "\n\n" +
                            "FIXNEAR Trust Score is an explainable reliability rating built on verified evidence, not commercial sponsorship.")
                    .setPositiveButton("Close", null)
                    .show();
        });

        btnBookServiceNow.setOnClickListener(v -> {
            Intent intent = new Intent(this, BookingActivity.class);
            intent.putExtra("provider_id", provider.getId());
            startActivity(intent);
        });

        btnMessageSpecialist.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("other_user_id", provider.getUserId());
            intent.putExtra("other_user_name", provider.getName());
            startActivity(intent);
        });
    }
}
