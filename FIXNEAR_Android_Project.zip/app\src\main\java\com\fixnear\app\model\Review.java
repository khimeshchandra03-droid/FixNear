package com.fixnear.app.model;

import java.io.Serializable;

public class Review implements Serializable {
    private long id;
    private long bookingId;
    private long customerId;
    private String customerName;
    private long providerId;
    private float rating;
    private String reviewText;
    private String createdAt;

    public Review() {}

    public Review(long id, long bookingId, long customerId, String customerName, long providerId,
                  float rating, String reviewText, String createdAt) {
        this.id = id;
        this.bookingId = bookingId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.providerId = providerId;
        this.rating = rating;
        this.reviewText = reviewText;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getBookingId() { return bookingId; }
    public void setBookingId(long bookingId) { this.bookingId = bookingId; }

    public long getCustomerId() { return customerId; }
    public void setCustomerId(long customerId) { this.customerId = customerId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public long getProviderId() { return providerId; }
    public void setProviderId(long providerId) { this.providerId = providerId; }

    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }

    public String getReviewText() { return reviewText; }
    public void setReviewText(String reviewText) { this.reviewText = reviewText; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
